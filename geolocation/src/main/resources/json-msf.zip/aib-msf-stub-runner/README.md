# Stub Runner Sandbox Boot

This is a Spring Boot application that will run stubs on specific ports that you can specify in config.

Under the hood:

It either downloads the stubs from a repository or if you choose to work offline it will try your local M2 Repo.

You can configure it as follows:

```yml
stubrunner:
  # artifact ids containing stubs to be downloaded
  ids: ie.aib.groupid:artifactid:classifier:version:port
  # url of where the stubs reside
  repositoryRoot: https://nexus.aib.pri/nexus/content/repositories/releases/
```

Then when you start the application the stubs will be downloaded and
http server stubs will be started for you.

# How to use

If you go to /stubs you will see something like:

```javascript
{"ie.aib.msf.sample:server:1.0.0-SNAPSHOT:stubs":9876}
```
This JSON object contains the resolved stubs and the port they're running on. Similarly /mappings will show you mappings.

You can make http requests on those ports to use the stubs. If it couldn't resolve your stub from a remote repo it won't appear here.

# Common Problems

### Q: It can't find the contract stub from when I start the application

A: * Try running working offline first, to ensure that your group, artifact id, and version are correct.
   * Ensure that the artifact jar has been built correctly. I.e. you can see the wiremock JSON inside.
   * Make sure that your repositoryRoot matches what you've set in the version, i.e. if you've specified a snapshot, use the snapshot repo.

   It is also possible to use remote stubs as part of a JUnit test, it may be easier to debug/troubleshoot there. You can add:

```java
@AutoConfigureStubRunner(repositoryRoot = "classpath:m2repo/repository/",
        		ids = { "org.springframework.cloud.contract.verifier.stubs:contextPathFraudDetectionServer" })
```

Have a look at the consumer module in the samples at for an example of how to use: https://gitstash.aib.pri/projects/MSFSAM/repos/spring-cloud-contract-sample/browse/contract-consumer

### Q: When starting you get the following exception:

```bash
org.springframework.beans.factory.UnsatisfiedDependencyException: Error creating bean with name 'org.springframework.cloud.contract.stubrunner.server.HttpStubsController': Unsatisfied dependency expressed through constructor parameter 0; nested exception is org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'batchStubRunner' defined in org.springframework.cloud.contract.stubrunner.spring.StubRunnerConfiguration: Bean instantiation via factory method failed; nested exception is org.springframework.beans.BeanInstantiationException: Failed to instantiate [org.springframework.cloud.contract.stubrunner.BatchStubRunner]: Factory method 'batchStubRunner' threw exception; nested exception is java.lang.IllegalStateException: Remote repositories for stubs are not specified and work offline flag wasn't passed
	at org.springframework.beans.factory.support.ConstructorResolver.createArgumentArray(ConstructorResolver.java:749) ~[spring-beans-4.3.5.RELEASE.jar!/:4.3.5.RELEASE]
	at org.springframework.beans.factory.support.ConstructorResolver.autowireConstructor(ConstructorResolver.java:189) ~[spring-beans-4.3.5.RELEASE.jar!/:4.3.5.RELEASE]
	at org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory.autowireConstructor(AbstractAutowireCapableBeanFactory.java:1154) ~[spring-beans-4.3.5.RELEASE.jar!/:4.3.5.RELEASE]
```

A: The application expects `stubrunner.repositoryRoot` when working online so it knows where to get the stubs. You will need to set this so it can download them.
Alternatively, you can set `stubRunner.workOffline` flag to `true` and work from the local M2 repo.


# Why do this?

It's possible to run stubs with the likes of:

```bash
mvn spring-cloud-contract-verifier:run -Dspring.cloud.contract.verifier.stubs=ie.aib:example:+:stubs:1234
```

Which doesn't even need a pom.

With with the stubs in an actual Spring Boot Application, we have the option to deploy and configure the stubs in one place for (external) people to test and it should just be a matter of setting config.

## Links

- https://cloud.spring.io/spring-cloud-contract/
