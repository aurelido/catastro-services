package ie.aib.msf.sandbox

import org.junit.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.context.SpringBootContextLoader
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.cloud.client.loadbalancer.LoadBalanced
import org.springframework.cloud.contract.stubrunner.StubFinder
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner
import org.springframework.cloud.netflix.eureka.EnableEurekaClient
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer
import org.springframework.context.ConfigurableApplicationContext
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.http.HttpMethod
import org.springframework.http.client.ClientHttpResponse
import org.springframework.test.annotation.DirtiesContext
import org.springframework.test.context.ContextConfiguration
import org.springframework.web.client.*
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.util.concurrent.PollingConditions

@ContextConfiguration(classes = Config, loader = SpringBootContextLoader)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = ["stubrunner.cloud.eureka.enabled=true",
                "stubrunner.cloud.stubbed.discovery.enabled=true",
                "stubrunner.cloud.ribbon.enabled=true",
                "eureka.client.enabled=true",
                "eureka.instance.leaseRenewalIntervalInSeconds=1",
                "ribbon.ServerListRefreshInterval=100"])
@AutoConfigureStubRunner(
        workOffline = false, //from Nexus
        repositoryRoot = "https://nexus.aib.pri/nexus/content/repositories/releases",
        ids = ["ie.aib.apigee.v2.aisp.account:accounts:+"] //get the latest account stub
)
@DirtiesContext
class StubRunnerSpringCloudEurekaAutoConfigIT extends Specification {

    @Autowired
    StubFinder stubFinder
    @Autowired
    @LoadBalanced
    RestTemplate restTemplate
    @Shared
    @AutoCleanup
    ConfigurableApplicationContext eurekaServer

    void setupSpec() {
        System.clearProperty("stubrunner.stubs.repository.root")
        System.clearProperty("stubrunner.stubs.classifier")
        eurekaServer = SpringApplication.run(EurekaServer,
                "--stubrunner.cloud.eureka.enabled=true",
                "--stubrunner.cloud.stubbed.discovery.enabled=true",
                "--eureka.client.enabled=true",
                "--eureka.numberRegistrySyncRetries=0",
                "--server.port=8761",
                "--spring.profiles.active=eureka")

    }

    void cleanupSpec() {
        System.clearProperty("stubrunner.stubs.repository.root")
        System.clearProperty("stubrunner.stubs.classifier")
    }

    PollingConditions conditions = new PollingConditions(timeout: 120, delay: 1)

    @Test
    def 'that service discovery works for stubs'() {

        expect: 'The WireMock server is running the accounts stub'
        "${stubFinder.findStubUrl('accounts').toString()}/health".toURL().text == 'OK'
        and: 'Stubs can be reached via service discovery'
        conditions.eventually {
            // whenever we get a real service id once eureka has started, this id (from the test yml) will start to work
            assert restTemplate.getForObject('http://someNameThatShouldMapToAccounts/ping', String) == 'OK'
        }

    }

    @Configuration
    @EnableAutoConfiguration
    @EnableEurekaClient
    static class Config {

        @Bean
        @LoadBalanced
        RestTemplate restTemplate() {
            // we override the defaults to throw assertion errors so the polling loop will continue until it times out
            def template = new RestTemplate() {

                @Override
                protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor) throws RestClientException {
                    try {
                        return super.doExecute(url, method, requestCallback, responseExtractor)
                    } catch (Exception e) {
                        throw new AssertionError(e)
                    }
                }
            }
            template.errorHandler = new DefaultResponseErrorHandler() {
                @Override
                void handleError(ClientHttpResponse response) throws IOException {
                    try {
                        super.handleError(response)
                    } catch (Exception e) {
                        throw new AssertionError(e)
                    }
                }
            }
            return template
        }

    }

    @Configuration
    @EnableAutoConfiguration
    @EnableEurekaServer
    static class EurekaServer {

    }
}
