package ie.aib.msf.sandbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.contract.stubrunner.server.EnableStubRunnerServer;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;

@EnableDiscoveryClient
@EnableStubRunnerServer
@SpringBootApplication
@AutoConfigureStubRunner
public class StubRunnerBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(StubRunnerBootApplication.class, args);
    }
}