##MSF Config Server

MSF Config Server is an implementation of `org.springframework.cloud.config.server` (see [Spring Cloud Netflix](http://cloud.spring.io/spring-cloud-netflix/spring-cloud-netflix.html))

### Notable Properties

Property | Profile | Default Value
--- | --- | ---
`server.port` | default | 8888
`spring.application.name` | default | msf-config-server
`MSF_CONFIG_GIT_URI` | default | (no default vaue, required property)
`MSF_CONFIG_GIT_USERNAME` | default | (no default vaue, required property)
`MSF_CONFIG_GIT_PASSWORD` | default | (no default vaue, required property)
`MSF_CONFIG_GIT_DIR` | default | msf-config-server-repo
`MSF_DISCOVERY_HOST` | default | http://localhost
`MSF_DISCOVERY_PORT` | default | 8761
`SSL_KEY_STORE` | https | /opt/ssl/keystore.jks
`SSL_KEY_STORE_PASSWORD` | https | (no default vaue, required property)

It also supports mutual auth and encrypted properties, with [X509 security starter](https://wiki.aib.pri/pages/viewpage.action?pageId=39549668)

This is disabled by default, but can be enabled by setting: `ie.aib.msf.security.x509.enabled=true`

If enabled, it requires mutual auth, and the client certs must match the regex specified by `ie.aib.msf.security.x509.client-authorization-regex` (except for the /encrypt endpoint)

See [Spring Config Server Key management](https://cloud.spring.io/spring-cloud-config/spring-cloud-config.html#_key_management) for setting auth encryption keys.

See also [Spring Config Server secrets management](https://wiki.aib.pri/display/SWG/Spring+Config+Server+Secrets+Management) for a more detailed description of how this can be used for secrets management.