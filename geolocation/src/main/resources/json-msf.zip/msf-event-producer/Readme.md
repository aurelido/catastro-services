## Event Producer

The Event Producer writes events based on: [Event Bus Standards](https://wiki.aib.pri/display/SDA/Event+Bus+Standards+v2.0)

## Sync or Async

There are two `POST` methods:
+ `/kafka-message-sync` will attempt to wait and return any metadata (topic, partition, offset & timestamp) provided by the kafka producer.  
+ `/kafka-message-async` will send the message asynchronously to the kafka producer - no metadata is returned.

In both cases, the `POST` body is expected to be a concrete implementation of an `AbstractLogEntry` represented in `json`.

There are currently 5 subclasses of `AbstractLogEntry` which map to topics on Kafka as follows: 

LogType | Topic
--- | ---
`APPLICATION` | ${PREFIX}_applog
`AUDIT` | ${PREFIX}_audit
`BUSINESS` | ${PREFIX}_business
`NOTIFICATION` | ${PREFIX}_notification
`PERFORMANCE` | ${PREFIX}_perf

Where PREFIX is defined by `ie.aib.msf.event.producer.prefix`, which is a required property.

Events are written as `json` converted to `byte[]`.

### Configuration

The only properties that should need to be set are:

Property | Description
--- | ---
`ie.aib.msf.event.producer.prefix` | The topic prefix (as described above).
`ie.aib.msf.event.producer.logging.logTypes` | The list of `LogType`s for which events should be logged.
`spring.cloud.stream.kafka.binder.autoCreateTopics` | Set to `false` to disable autocreation of topics on Kafka (and disable the need to specify the Zookeeper address).
`spring.cloud.stream.kafka.binder.brokers` | The address(es) of the Kafka broker(s).
`spring.cloud.stream.kafka.binder.configuration."[max.block.ms]"` | How long `KafkaProducer.send()` will block.

Any other Kafka configuration can be done through the Spring Cloud Stream Kafka Binder.
