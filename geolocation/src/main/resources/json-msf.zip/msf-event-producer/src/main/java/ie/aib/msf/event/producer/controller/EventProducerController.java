package ie.aib.msf.event.producer.controller;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.event.producer.model.EventProducerMetadata;
import ie.aib.msf.event.producer.service.EventProducerService;
import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@JwtAuthorization
public class EventProducerController {
    
    public static final String EVENT_ENDPOINT_SYNC_PATH = "/kafka-message-sync";
    public static final String EVENT_ENDPOINT_ASYNC_PATH = "/kafka-message-async";
    public static final String EVENT_V1_ENDPOINT_SYNC_PATH = "/{version:v[1-9]|v[0-9]{1,}}/kafka-message-sync";
    public static final String EVENT_V1_ENDPOINT_ASYNC_PATH = "/{version:v[1-9]|v[0-9]{1,}}/kafka-message-async";

    private static final Log LOG = LogFactory.getLog(EventProducerController.class);

    private final EventProducerService eventProducerService;

    @Autowired
    public EventProducerController(EventProducerService eventProducerService) {
        this.eventProducerService = eventProducerService;
    }

    @PostMapping(path = {EVENT_ENDPOINT_SYNC_PATH, EVENT_V1_ENDPOINT_SYNC_PATH})
    public EventProducerMetadata sync(@RequestBody @Valid AbstractLogEntry abstractLogEntry) {
        if (LOG.isDebugEnabled()) {
            LOG.debug(String.format("Processing sync abstractLogEntry: %s", abstractLogEntry));
        }

        return eventProducerService.process(abstractLogEntry, true);
    }

    @PostMapping(path = {EVENT_ENDPOINT_ASYNC_PATH, EVENT_V1_ENDPOINT_ASYNC_PATH})
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void async(@RequestBody @Valid AbstractLogEntry abstractLogEntry) {
        if (LOG.isDebugEnabled()) {
            LOG.debug(String.format("Processing async abstractLogEntry: %s", abstractLogEntry));
        }

        eventProducerService.process(abstractLogEntry, false);
    }
}
