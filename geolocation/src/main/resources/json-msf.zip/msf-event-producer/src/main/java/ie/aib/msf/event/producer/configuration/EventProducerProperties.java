package ie.aib.msf.event.producer.configuration;

import ie.aib.msf.core.domain.model.event.LogType;
import java.util.List;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

@Component
@Validated
@ConfigurationProperties("ie.aib.msf.event.producer")
public class EventProducerProperties {

    public static class Logging {

        private List<LogType> logTypes;

        public List<LogType> getLogTypes() {
            return logTypes;
        }

        public void setLogTypes(List<LogType> logTypes) {
            this.logTypes = logTypes;
        }
    }

    @NotNull
    @Size(min = 1)
    private String prefix;

    private Logging logging;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public Logging getLogging() {
        return logging;
    }

    public void setLogging(Logging logging) {
        this.logging = logging;
    }
}
