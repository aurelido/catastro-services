package ie.aib.msf.event.producer.service;

import static org.apache.commons.lang3.builder.ToStringStyle.NO_CLASS_NAME_STYLE;

import ie.aib.msf.core.domain.exceptions.http.ServiceUnavailableException;
import ie.aib.msf.core.domain.model.event.LogType;
import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.event.producer.configuration.EventProducerProperties;
import ie.aib.msf.event.producer.model.EventProducerMetadata;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

@Service
public class EventProducerService {

    private static final Log LOG = LogFactory.getLog(EventProducerService.class);

    private static final Map<LogType, String> topicNames;

    static {
        topicNames = new HashMap<>();
        Arrays.stream(LogType.values()).forEach(logType -> topicNames.put(logType, logType.toValue()));
        topicNames.put(LogType.APPLICATION, "applog");
        topicNames.put(LogType.PERFORMANCE, "perf");
    }

    private final EventProducerProperties eventProducerProperties;
    private final ObjectMapperHelper objectMapperHelper;
    private final KafkaTemplate<byte[], byte[]> kafkaTemplate;
    private final List<LogType> loggingLogTypes;

    @Autowired
    public EventProducerService(EventProducerProperties eventProducerProperties,
            ObjectMapperHelper objectMapperHelper,
            KafkaTemplate<byte[], byte[]> kafkaTemplate) {
        this.eventProducerProperties = eventProducerProperties;
        this.objectMapperHelper = objectMapperHelper;
        this.kafkaTemplate = kafkaTemplate;

        if (eventProducerProperties.getLogging() != null
                && eventProducerProperties.getLogging().getLogTypes() != null) {
            loggingLogTypes = eventProducerProperties.getLogging().getLogTypes();
        } else {
            loggingLogTypes = null;
        }
    }

    public EventProducerMetadata process(AbstractLogEntry abstractLogEntry, boolean sync) {

        ListenableFuture<SendResult<byte[], byte[]>> listenableFuture;

        try {
            String json = objectMapperHelper.toJson(abstractLogEntry);
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            String topic = String.format("%s_%s",
                    eventProducerProperties.getPrefix(),
                    topicNames.get(abstractLogEntry.getType()));

            log(abstractLogEntry, topic, json);

            listenableFuture = kafkaTemplate.send(topic, bytes);

            // send blocks until a kafka producer is found (or not) so check for exception if done ...

            if (listenableFuture.isDone()) {
                listenableFuture.get();
            }
        } catch (Exception e) {
            throw new ServiceUnavailableException("Unable to send", e);
        }

        RecordMetadata recordMetadata = null;

        if (sync) {
            try {
                recordMetadata = listenableFuture.get().getRecordMetadata();
                if (LOG.isDebugEnabled()) {
                    LOG.debug(String.format("Received metadata: %s", recordMetadata.toString()));
                }
            } catch (Exception e) {
                throw new ServiceUnavailableException("Unable to receive acknowledgement for send", e);
            }
        }

        return EventProducerMetadata.valueOf(recordMetadata);
    }

    private void log(AbstractLogEntry abstractLogEntry, String topic, String json) {
        if (loggingLogTypes != null && loggingLogTypes.contains(abstractLogEntry.getType())) {
            LOG.info(String.format("Sending to topic %s: %s", topic, json));
        } else {
            if (LOG.isDebugEnabled()) {
                String info = new ToStringBuilder(null, NO_CLASS_NAME_STYLE)
                        .append("type", abstractLogEntry.getType())
                        .append("severity", abstractLogEntry.getSeverity())
                        .append("timestamp", abstractLogEntry.getTimestamp())
                        .append("host", abstractLogEntry.getHost())
                        .append("ip", abstractLogEntry.getIp())
                        .append("eventType", abstractLogEntry.getEventType())
                        .append("application", abstractLogEntry.getApplication())
                        .append("appVersion", abstractLogEntry.getAppVersion())
                        .toString();
                LOG.debug(String.format("Sending to topic %s: %s", topic, info));
            }
        }
    }
}
