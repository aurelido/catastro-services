package ie.aib.msf.event.producer.model;

import org.apache.kafka.clients.producer.RecordMetadata;

public class EventProducerMetadata {

    private String topic;
    private int partition;
    private long offset;
    private long timestamp;

    public static EventProducerMetadata valueOf(RecordMetadata recordMetadata) {
        EventProducerMetadata eventProducerMetadata;

        if (recordMetadata == null) {
            eventProducerMetadata = null;
        } else {
            eventProducerMetadata = new EventProducerMetadata();
            eventProducerMetadata.setTopic(recordMetadata.topic());
            eventProducerMetadata.setPartition(recordMetadata.partition());
            eventProducerMetadata.setOffset(recordMetadata.offset());
            eventProducerMetadata.setTimestamp(recordMetadata.timestamp());
        }

        return eventProducerMetadata;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getPartition() {
        return partition;
    }

    public void setPartition(int partition) {
        this.partition = partition;
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
