package ie.aib.msf.event.producer.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.event.producer.configuration.EventProducerProperties;
import ie.aib.msf.event.producer.model.EventProducerMetadata;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.FailureCallback;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.util.concurrent.SuccessCallback;

public class EventProducerServiceUnitTest {

    @Mock
    private EventProducerProperties eventProducerProperties;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private KafkaTemplate<byte[], byte[]> kafkaTemplate;

    @InjectMocks
    private EventProducerService eventProducerService;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSyncProcess() {
        AuditLogEntry auditLogEntry = AuditLogEntry.builder().build();
        Mockito.when(objectMapperHelper.toJson(Mockito.eq(auditLogEntry))).thenReturn("{}");
        Mockito.when(eventProducerProperties.getPrefix()).thenReturn("test");
        Mockito.when(kafkaTemplate.send(Mockito.eq("test_audit"), Mockito.any()))
                .thenReturn(newListenableFuture(newRecordMetadata())); // sync successful (get)

        EventProducerMetadata eventProducerMetadata = eventProducerService.process(auditLogEntry, true);
        assertEquals("test_audit", eventProducerMetadata.getTopic());
        assertEquals(3L, eventProducerMetadata.getOffset());
        assertEquals(0L, eventProducerMetadata.getPartition());
        assertEquals(3L, eventProducerMetadata.getTimestamp());
    }

    @Test
    public void testAsyncProcess() {
        AuditLogEntry auditLogEntry = AuditLogEntry.builder().build();
        Mockito.when(objectMapperHelper.toJson(Mockito.eq(auditLogEntry))).thenReturn("{}");
        Mockito.when(eventProducerProperties.getPrefix()).thenReturn("test");
        Mockito.when(kafkaTemplate.send(Mockito.eq("test_audit"), Mockito.any()))
                .thenReturn(newListenableFuture(null)); // async successful (no get)

        EventProducerMetadata eventProducerMetadata = eventProducerService.process(auditLogEntry, false);
        assertNull(eventProducerMetadata);
    }

    private RecordMetadata newRecordMetadata() {
        TopicPartition topicPartition = new TopicPartition("test_audit", 0);
        return new RecordMetadata(topicPartition, 1, 2, 3, 4, 5, 6);
    }

    private ListenableFuture<SendResult<byte[], byte[]>> newListenableFuture(final RecordMetadata recordMetadata) {
        final SendResult<byte[], byte[]> sendResult = new SendResult<>(null, recordMetadata);
        return new ListenableFuture<SendResult<byte[], byte[]>>() {
            @Override
            public boolean cancel(boolean mayInterruptIfRunning) {
                return false;
            }

            @Override
            public boolean isCancelled() {
                return false;
            }

            @Override
            public boolean isDone() {
                return false;
            }

            @Override
            public SendResult<byte[], byte[]> get() throws InterruptedException, ExecutionException {
                if (recordMetadata == null) {
                    throw new ExecutionException("TEST", null);
                }
                return sendResult;
            }

            @Override
            public SendResult<byte[], byte[]> get(long timeout, TimeUnit unit)
                    throws InterruptedException, ExecutionException, TimeoutException {
                return null;
            }

            @Override
            public void addCallback(ListenableFutureCallback<? super SendResult<byte[], byte[]>> callback) {

            }

            @Override
            public void addCallback(SuccessCallback<? super SendResult<byte[], byte[]>> successCallback,
                    FailureCallback failureCallback) {

            }
        };
    }
}
