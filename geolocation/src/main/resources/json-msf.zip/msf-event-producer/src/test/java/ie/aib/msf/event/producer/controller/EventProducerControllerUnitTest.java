package ie.aib.msf.event.producer.controller;

import static org.junit.Assert.assertEquals;

import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.event.producer.model.EventProducerMetadata;
import ie.aib.msf.event.producer.service.EventProducerService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class EventProducerControllerUnitTest {

    @Mock
    private EventProducerService eventProducerService;

    @InjectMocks
    private EventProducerController eventProducerController;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSync() {
        AuditLogEntry auditLogEntry = AuditLogEntry.builder().build();
        EventProducerMetadata eventProducerMetadata = new EventProducerMetadata();
        Mockito.when(eventProducerService.process(Mockito.eq(auditLogEntry), Mockito.eq(true)))
                .thenReturn(eventProducerMetadata);
        EventProducerMetadata response = eventProducerController.sync(auditLogEntry);
        assertEquals(response, eventProducerMetadata);
    }

    @Test
    public void testAsync() {
        AuditLogEntry auditLogEntry = AuditLogEntry.builder().build();
        eventProducerController.async(auditLogEntry);
        Mockito.verify(eventProducerService, Mockito.times(1)).process(Mockito.eq(auditLogEntry), Mockito.eq(false));
    }
}
