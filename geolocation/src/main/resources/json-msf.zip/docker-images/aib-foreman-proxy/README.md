#Building

To build. run the following command:

        docker build -t infra/aib-foreman-proxy .

#Running foreman

1. Run the container:

        docker run --name foreman-proxy.aib.pri -d -h foreman-proxy.aib.pri -p 8443:8443 -v /vagrant/workspace/docker-images/aib-foreman-proxy/certs:/certs infra/aib-foreman-proxy
        
NOTE: The mounted cert directory is expected to have a ca.pem, <FQDN>.pem, <FQDN>.key and a directory called trusted-certs containing any certs that are to be trusted. The Chef user PEM (<user>.pem) is also expected to be in a directory called chef.

