#!/bin/bash -xe

if [ ! -f /opt/.foreman_configured ]; then
    # Setup 
    mkdir -p /var/lib/puppet/ssl/certs/
    mkdir -p /var/lib/puppet/ssl/private_keys/
    mkdir -p /var/lib/puppet/ssl/ca/

    # Set proxy environment variables
    export http_proxy=$FOREMAN_HTTP_PROXY
    export https_proxy=$FOREMAN_HTTPS_PROXY
    export no_proxy=$FOREMAN_HOST,$FOREMAN_NO_PROXY
    
    # Copy certificates
    cp /certs/`hostname -f`.pem /var/lib/puppet/ssl/certs/`hostname -f`.pem
    cp /certs/`hostname -f`.key /var/lib/puppet/ssl/private_keys/`hostname -f`.pem    
    cp /certs/ca.pem /var/lib/puppet/ssl/certs/ca.pem

    # Install trusted certificates
    if [ -d "/certs/trusted-certs" ]; then
        for cert in `ls /certs/trusted-certs | grep ".crt$"`; do
            cp /certs/trusted-certs/$cert /usr/local/share/ca-certificates/
        done
    fi
    
    update-ca-certificates

    foreman-installer \
        --foreman-proxy-registered-name="$FOREMAN_PROXY_NAME" \
        --foreman-proxy-foreman-base-url=https://$FOREMAN_HOST:$FOREMAN_PORT \
        --foreman-proxy-oauth-consumer-key=$FOREMAN_OAUTH_CONSUMER_KEY \
        --foreman-proxy-oauth-consumer-secret=$FOREMAN_OAUTH_CONSUMER_SECRET \
        --no-enable-foreman \
        --no-enable-foreman-cli \
        --no-enable-foreman-plugin-setup \
        --enable-foreman-proxy \
        --no-enable-puppet \
        --puppet-server=false \
        --foreman-proxy-logs=false \
        --foreman-proxy-dns=false \
        --foreman-proxy-dhcp=false \
        --foreman-proxy-tftp=false \
        --foreman-proxy-puppet=false \
        --foreman-proxy-puppetca=false \
        --enable-foreman-proxy-plugin-chef \
        --foreman-proxy-plugin-chef-client-name=$CHEF_CLIENT_NAME \
        --foreman-proxy-plugin-chef-private-key=/certs/chef/$CHEF_CLIENT_NAME.pem \
        --foreman-proxy-plugin-chef-server-url=$CHEF_SERVER_URL \
        --foreman-proxy-plugin-chef-ssl-verify=false \
        --foreman-server-ssl-crl=''

    # Reset proxy
    unset http_proxy
    unset https_proxy
    unset no_proxy
    
    # Restart foreman-proxy
    service foreman-proxy restart

    touch /opt/.foreman_configured
fi

tail -F /var/log/foreman-proxy/proxy.log
