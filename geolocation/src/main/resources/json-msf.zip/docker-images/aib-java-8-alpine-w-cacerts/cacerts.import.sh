#!/bin/sh
echo -e "changeit\nyes" | keytool -import -file aib.root.ca.cer -keystore /etc/ssl/certs/java/cacerts -alias aibrootca
