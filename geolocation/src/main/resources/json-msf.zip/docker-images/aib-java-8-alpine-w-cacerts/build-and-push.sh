#!/bin/bash
if [ "$#" -ne 1 ]; then
    echo "Must specify version number"
    exit 1
fi

docker build -t nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts .

docker tag nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts:${1}

docker push nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts:${1}
docker push nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts:latest

docker pull nexus3.aib.pri:18444/infra/aib-java-8-alpine-w-cacerts:${1}
