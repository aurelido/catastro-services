## jenkins-aib pipeline

* To rebuild the docker images, visit the `build` directory
 
* To configure and run a new jenkins-aib instance, visit the `run` directory

