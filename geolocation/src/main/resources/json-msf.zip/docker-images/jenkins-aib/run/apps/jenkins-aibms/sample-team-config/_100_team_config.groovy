import jenkins.model.*
import hudson.model.*
import hudson.security.*

def instance = Jenkins.getInstance()

println "AIB Team config script running"
/*******************
***   AUTH STRATEGY
******/
def strategy = new GlobalMatrixAuthorizationStrategy()
// TODO add the auth props here

//  Setting Anonymous Permissions

strategy.add(hudson.model.Hudson.READ,'anonymous')
strategy.add(hudson.model.Hudson.READ,'Jenkins_Admin')
strategy.add(hudson.model.Hudson.READ,'Jenkins_User')
strategy.add(hudson.model.Hudson.ADMINISTER, "Jenkins_Admin")
strategy.add(hudson.model.Hudson.ADMINISTER, "admin")
strategy.add(hudson.model.Hudson.ADMINISTER, "42898") // TODO - this should be config driven
strategy.add(hudson.model.Hudson.ADMINISTER, "57106") // TODO - this should be config driven

strategy.add(Item.READ,'Jenkins_User')
strategy.add(Item.DISCOVER,'Jenkins_User')
strategy.add(Item.CONFIGURE,'Jenkins_User')
strategy.add(Item.CREATE,'Jenkins_User')
strategy.add(Item.DELETE,'Jenkins_User')
strategy.add(Item.BUILD,'Jenkins_User')
strategy.add(Item.WORKSPACE,'Jenkins_User')
strategy.add(Item.CANCEL,'Jenkins_User')

println "AIB settings credentials permission"
strategy.add( com.cloudbees.plugins.credentials.CredentialsProvider.CREATE, "Jenkins_User" )
strategy.add( com.cloudbees.plugins.credentials.CredentialsProvider.DELETE, "Jenkins_User" )
strategy.add( com.cloudbees.plugins.credentials.CredentialsProvider.UPDATE, "Jenkins_User" )
strategy.add( com.cloudbees.plugins.credentials.CredentialsProvider.VIEW, "Jenkins_User" )
strategy.add( com.cloudbees.plugins.credentials.CredentialsProvider.MANAGE_DOMAINS, "Jenkins_User" )
println "AIB settings credentials permission COMPLETE"

strategy.add(Run.UPDATE,'Jenkins_User')
strategy.add(Run.DELETE,'Jenkins_User')

strategy.add(View.READ,'Jenkins_User')
strategy.add(View.CONFIGURE,'Jenkins_User')
strategy.add(View.CREATE,'Jenkins_User')
strategy.add(View.DELETE,'Jenkins_User')

//strategy.add(hudson.scm.SCM.Tag,'Jenkins_User')

strategy.add(Computer.BUILD,'Jenkins_Admin')
strategy.add(Computer.CONFIGURE,'Jenkins_Admin')
strategy.add(Computer.CONNECT,'Jenkins_Admin')
strategy.add(Computer.CREATE,'Jenkins_Admin')
strategy.add(Computer.DISCONNECT,'Jenkins_Admin')

instance.setAuthorizationStrategy(strategy)
instance.save()
println "AIB Auth Strategy settings updated"
println "AIB Team config script complete."
