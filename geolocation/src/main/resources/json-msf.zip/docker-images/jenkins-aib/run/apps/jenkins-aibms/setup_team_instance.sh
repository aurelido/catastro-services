#!/bin/bash

# Change the jenkins user's id to the id of the user being passed in.
#  1. Should create group id 1000 on the host machine (called jenkins).
#  2. Create a new user (for each jenkins instance des_jenkins) on the host machine & ensure that user is in the jenkins group.
#  3. Ensure the workspace & config folders on the host are readable & writable by the jenkins group.
#  4. Containers will then change the container jenkins userid to be that of des_jenkins while leaving the group at default 1000
#  5. Containers will then execute as jenkins:jenkins withtin the container but as des_jenkins:jenkins on the host.

teamname=$1
if [ -z "${teamname}" ]; then
    echo "Team name must be provided as a parameter"
    exit 1
fi
username=$teamname"_jenkins"

# Ensure group is created
sudo groupadd --gid 2000 jenkins ## TODO - using gid 1000 failed on ubuntu, already in use

# Add the host user
sudo useradd --shell /bin/false -m -N -G jenkins,docker -c "$teamname Jenkins user" $username

# Create & setup the team folder
mkdir -p /apps/$teamname
mkdir -p /apps/$teamname/workspace
mkdir -p /apps/$teamname/config
# TODO::::::  Create TEAM config folder - ssl certs (./config/sslcerts), chef org knife config (./config/.chef),
#               File for team permissions from git(./config/sslcerts/_100_team_config.groovy in git)

cp -r ./sample-team-config/* /apps/$teamname/config
cp -r ./sample-team-config/.chef /apps/$teamname/config
cp ./docker-compose.yml /apps/$teamname/docker-compose.yml

cd /apps/$teamname

echo "Please edit /apps/$teamname/docker-compose.yml to:"
echo "  1) Setup your ports"
echo "  2) Configure your SSL Java keystore (/apps/$teamname/config/keystore.jks)"
echo "  3) Configure your chef connection in ./config"

sudo chown -R $username:jenkins .
sudo chmod -R g+w .

# docker-compose up
