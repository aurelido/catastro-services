## configure and run a new jenkins-aib instance

* On the docker host, clone or copy `/apps/jenkins-aibms`
 
* `cd apps/jenkins-aibms`

* `./setup_team_instance.sh {TEAM_NAME}`

* The above script will create a new team folder: `/apps/{TEAM_NAME}` 

* Edit the file `/apps/{TEAM_NAME}/docker-compose.yml` and:
    * Update `container_name`
    * Configure the appropriate ports (TODO - provide more detail)

* Configure the SSL java keystore (`/apps/{TEAM_NAME}/config/sslcerts/keystore.jks`)
* Configure the chef client (`/apps/{TEAM_NAME}/config/.chef/`)

* `docker-compose up`


##Enable GIT Authentication for the Jenkins Instance
*Run the Jenkins Job ShowPublicSSHKey
*Add the SSH Key to the Gitstash profile of the nominated GitStash Team user
*Grant that GitStash Read/Write access to each GIT repository that needs to be built on Jenkins