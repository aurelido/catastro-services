#Building

To build. run the following command:

        docker build -t infra/aib-foreman .

#Running foreman

1. Run the container:

        docker run --name foreman.aib.pri -d -p 444:443 -h foreman.aib.pri -v /vagrant/workspace/docker-images/aib-foreman/certs:/certs -v /vagrant/workspace/docker-images/aib-foreman/backup:/backup -e FOREMAN_USER=admin -e FOREMAN_PASSWORD=password -e FOREMAN_DB_PASSWORD=password -e FOREMAN_NUM_BACKUPS=30 infra/aib-foreman
        
NOTE: The mounted cert directory is expected to have a ca.pem, <FQDN>.pem, <FQDN>.key and a directory called trusted-certs containing any certs that are to be trusted.

