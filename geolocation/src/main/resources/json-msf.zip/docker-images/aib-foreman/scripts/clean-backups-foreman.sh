#!/bin/bash -xe

COUNT=`ls -l /backup/*.sql | wc -l`
NUM_BACKUPS=`cat /backup/num_backups`

if [ $COUNT -gt $NUM_BACKUPS ]; then
  ls -1 /backup/*.sql | sort | head -n $((COUNT-$NUM_BACKUPS)) | xargs rm
fi
