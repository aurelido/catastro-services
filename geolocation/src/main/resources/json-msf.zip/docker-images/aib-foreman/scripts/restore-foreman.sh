#!/bin/bash -xe

service apache2 stop
yes | foreman-rake db:import_dump file=`ls -1 /backup/*.sql | sort | tail -n 1`
service apache2 start