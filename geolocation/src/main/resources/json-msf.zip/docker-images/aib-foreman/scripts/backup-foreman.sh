#!/bin/bash -xe

foreman-rake db:dump && mv /usr/share/foreman/db/*.sql /backup/