#!/bin/bash -xe

echo $FOREMAN_NUM_BACKUPS > /backup/num_backups

if [ ! -f /opt/.foreman_configured ]; then 
    # Setup 
    localedef -i en_US -c -f UTF-8 -A /usr/share/locale/locale.alias en_US.UTF-8 
    mkdir -p /var/lib/puppet/ssl/certs/
    mkdir -p /var/lib/puppet/ssl/private_keys/
    mkdir -p /var/lib/puppet/ssl/ca/

    # Set proxy environment variables
    export http_proxy=$FOREMAN_HTTP_PROXY
    export https_proxy=$FOREMAN_HTTPS_PROXY
    export no_proxy=$FOREMAN_NO_PROXY

    # Copy certificates
    cp /certs/`hostname -f`.pem /var/lib/puppet/ssl/certs/`hostname -f`.pem
    cp /certs/`hostname -f`.key /var/lib/puppet/ssl/private_keys/`hostname -f`.pem    
    cp /certs/ca.pem /var/lib/puppet/ssl/certs/ca.pem

    # Install trusted certificates
    if [ -d "/certs/trusted-certs" ]; then
        for cert in `ls /certs/trusted-certs | grep ".crt$"`; do
            cp /certs/trusted-certs/$cert /usr/local/share/ca-certificates/
        done
    fi
    
    update-ca-certificates

    # Install foreman
	foreman-installer \
	  --foreman-admin-username="$FOREMAN_USER" \
	  --foreman-admin-password="$FOREMAN_PASSWORD" \
	  --foreman-db-password="$FOREMAN_DB_PASSWORD" \
	  --foreman-oauth-consumer-key="$FOREMAN_OAUTH_CONSUMER_KEY" \
	  --foreman-oauth-consumer-secret="$FOREMAN_OAUTH_CONSUMER_SECRET" \
	  --no-enable-foreman-proxy \
	  --no-enable-puppet \
	  --puppet-server=false \
	  --enable-foreman-plugin-chef \
	  --enable-foreman-plugin-tasks \
	  --foreman-server-ssl-crl='' 

    # Reset proxy
    unset http_proxy
    unset https_proxy
    unset no_proxy
    
    # Restart foreman
    service apache2 restart

	touch /opt/.foreman_configured
fi

tail -F /var/log/foreman/production.log
