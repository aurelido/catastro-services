## Building new version

The included script `build-and-push.sh` can be used to build a new version.

A new version must be specified as the first argument.

If successful, the new version will be tagged and pushed to Nexus3 as that version and `latest`