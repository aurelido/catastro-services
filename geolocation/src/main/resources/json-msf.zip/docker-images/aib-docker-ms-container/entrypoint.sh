#!/bin/sh

# touch the jar to make sure the timestamp is updated
touch -m /${1}.jar

java $JAVA_OPTS -Djava.security.egd=file:/dev/./urandom -jar /${1}.jar
