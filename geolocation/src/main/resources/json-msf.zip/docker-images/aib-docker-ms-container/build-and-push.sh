#!/bin/bash
if [ "$#" -ne 1 ]; then
    echo "Must specify version number"
    exit 1
fi

export DOCKERIZE_VERSION=v0.4.0
export https_proxy=http://webproxy.prd.aib.pri:8080

curl -L --insecure -O https://github.com/jwilder/dockerize/releases/download/$DOCKERIZE_VERSION/dockerize-linux-amd64-$DOCKERIZE_VERSION.tar.gz \
    && tar -C . -xzvf dockerize-linux-amd64-$DOCKERIZE_VERSION.tar.gz
    
dos2unix entrypoint.sh

docker build -t nexus3.aib.pri:18444/infra/aib-docker-ms-container .

docker tag nexus3.aib.pri:18444/infra/aib-docker-ms-container nexus3.aib.pri:18444/infra/aib-docker-ms-container:${1}
docker push nexus3.aib.pri:18444/infra/aib-docker-ms-container:${1}
docker push nexus3.aib.pri:18444/infra/aib-docker-ms-container:latest

docker pull nexus3.aib.pri:18444/infra/aib-docker-ms-container:${1}
docker pull nexus3.aib.pri:18444/infra/aib-docker-ms-container:latest
