package ie.aib.msf.eureka.server;

import io.micrometer.core.instrument.Meter.Id;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.config.MeterFilter;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetricsConfiguration {

    public MetricsConfiguration(MeterRegistry meterRegistry) {
        meterRegistry.config().meterFilter(MeterFilter
                .deny(MetricsConfiguration::checkCatalogUriTag));
    }

    /*
        Prometheus' Consul scraping uses a long-poll to check for registry changes.
        See https://github.com/twinformatics/eureka-consul-adapter#long-polling

        This usually takes up to 30s and can skew metrics for request time across services if included in
        aggregate metrics.
        Easiest thing to do is drop the metrics for that set of URIs, since the time will always be around 30s
     */
    private static boolean checkCatalogUriTag(Id meterId) {
        String tag = meterId.getTag("uri");
        return tag != null && tag.contains("/v1/catalog/service");
    }
}