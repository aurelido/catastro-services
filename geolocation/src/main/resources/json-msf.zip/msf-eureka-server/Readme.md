##MSF Eureka Server

MSF Eureka Server is an implementation of `org.springframework.cloud.netflix.eureka.server` (see [Spring Cloud Netflix](http://cloud.spring.io/spring-cloud-netflix/spring-cloud-netflix.html))

### Notable Properties

Property | Profile | Default Value
--- | --- | ---
`server.port` | default | 8761
`spring.application.name` | default | msf-eureka-server
`MSF_DISCOVERY_PEER` | default | http://${spring.cloud.client.hostname}:${server.port}/eureka/<br>See [Standalone Mode](http://cloud.spring.io/spring-cloud-netflix/spring-cloud-netflix.html#_standalone_mode) versus [Peer Awareness](http://cloud.spring.io/spring-cloud-netflix/spring-cloud-netflix.html#_peer_awareness)
`SSL_KEY_STORE` | https | /opt/ssl/keystore.jks
`SSL_KEY_STORE_PASSWORD` | https | (no default vaue, required property)
