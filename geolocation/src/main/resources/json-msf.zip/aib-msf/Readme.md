##AIB MSF (aib-msf-super-pom)

This project contains reusable Maven POMs and some helpful Libraries and Models for use within the AIB Microservice Framework (MSF). 

###Project / POM Hierarcy

+ aib-msf-super-pom
    + aib-msf-library-parent
        + aib-msf-boot-parent

####aib-msf-super-pom

+ The POM within aib-msf-super-pom, contains the majority of our dependency management, plugin and profile configuration. Crucially, this POM dictates which versions of the Spring Platform and Spring Cloud BOMs are to be imported.     

####aib-msf-library-parent

+ The aib-msf-library-parent POM inherits from aib-msf-super-pom and simply extends the dependency management to include the enclosed MSF Libraries and Models.  The source for the enclosed MSF Libraries and Models can be found within the aib-msf-library-parent module.  
+ **The aib-msf-library-parent POM should be used as the parent for new standalone library projects** developed for use within the Microservice Framework.
   
####aib-msf-boot-parent

+ The aib-msf-boot-parent POM inherits from aib-msf-library-parent and adds some common Spring Boot dependencies in addition to the Spring Boot Maven Plugin.
+ **The aib-msf-boot-parent POM should be used as the parent for new microservice projects**.
+ The dependencies directly included are:
    + jolokia-core
    + logback-core
    + logback-classic
    + spring-boot-starter-actuator
    + spring-boot-starter-web
    + spring-boot-starter-test
    + spring-boot-starter-aop (required for back-off and retry for config-server clients)
    + spring-retry (required for back-off and retry for config-server clients)
    + aib-msf-branding (brings in AIB branded banner.jpg, favicon.ico and banner.txt)