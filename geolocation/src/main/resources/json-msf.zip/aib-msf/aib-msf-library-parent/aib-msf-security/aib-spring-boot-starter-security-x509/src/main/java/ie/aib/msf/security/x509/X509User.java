package ie.aib.msf.security.x509;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

@SuppressWarnings("WeakerAccess")
public class X509User extends User {

    private transient Map<String, Object> properties;

    /**
     * Create a new X509 user, representing a user identified by a X509 certificate.
     * @param username The username, which should be the full distinguished name of the certificate
     * @param authorities Granted authorities for the user
     * @param properties Map of properties associated with the user
     */
    public X509User(String username,
            Collection<? extends GrantedAuthority> authorities, Map<String, Object> properties) {
        super(username, "", authorities);

        if (properties != null) {
            this.properties = Collections.unmodifiableMap(properties);
        } else {
            this.properties = Collections.emptyMap();
        }
    }

    /**
     * Get the properties associated with this user.
     * <p/>
     * These are defined by {@link X509Properties#getClients()}
     * @return The client properties
     */
    public Map<String, Object> getProperties() {
        return properties;
    }

    /**
     * Get a single property associated with the user
     * @param name The property name
     * @param clazz The class of the property
     * @param <T> Type of clazz
     * @return The property, cast to the specified type
     */
    public <T> T getProperty(String name, Class<T> clazz) {
        Object property = properties.get(name);
        if (property != null) {
            return clazz.cast(property);
        }

        return null;
    }
}
