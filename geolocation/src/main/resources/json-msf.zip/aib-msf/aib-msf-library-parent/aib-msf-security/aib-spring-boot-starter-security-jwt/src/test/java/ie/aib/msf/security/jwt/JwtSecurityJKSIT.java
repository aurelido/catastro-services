package ie.aib.msf.security.jwt;

import static ie.aib.msf.security.jwt.test.JwtTestTokenGenerator.generateToken;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import io.jsonwebtoken.SignatureAlgorithm;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = JwtSecurityTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.jwt.keystore.file=classpath:test-keystore.jks",
                "ie.aib.msf.security.jwt.keyStore.alias=testKey",
                "ie.aib.msf.security.jwt.keyStore.password=password",
                "ie.aib.msf.security.jwt.user-claim=userId",
                "ie.aib.msf.security.jwt.role-claims=role"})
@AutoConfigureMockMvc
public class JwtSecurityJKSIT {

    private static final String BEARER = "Bearer ";
    private static final String NAME = "test";
    private static final String USER_ID = "userId";
    private static final String ROLE = "role";

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testValidJWT() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        String jwt = generateToken(claims);
        sendRequest(jwt)
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, " + NAME));
    }

    @Test
    public void testInvalidSignature() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        String jwt = generateToken(SignatureAlgorithm.HS512, "invalid-key", claims);
        sendRequest(jwt).andExpect(status().isUnauthorized());
    }

    @Test
    public void testValidJWTChangedKeyId() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        String jwt = generateToken("testKey2", claims);
        sendRequest(jwt)
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, " + NAME));
    }

    @Test
    public void testJWTSignedWithKidAbsentFromKeystore() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        String jwt = generateToken(SignatureAlgorithm.RS256, "classpath:jwt-it-test-keystore.jks",
                "password", "it-test-key", claims);
        sendRequest(jwt)
                .andExpect(status().isUnauthorized());
    }

    private ResultActions sendRequest(String jwt) throws Exception {
        return mockMvc
                .perform(get("/test/secured").param("name", JwtSecurityJKSIT.NAME).header(HttpHeaders.AUTHORIZATION, BEARER + jwt));
    }
}
