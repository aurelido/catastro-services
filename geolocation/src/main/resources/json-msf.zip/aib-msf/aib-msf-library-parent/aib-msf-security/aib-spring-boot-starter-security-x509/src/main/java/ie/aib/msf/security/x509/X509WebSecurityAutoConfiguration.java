package ie.aib.msf.security.x509;

import static org.springframework.util.StringUtils.commaDelimitedListToStringArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;

/**
 * Autoconfiguration class for mutual authentication using X509 certs and regex pattern matching
 */
@Configuration
@ComponentScan
@ConditionalOnProperty(prefix = "ie.aib.msf.security.x509", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties
public class X509WebSecurityAutoConfiguration {

    /**
     * X509 Security for user defined endpoints
     */
    @Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
    @ConditionalOnProperty(prefix = "ie.aib.msf.security.x509", name = "paths")
    @EnableWebSecurity
    class X509WebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

        private X509Properties x509Properties;

        @Autowired
        X509WebSecurityConfigurerAdapter(X509Properties x509Properties) {
            this.x509Properties = x509Properties;
        }


        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http.authorizeRequests()
                    .antMatchers(commaDelimitedListToStringArray(x509Properties.getPaths()))
                    .authenticated()
                    .and()
                    .x509()
                    .x509AuthenticationFilter(x509Filter(super.authenticationManagerBean()))
                    .userDetailsService(X509WebSecurityConfigurerAdapter.this.userDetailsService(
                            x509Properties));

            //Any server requiring mutual auth will not be web-facing. Ok to disable CSRF support.
            http.csrf().disable();
        }

        @Override
        public void configure(WebSecurity web) throws Exception {
            web.ignoring()
                    .antMatchers(commaDelimitedListToStringArray(x509Properties.getIgnoredPaths()));
        }

        private X509AuthenticationFilter x509Filter(AuthenticationManager authenticationManager) {
            X509AuthenticationFilter x509AuthenticationFilter = new X509AuthenticationFilter();
            x509AuthenticationFilter.setAuthenticationManager(authenticationManager);
            x509AuthenticationFilter.setPrincipalExtractor(principalExtractor());
            return x509AuthenticationFilter;
        }

        private X509PrincipalExtractor principalExtractor() {
            return new FullSubjectDnX509PrincipalExtractor();
        }

        private UserDetailsService userDetailsService(X509Properties x509Properties) {
            return new X509UserDetailsService(x509Properties);
        }
    }
}
