package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultClaims;
import org.junit.Test;

public class JwtAuthenticationTokenTest {

    @Test
    public void testCreateToken() {
        String username = "testUser";
        String tokenString = "testToken";
        Claims claims = new DefaultClaims();
        claims.setSubject("testSubject");
        JwtUserDetails userDetails = new JwtUserDetails(username, tokenString, claims, null);
        JwtAuthenticationToken token = new JwtAuthenticationToken(tokenString, userDetails);

        assertThat(token.getToken()).isEqualTo(tokenString);
        assertThat(token.getPrincipal()).isEqualTo(userDetails);
        assertThat(token.getClaims()).isEqualTo(claims);
        assertThat(token.getCredentials()).isEqualTo(username);
    }

    @Test
    public void testTokenEquals() {
        String username = "testUser";
        String tokenString = "testToken";
        Claims claims = new DefaultClaims();
        claims.setSubject("testSubject");
        JwtUserDetails userDetails = new JwtUserDetails(username, tokenString, claims, null);
        JwtAuthenticationToken token = new JwtAuthenticationToken(tokenString, userDetails);

        JwtUserDetails userDetails2 = new JwtUserDetails(username, tokenString, claims, null);
        JwtAuthenticationToken token2 = new JwtAuthenticationToken(tokenString, userDetails2);

        assertThat(token).isEqualTo(token2);
        assertThat(token.hashCode()).isEqualTo(token2.hashCode());
    }

    @Test
    public void testTokenNotEquals() {
        String username = "testUser";
        String tokenString = "testToken";
        Claims claims = new DefaultClaims();
        claims.setSubject("testSubject");
        JwtUserDetails userDetails = new JwtUserDetails(username, tokenString, claims, null);
        JwtAuthenticationToken token = new JwtAuthenticationToken(tokenString, userDetails);

        String tokenString2 = "someOtherToken";
        JwtUserDetails userDetails2 = new JwtUserDetails(username, tokenString2, claims, null);
        JwtAuthenticationToken token2 = new JwtAuthenticationToken(tokenString2, userDetails2);

        assertThat(token).isNotEqualTo(token2);
        assertThat(token.hashCode()).isNotEqualTo(token2.hashCode());
    }
}