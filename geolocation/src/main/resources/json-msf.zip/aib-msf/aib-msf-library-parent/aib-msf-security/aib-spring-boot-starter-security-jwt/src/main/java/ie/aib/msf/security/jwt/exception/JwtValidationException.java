package ie.aib.msf.security.jwt.exception;

import ie.aib.msf.errorhandling.ErrorCode;

@ErrorCode(code = "401-0100-0004", info = "https://wiki.aib.pri/display/MSF/Generic+Error+Codes")
public class JwtValidationException extends JwtAuthenticationException {

    public JwtValidationException(String msg) {
        super(msg);
    }
}