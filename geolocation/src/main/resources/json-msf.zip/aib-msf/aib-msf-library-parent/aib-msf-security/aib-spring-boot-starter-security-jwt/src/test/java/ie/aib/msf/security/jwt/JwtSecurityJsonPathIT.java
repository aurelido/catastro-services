package ie.aib.msf.security.jwt;

import static ie.aib.msf.security.jwt.test.JwtTestTokenGenerator.generateToken;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = JwtSecurityTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.jwt.keystore.file=classpath:test-keystore.jks",
                "ie.aib.msf.security.jwt.keyStore.alias=testKey",
                "ie.aib.msf.security.jwt.keyStore.password=password",
                "ie.aib.msf.security.jwt.user-claim=userId",
                "ie.aib.msf.security.jwt.role-claims=role",
                "ie.aib.msf.security.jwt.jsonPathExpression=$.security.jwt",
                "ie.aib.msf.security.jwt.location=BODY"})
@AutoConfigureMockMvc
public class JwtSecurityJsonPathIT {

    private static final String NAME = "test";
    private static final String USER_ID = "userId";
    private static final String ROLE = "role";

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testValidJWT() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        String jwt = generateToken(claims);
        JsonPathTestRequest jsonPathTestRequest = new JsonPathTestRequest(new JsonPathTestRequest.SecurityContext(jwt));
        ResultActions resultActions = sendRequest(jsonPathTestRequest);
        resultActions.andExpect(status().isOk());
    }

    @Test
    public void testJsonPathMissing() throws Exception {
        JsonPathTestRequest jsonPathTestRequest = new JsonPathTestRequest(null);
        ResultActions resultActions = sendRequest(jsonPathTestRequest);
        resultActions.andExpect(status().isUnauthorized());
    }

    private ResultActions sendRequest(JsonPathTestRequest request) throws Exception {
        return mockMvc.perform(post("/test/jsonpath").contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)));
    }
}
