package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import ie.aib.msf.security.jwt.test.JwtTestTokenGenerator;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = JwtSecurityTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.jwt.signingKeyBase64=test-key",
                "ie.aib.msf.security.jwt.user-claim=userId",
                "ie.aib.msf.security.jwt.role-claims=role",
                "ie.aib.msf.security.jwt.allowed-clock-skew-seconds=5",
                "security.basic.enabled=false"})
@AutoConfigureMockMvc
public class JwtSecurityBase64IT {

    private static final String BEARER = "Bearer ";
    private static final String NAME = "test";
    private static final String USER_ID = "userId";
    private static final String ROLE = "role";
    @Autowired
    private TestRestTemplate restTemplate;
    @Value("${ie.aib.msf.security.jwt.signingKeyBase64}")
    String base64EncodedSigningKey;
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testValidJWT() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        sendRequest(generateToken(claims))
                .andExpect(content().string("Hello, " + NAME));
    }

    @Test
    public void testValidJWTClassLevelJwtAnnotation() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        sendRequest("/test2/secured", NAME, generateToken(claims))
                .andExpect(content().string("Hello, " + NAME));
    }

    @Test
    public void testInvalidJWT() throws Exception {
        String jwt = "123.456.789";
        sendRequest(jwt)
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testValidJWTInvalidRole() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "NONE");
        sendRequest(generateToken(claims))
                .andExpect(status().isForbidden());
    }

    /*
        Using TestRestTemplate here because MockMvc could potentially treat trailing slashes differently to real mvc endpoints.
        This test checks that endpoints with a trailing slash a secured the same way as those without one.
     */
    @Test
    public void testValidJWTInvalidRoleTrailingSlash() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "NONE");
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + generateToken(claims));
        ResponseEntity<String> responseEntity = restTemplate
                .exchange("/test/secured/", HttpMethod.GET, new HttpEntity<>(headers), String.class);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }

    @Test
    public void testValidJWTUserAbsent() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(ROLE, "NONE");
        sendRequest(generateToken(claims))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testExpiredJWT() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        claims.put("exp", String.valueOf(
                TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1))));
        sendRequest(generateToken(claims))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testAllowedClockSkewInJWT() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        claims.put(ROLE, "USER");
        //set expiration before the current time
        claims.put("exp", String.valueOf(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - 1)));
        sendRequest(generateToken(claims))
                .andExpect(status().isOk());
    }

    @Test
    public void testHeaderPresentButTokenMissing() throws Exception {
        sendRequest("")
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testInvalidSignature() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER_ID, NAME);
        sendRequest(JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS512, "invalid-key", claims))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testOpenEndpointWithoutSecurity() throws Exception {
        mockMvc.perform(get("/test/open?name=test"))
                .andExpect(status().isOk());
    }

    //MockMvc does not propagate the error back to the handler, so can't used it to test the extra fields
    @Test
    public void testCodeAndInfoSet() {
        String path = "/test/secured";
        String response = restTemplate.getForObject(path, String.class);
        assertThat(response).isNotNull();
        DocumentContext jsonContext = JsonPath.parse(response);
        assertThat(jsonContext.read("$.code", String.class)).isEqualTo("401-0100-0003");
        assertThat(jsonContext.read("$.message", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.info", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.timestamp", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.uuid", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.error", String.class)).isEqualTo(HttpStatus.UNAUTHORIZED.getReasonPhrase());
        assertThat(jsonContext.read("$.status", Integer.class)).isEqualTo(HttpStatus.UNAUTHORIZED.value());
        assertThat(jsonContext.read("$.path", String.class)).isEqualTo(path);
    }

    private ResultActions sendRequest(String endpoint, String name, String jwt) throws Exception {
        return mockMvc.perform(get(endpoint).param("name", name).header(HttpHeaders.AUTHORIZATION, BEARER + jwt));
    }

    private ResultActions sendRequest(String jwt) throws Exception {
        return sendRequest("/test/secured", JwtSecurityBase64IT.NAME, jwt);
    }

    private String generateToken(Map<String, String> claims) {
        return JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS512, base64EncodedSigningKey, claims);
    }
}
