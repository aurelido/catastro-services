package ie.aib.msf.security.ldap;

import org.springframework.ldap.support.LdapUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;

public class GroupConvertingLdapUserDetailsMapper extends LdapUserDetailsMapper {

    private static final String ROLE_PREFIX = "ROLE_";
    private String roleAttributeKey;

    GroupConvertingLdapUserDetailsMapper(String roleAttributeKey) {
        this.roleAttributeKey = roleAttributeKey;
    }

    @Override
    protected GrantedAuthority createAuthority(Object role) {
        if (role instanceof String) {
            return new SimpleGrantedAuthority(
                    ROLE_PREFIX + LdapUtils.getStringValue(LdapUtils.newLdapName((String) role), roleAttributeKey));
        }
        return null;
    }
}
