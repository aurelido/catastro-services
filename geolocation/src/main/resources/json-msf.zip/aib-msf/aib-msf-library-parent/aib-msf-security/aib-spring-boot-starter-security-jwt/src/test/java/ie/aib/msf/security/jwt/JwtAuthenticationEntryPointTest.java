package ie.aib.msf.security.jwt;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.junit.Test;

public class JwtAuthenticationEntryPointTest {

    @Test
    public void testCommence() throws IOException {
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        new JwtAuthenticationEntryPoint().commence(null, httpServletResponse, null);
        verify(httpServletResponse, times(1)).sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
    }

}