package ie.aib.msf.security.x509;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.security.Principal;
import java.security.cert.X509Certificate;
import org.junit.Test;

public class FullSubjectDnX509PrincipalExtractorTest {

    @Test
    public void testExtractorReturnsFullDistinguishedName() {
        String testDN = "CN=test-client, OU=Test, O=AIB";
        X509Certificate certificateMock = mock(X509Certificate.class);
        Principal principal = mock(Principal.class);
        when(principal.getName()).thenReturn(testDN);
        when(certificateMock.getSubjectDN()).thenReturn(principal);

        assertThat(new FullSubjectDnX509PrincipalExtractor().extractPrincipal(certificateMock)).isEqualTo(testDN);
    }

}