package ie.aib.msf.security.jwt.exception;

import ie.aib.msf.errorhandling.ErrorCode;

@ErrorCode(code = "401-0100-0003", info = "https://wiki.aib.pri/display/MSF/Generic+Error+Codes")
public class JwtTokenMissingException extends JwtAuthenticationException {

    public JwtTokenMissingException(String s) {
        super(s);
    }
}
