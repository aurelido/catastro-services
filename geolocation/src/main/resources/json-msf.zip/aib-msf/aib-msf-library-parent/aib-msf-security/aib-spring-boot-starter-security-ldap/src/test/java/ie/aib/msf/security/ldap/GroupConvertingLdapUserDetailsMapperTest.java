package ie.aib.msf.security.ldap;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

public class GroupConvertingLdapUserDetailsMapperTest {

    @Test
    public void testCreateAuthority() {
        GroupConvertingLdapUserDetailsMapper detailsMapper = new GroupConvertingLdapUserDetailsMapper("cn");
        assertThat(detailsMapper.createAuthority("cn=testRole").getAuthority()).isEqualTo("ROLE_testRole");
        assertThat(detailsMapper.createAuthority(1)).isNull();
    }
}