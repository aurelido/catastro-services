package ie.aib.msf.security.jwt.audit;

import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import javax.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.AuthenticationDetailsSource;

/**
 * Implementation of {@link AuthenticationDetailsSource} which builds the details object
 * from a <tt>HttpServletRequest</tt> object, creating a {@code JwtWebAuthenticationDetails}
 */
public class JwtWebAuthenticationDetailsSource implements
        AuthenticationDetailsSource<HttpServletRequest, JwtWebAuthenticationDetails> {

    private boolean includeRequestUri;
    private boolean includeQueryString;

    public JwtWebAuthenticationDetailsSource(JwtSecurityProperties jwtSecurityProperties) {
        this.includeRequestUri = jwtSecurityProperties.getAudit().isIncludeRequestUri();
        this.includeQueryString = jwtSecurityProperties.getAudit().isIncludeQueryString();
    }

    @Override
    public JwtWebAuthenticationDetails buildDetails(HttpServletRequest context) {
        return new JwtWebAuthenticationDetails(context, includeRequestUri, includeQueryString);
    }
}