package ie.aib.msf.security.x509;

import java.security.cert.X509Certificate;
import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;

/**
 * Extracts the full Distinguished Name from the client certificate
 */
class FullSubjectDnX509PrincipalExtractor implements X509PrincipalExtractor {

    @Override
    public Object extractPrincipal(X509Certificate clientCert) {
        return clientCert.getSubjectDN().getName();
    }
}
