package ie.aib.msf.security.x509;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class X509UserTest {

    @Test
    public void testCreateUserWithoutProperties() {
        X509User user = new X509User("test", new ArrayList<>(), null);

        assertThat(user.getProperties()).isEmpty();
        assertThat(user.getProperty("test", String.class)).isNull();
    }

    @Test
    public void testCreateUserWithProperties() {
        Map<String, Object> properties = new HashMap<>();
        properties.put("test", "testValue");
        properties.put("testList", Collections.singletonList("testListItem"));
        X509User user = new X509User("test", new ArrayList<>(), properties);

        assertThat(user.getProperties()).hasSize(2);
        assertThat(user.getProperty("test", String.class)).isEqualTo("testValue");
        assertThat(user.getProperty("testList", List.class).get(0)).isEqualTo("testListItem");
    }
}