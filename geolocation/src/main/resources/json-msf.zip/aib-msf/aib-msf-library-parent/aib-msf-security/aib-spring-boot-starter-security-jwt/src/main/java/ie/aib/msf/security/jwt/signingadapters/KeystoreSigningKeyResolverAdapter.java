package ie.aib.msf.security.jwt.signingadapters;

import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.Assert;

public class KeystoreSigningKeyResolverAdapter extends SigningKeyResolverAdapter implements InitializingBean {

    private static final Log LOG = LogFactory.getLog(KeystoreSigningKeyResolverAdapter.class);

    private final JwtSecurityProperties jwtSecurityProperties;

    private final ResourceLoader resourceLoader;

    private PublicKey defaultPublicKey;

    private Map<String, PublicKey> keyMap = new ConcurrentHashMap<>();

    public KeystoreSigningKeyResolverAdapter(JwtSecurityProperties jwtSecurityProperties,
            ResourceLoader resourceLoader) {
        this.jwtSecurityProperties = jwtSecurityProperties;
        this.resourceLoader = resourceLoader;
    }

    @Override
    public Key resolveSigningKey(JwsHeader header, Claims claims) {
        String kid = null;
        if (header != null) {
            kid = header.getKeyId();
        }

        PublicKey signingKey;
        //use the kid, if set. If not, use the default signing key
        if (kid != null) {
            signingKey = keyMap.get(kid);
            if (signingKey == null) {
                signingKey = getPublicKeyFromKid(kid);
            }
        } else if (defaultPublicKey != null) {
            signingKey = defaultPublicKey;
        } else {
            throw new JwtTokenMalformedException("No kid specified");
        }
        return signingKey;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(jwtSecurityProperties.getKeystore(), "KeyStore properties must be set if signingKeyType is JKS");

        String alias = jwtSecurityProperties.getKeystore().getAlias();
        if (alias != null) {
            defaultPublicKey = readKey(alias);
        }
    }

    private PublicKey getPublicKeyFromKid(String kid) {
        PublicKey signingKey;
        try {
            signingKey = readKey(kid);
        } catch (KeyStoreException e) {
            LOG.error(String.format("kid: %s not valid", kid), e);
            throw new JwtTokenMalformedException(String.format("kid: %s not valid", kid));
        }
        return signingKey;
    }

    private PublicKey readKey(String alias) throws KeyStoreException {
        PublicKey key;
        KeyStore keyStore = KeyStore.getInstance(jwtSecurityProperties.getKeystore().getType());
        Resource resource = resourceLoader.getResource(jwtSecurityProperties.getKeystore().getFile());
        try (InputStream in = resource.getInputStream()) {
            keyStore.load(in, jwtSecurityProperties.getKeystore().getPassword().toCharArray());
            java.security.cert.Certificate cert = keyStore.getCertificate(alias);
            if (cert == null) {
                throw new KeyStoreException(String.format("Alias: %s not found", alias));
            }
            key = cert.getPublicKey();
            keyMap.put(alias, key);
        } catch (IOException | CertificateException | NoSuchAlgorithmException e) {
            throw new KeyStoreException(e);
        }
        return key;
    }
}
