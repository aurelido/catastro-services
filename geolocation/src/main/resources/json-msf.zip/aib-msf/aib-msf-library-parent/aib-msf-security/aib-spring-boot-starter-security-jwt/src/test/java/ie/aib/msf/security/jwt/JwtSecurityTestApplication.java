package ie.aib.msf.security.jwt;

import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class JwtSecurityTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(JwtSecurityTestApplication.class, args);
    }

    @RequestMapping("/test")
    @RestController
    static class TestController {

        @JwtAuthorization
        @PreAuthorize("hasRole('USER')")
        @GetMapping(value = "/secured")
        String secured(@RequestParam(name = "name", defaultValue = "user") String name) {
            return "Hello, " + name;
        }

        @GetMapping(value = "/open")
        String open(@RequestParam(name = "name", defaultValue = "user") String name) {
            return "Hello, " + name;
        }

        @JwtAuthorization
        @PostMapping("/jsonpath")
        void jsonPath(@RequestBody JsonPathTestRequest request) {
        }
    }

    @RequestMapping("/test2")
    @RestController
    @JwtAuthorization
    static class TestController2 {

        @GetMapping(value = "secured")
        String secured(@RequestParam(name = "name", defaultValue = "user") String name) {
            return "Hello, " + name;
        }
    }
}
