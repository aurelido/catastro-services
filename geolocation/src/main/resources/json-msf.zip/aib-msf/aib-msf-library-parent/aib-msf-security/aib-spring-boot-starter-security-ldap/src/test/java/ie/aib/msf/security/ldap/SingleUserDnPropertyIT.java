package ie.aib.msf.security.ldap;

import static org.assertj.core.api.Assertions.assertThat;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@ActiveProfiles("single-user-dn")
@SpringBootTest(classes = {TestLdapSecurityApplication.class},
        webEnvironment = WebEnvironment.NONE)
@RunWith(SpringRunner.class)
public class SingleUserDnPropertyIT {

    @Autowired
    private LdapProperties ldapProperties;

    @Test
    public void testSingleUserDNisNotSplit() throws InvalidNameException {
        assertThat(ldapProperties.getUserDn()).hasSize(1);
        assertThat(ldapProperties.getUserDn().get(0)).isEqualTo(new LdapName("cn={0},ou=STAFF,ou=USERS"));
    }
}