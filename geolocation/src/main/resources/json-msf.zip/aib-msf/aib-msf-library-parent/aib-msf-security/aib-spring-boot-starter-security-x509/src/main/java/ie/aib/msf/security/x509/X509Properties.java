package ie.aib.msf.security.x509;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * X509 starter properties
 */
@Getter
@Setter
@Component
@RefreshScope
@ConfigurationProperties(prefix = "ie.aib.msf.security.x509")
public class X509Properties {

    /**
     * Paths to secure with X509, using ANT matchers, e.g. "/**".<br/>
     * Takes a comma-separated list of paths.
     */
    private String paths;

    /**
     * Paths to ignore, using ANT matchers.
     * Useful when setting the path attribute to "/**" and excluding certain paths from it.<br/>
     * Takes a comma-separated list of paths.
     */
    private String ignoredPaths;

    /**
     * Regex(es) to specify which clients should be allowed to access protected resources,
     * based on the certificate's subject Distinguished Name. <br/>
     * <br/>
     * For example: "CN=client(1|3),(.*)OU=Test,(.*)O=AIB,(.*)C=IE" would allow clients:<br/>
     * CN=client1, OU=Test, O=AIB, C=IE or <br/>
     * CN=client3, OU=Test, O=AIB, C=IE or<br/>
     * CN=client3, OU=Test, O=AIB, L=Dublin, ST=Leinster, C=IE<br/>
     * (with or without whitespace) access to resources, but not<br/>
     * CN=client2, OU=Test, O=AIB, C=IE
     * <p/>
     * Can take a single string, or a list of strings if using multiple regex patterns. <br/>
     * In the latter case, clients will be authorized if they match any of the patterns. <br/>
     * Cannot be used if the 'clients' property is set, as they are mutually exclusive.
     */

    private List<Pattern> clientAuthorizationRegex;

    /**
     * Enable the X509 security module. True by default
     */
    private boolean enabled = true;

    /**
     * Specify a list of clients. <br/>
     * <p/>
     * These client are a way of grouping one or more clients,
     * and associating them with a regex. <br/>
     * A Map of properties is then added to the UserDetails object representing that client.
     * <p/>
     * Cannot be used if the 'clientAuthorizationRegex' property is set, as they are mutually exclusive.
     */
    private List<Client> clients;

    public void setClientAuthorizationRegex(List<Pattern> clientAuthorizationRegex) {
        Assert.isNull(clients, "clientAuthorizationRegex must not be set if clients is set");
        this.clientAuthorizationRegex = clientAuthorizationRegex;
    }

    public void setClients(List<Client> clients) {
        Assert.isNull(clientAuthorizationRegex, "clients must not be set if clientAuthorizationRegex is set");
        this.clients = clients;
    }

    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    public static class Client {

        /**
         * Name of the client
         */
        private String name;

        /**
         * Regex pattern(s) identifying the client, based on the subject's Distinguished Name. <br/>
         * Works the same way as {@link X509Properties#clientAuthorizationRegex} at the higher lever
         */
        private List<Pattern> clientAuthorizationRegex;

        /**
         * Map of properties to attach to the UserDetails object for this client.
         */
        private Map<String, Object> properties;
    }
}
