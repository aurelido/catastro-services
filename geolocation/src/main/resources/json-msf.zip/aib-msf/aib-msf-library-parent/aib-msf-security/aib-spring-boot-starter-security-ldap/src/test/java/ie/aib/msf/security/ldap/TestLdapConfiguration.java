package ie.aib.msf.security.ldap;

import javax.annotation.PreDestroy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.ldap.server.ApacheDSContainer;

@Configuration
class TestLdapConfiguration {

    private static final int LDAP_PORT = 53389;
    private static final String LDIF = "classpath:test-server.ldif";

    private static ApacheDSContainer apacheDSContainer = createApacheDSContainer();

    private static ApacheDSContainer createApacheDSContainer() {
        System.setProperty("test.ldap.url", "ldap://localhost:" + LDAP_PORT);
        ApacheDSContainer apacheDSContainer;
        try {
            apacheDSContainer = new ApacheDSContainer("o=AIB", LDIF);
            apacheDSContainer.setPort(LDAP_PORT);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return apacheDSContainer;
    }

    @Bean
    ApacheDSContainer apacheDSContainer() {
        return apacheDSContainer;
    }

    @PreDestroy
    public void stopLdapServer() {
        if (apacheDSContainer != null) {
            apacheDSContainer.stop();
        }
    }
}
