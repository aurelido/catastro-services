package ie.aib.msf.security.jwt;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = JwtSecurityTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.jwt.enabled=false",
                "security.basic.enabled=false",
                "ie.aib.msf.security.jwt.keystore.file=classpath:missing-keystore.jks",
                "ie.aib.msf.security.jwt.keystore.alias=fake"})
@AutoConfigureMockMvc
public class JwtSecurityDisabledIT {

    private static final String NAME = "test";

    @Autowired
    private MockMvc mockMvc;

    /*
    Test that keystore properties are not loaded when the starter is disabled
     */
    @Test
    public void testSecurityDisabled() throws Exception {
        mockMvc.perform(get("/test/secured").param("name", NAME))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, " + NAME));
    }
}
