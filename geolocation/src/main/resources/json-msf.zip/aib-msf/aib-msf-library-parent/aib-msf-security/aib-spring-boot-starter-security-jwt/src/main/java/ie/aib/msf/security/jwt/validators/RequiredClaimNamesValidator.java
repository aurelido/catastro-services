package ie.aib.msf.security.jwt.validators;

import ie.aib.msf.security.jwt.exception.JwtValidationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.Claims;
import java.util.HashSet;
import java.util.Set;
import org.springframework.util.StringUtils;

public class RequiredClaimNamesValidator implements ClaimsValidator {

    private final JwtSecurityProperties jwtSecurityProperties;

    public RequiredClaimNamesValidator(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
    }

    @Override
    public void validate(Claims claims) throws JwtValidationException {
        if (!claims.keySet().containsAll(jwtSecurityProperties.getRequiredClaimNames())) {
            Set<String> missingClaims = new HashSet<>(jwtSecurityProperties.getRequiredClaimNames());
            missingClaims.removeAll(claims.keySet());
            throw new JwtValidationException("Missing required claims: " + StringUtils
                    .collectionToCommaDelimitedString(missingClaims));
        }
    }
}