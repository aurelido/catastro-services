package ie.aib.msf.security.ldap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.util.StringUtils;

@SuppressWarnings("DeprecatedIsStillUsed")
@Getter
@Setter
@RefreshScope
@ConfigurationProperties(prefix = "ie.aib.msf.security.ldap")
public class LdapProperties {

    /**
     * The Distinguished Name pattern(s) to authenticate the user.
     * <p/>
     * Takes a single pattern, or a list or patterns, using yaml list format
     */
    private List<LdapName> userDn = new ArrayList<>(
            Collections.singletonList(new LdapName("cn={0},ou=ACTIVE,ou=USERS")));

    /**
     * Comma-separated list of LDAP provider urls.
     */
    private List<String> providerUrls;
    /**
     * Base distinguished name for all provider servers.
     */
    private String baseDN = "o=AIB";

    /**
     * The names of any attributes in the user's entry which represent application roles.
     */
    private List<String> roleAttributes = Collections.singletonList("groupMembership");

    /**
     * The key in the role attribute representing the group name. <br/>
     * E.g. if the role attribute value is
     * "cn=Sonar_User,ou=Sonar_Group,ou=GROUPS,o=AIB" and the key is "cn", Sonar_User will the group name
     */
    private String roleAttributeKey = "cn";

    /**
     * Paths to secure with LDAP, granting access only to members of groups specified by {@link #permittedGroups}<br/>
     * Uses ANT matchers, e.g. "/**".
     * <p/>
     * This setting and pathsToGroupsMapping are mutually exclusive.
     */

    private List<String> paths = new ArrayList<>();
    /**
     * Comma-separated list of LDAP groups permitted to access secure endpoints. <br/>
     * This should just be the group CN and not the fully qualified DN. <br/>
     * If empty, any authenticated user has permission.
     * <p/>
     * This setting and pathsToGroupsMapping are mutually exclusive.
     */
    private List<String> permittedGroups;

    /**
     * Paths available to all authenticated users, regardless of group membership.
     * <p/>
     * Access to these paths require the user to be logged in, but not to be a member of any particular group
     */
    private List<String> allAuthenticatedUsersPaths = new ArrayList<>();

    /**
     * Enable the LDAP security module. True by default
     */
    private boolean enabled = true;

    /**
     * Set a login page to redirect to. <br/>
     * If not set, a default simple login form will be used
     */
    private String loginPage;

    /**
     * Set a custom login processing url <br/>
     * This is the URL to validate the username and password <br/>
     */
    private String loginProcessingUrl;

    /**
     * Set a custom logout url
     */
    private String logoutUrl;

    @Getter(AccessLevel.NONE)
    private boolean useOpenPathsAttribute = false;


    /**
     * Secure Spring Boot's actuator endpoints with ldap
     * <p/>
     * If set to false, management.security.enabled controls access to the endpoints.<br/>
     * To disable actuator security entirely, set both values to false
     */
    private boolean secureActuatorEndpoints = false;

    /**
     * Mapping of paths to the groups that are allowed to access them.
     * <p/>
     * Each path is evaluated in order, so they should be defined from most to least specific.
     * <p/>
     * e.g<pre>
     * pathsToGroupsMapping
     *   - paths: /test/123
     *     groups: admins,operators
     *   - paths: /test/**
     *     groups: admins,developers
     *   - paths: /**
     *     groups admins,developers,operators
     * </pre>
     * Would mean that admins and operators can access /test/123, but admins and developers can
     * access everything else below /test, whereas admins, deveopers and operators could access every other path.
     * <p/>
     * This setting and paths/permittedGroups are mutually exclusive.
     */
    private List<PathMapping> pathsToGroupsMapping;

    /**
     * Paths to permit access on without being authenticated <br/>
     * <p/>
     * This is necessary when using a custom form, where you want to serve html, css, etc for the form
     *
     * @deprecated use {@link #openPaths} instead
     */
    @Deprecated
    private List<String> permittedPaths = Arrays
            .asList(StringUtils.commaDelimitedListToStringArray("/login.html,/**/*.css,/login,/logout,/info,/health"));

    public LdapProperties() throws InvalidNameException {
        //empty constructor. Required because member initialization can throw exception
    }

    /**
     * Paths to permit access on without being authenticated <br/>
     * <p/>
     *
     * @deprecated use openPaths instead
     */
    @Deprecated
    public List<String> getPermittedPaths() {
        return openPaths;
    }

    /**
     * Paths to permit access on without being authenticated <br/>
     * <p/>
     * This is necessary when using a custom form, where you want to serve html, css, etc for the form
     *
     * @deprecated use openPaths instead
     */
    @Deprecated
    public void setPermittedPaths(List<String> permittedPaths) {
        this.permittedPaths = permittedPaths;
        //openPaths takes precedence since it's the newer property
        if (!useOpenPathsAttribute) {
            this.openPaths = permittedPaths;
        }
    }

    /**
     * Paths to permit access on without being authenticated <br/>
     * <p/>
     * This is necessary when using a custom form, where you want to serve html, css, etc for the form
     */
    private List<String> openPaths = permittedPaths;

    /**
     * Paths to permit access on without being authenticated <br/>
     * <p/>
     * This is necessary when using a custom form, where you want to serve html, css, etc for the form
     */
    public void setOpenPaths(List<String> openPaths) {
        //attribute has been explicitly set, so user is using the new attribute instead of the old one.
        this.useOpenPathsAttribute = true;
        this.openPaths = openPaths;
    }

    public String[] getUserDnArray() {
        List<String> userDnList = new ArrayList<>();
        for (LdapName ldapName : userDn) {
            userDnList.add(ldapName.toString());
        }
        return userDnList.toArray(new String[0]);
    }

    /**
     * Set the base distinguished name.
     * <p/>
     * This method exists to allow the format base-dn as well as base-d-n.<br/>
     * Previously it was inconsistent with userDN
     * @param baseDn the baseDn
     */
    public void setBaseDn(String baseDn) {
        this.baseDN = baseDn;
    }

    /**
     * Set the base distinguished name.
     * <p/>
     * This method exists to allow the format base-dn as well as base-d-n.<br/>
     * Previously it was inconsistent with userDN
     * @param baseDN the baseDN
     */
    public void setBaseDN(String baseDN) {
        this.setBaseDn(baseDN);
    }

    /**
     * Set the user distinguished name.
     * <p/>
     * This method exists to allow the format user-dn as well as user-d-n.<br/>
     * Previously it was inconsistent with baseDN
     * @param userDN the userDN
     */
    public void setUserDN(List<LdapName> userDN) {
        this.userDn = userDN;
    }

    public void setUserDn(List<LdapName> userDn) {
        this.setUserDN(userDn);
    }

    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    public static class PathMapping {

        private List<String> paths = new ArrayList<>();
        private List<String> groups = new ArrayList<>();
    }
}