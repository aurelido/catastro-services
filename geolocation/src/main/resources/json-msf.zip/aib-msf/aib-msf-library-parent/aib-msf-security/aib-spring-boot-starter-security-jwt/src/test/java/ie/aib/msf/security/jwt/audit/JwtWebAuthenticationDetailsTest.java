package ie.aib.msf.security.jwt.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import org.junit.Before;
import org.junit.Test;

public class JwtWebAuthenticationDetailsTest {

    private static final String REQUEST_URI = "/test";
    private static final String QUERY_STRING = "name=test";
    private HttpServletRequest request;

    @Before
    public void setup() {
        request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn(REQUEST_URI);
        when(request.getQueryString()).thenReturn(QUERY_STRING);
    }

    @Test
    public void testCreateAuthenticationDetails() {

        JwtWebAuthenticationDetails details = new JwtWebAuthenticationDetails(request, true, true);
        assertThat(details.getRequestUri()).isEqualTo(REQUEST_URI);
        assertThat(details.getQueryString()).isEqualTo(QUERY_STRING);
        assertThat(details.toString()).contains("RequestURI: " + REQUEST_URI);
        assertThat(details.toString()).contains("QueryString: " + QUERY_STRING);
    }

    @Test
    public void testCreateAuthenticationDetailsValuesSuppressed() {

        JwtWebAuthenticationDetails details = new JwtWebAuthenticationDetails(request, false, false);
        assertThat(details.getRequestUri()).isNull();
        assertThat(details.getQueryString()).isNull();
    }
}