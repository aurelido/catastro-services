package ie.aib.msf.security.jwt.extractors;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import ie.aib.msf.security.jwt.JwtExtractor;
import ie.aib.msf.security.jwt.MultipleReadRequestWrapper;
import ie.aib.msf.security.jwt.exception.JwtTokenMissingException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import java.nio.charset.StandardCharsets;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * JwtExtractor for parsing the JWT from the both of an incoming request using JsonPath expressions
 */
public class JsonPathJwtExtractor implements JwtExtractor {

    private static final Log LOGGER = LogFactory.getLog(JsonPathJwtExtractor.class);

    private JwtSecurityProperties jwtSecurityProperties;

    @SuppressWarnings("SpringJavaAutowiredMembersInspection")
    @Autowired
    public JsonPathJwtExtractor(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
        Assert.hasText(jwtSecurityProperties.getJsonPathExpression(), "JSON Path Expression must be set.");
    }

    @Override
    public String extractJwt(HttpServletRequest request, HttpServletResponse response) {
        String jwt;
        try {
            byte[] bytes = ((MultipleReadRequestWrapper) request).getContentAsByteArray();
            String content = new String(bytes, StandardCharsets.UTF_8);
            DocumentContext jsonContext = JsonPath.parse(content);
            jwt = jsonContext.read(jwtSecurityProperties.getJsonPathExpression(), String.class);
        } catch (Exception e) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Failed to parse JWT from request body", e);
            }
            throw new JwtTokenMissingException("Failed to read JWT from request body");
        }

        if (StringUtils.isEmpty(jwt)) {
            throw new JwtTokenMissingException("JWT is empty");
        }
        return jwt;
    }
}
