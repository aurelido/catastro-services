package ie.aib.msf.security.ldap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * Convert a String to an list of LdapNames
 * <p/>
 * This converter stops Spring from converting a string with commas into a list before converting to LDAP
 * E.g. cn={0},ou=ACTIVE,ou=USERS would become a list with 1 element instead of 3
 */
@Component
@ConfigurationPropertiesBinding
public class StringToLdapNameListConverter implements Converter<String, List<LdapName>> {

    @Override
    public List<LdapName> convert(String source) {
        try {
            //can't return the singleton list directly, as it needs to be mutable
            return new ArrayList<>(Collections.singletonList(new LdapName(source)));
        } catch (InvalidNameException e) {
            throw new IllegalArgumentException(
                    String.format("failed to parse ldap name: %s message:%s", source, e.getMessage()), e);
        }
    }
}