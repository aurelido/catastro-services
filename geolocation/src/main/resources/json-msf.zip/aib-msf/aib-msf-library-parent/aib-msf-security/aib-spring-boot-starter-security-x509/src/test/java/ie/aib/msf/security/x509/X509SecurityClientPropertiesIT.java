package ie.aib.msf.security.x509;

import static ie.aib.msf.security.x509.TestX509SecurityApplication.PRINCIPAL_ENDPOINT;
import static ie.aib.msf.security.x509.X509TestUtil.configureRestTemplate;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestX509SecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"spring.profiles.active=clientlist", "server.ssl.client-auth=need"})
@DirtiesContext
public class X509SecurityClientPropertiesIT {

    @SuppressWarnings("WeakerAccess")
    @Autowired
    TestRestTemplate restTemplate;

    @SuppressWarnings("unchecked")
    @Test
    public void testTrustedClientMatchingRegex() throws Exception {
        //Given: a keystore with a trusted cert that matches the regex
        configureRestTemplate(restTemplate, "classpath:x509-client1-keystore.jks");

        //When: The client requests a secured resource
        ResponseEntity<Map> responseEntity = restTemplate.getForEntity(PRINCIPAL_ENDPOINT, Map.class);

        //Then: Access is granted and the response is returned
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().get("testProperty")).isEqualTo("testValue");
        assertThat((Map<String, Object>) responseEntity.getBody().get("listProperty")).hasSize(2);
    }

    @Test
    public void testTrustedClientNotMatchingRegex() throws Exception {
        //Given: a keystore with a trusted cert that does not matches the regex
        configureRestTemplate(restTemplate, "classpath:x509-client2-keystore.jks");

        //When: The client requests a secured resource
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(PRINCIPAL_ENDPOINT, String.class);

        //Then: Access is forbidden
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }
}
