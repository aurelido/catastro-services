package ie.aib.msf.security.x509;

import static ie.aib.msf.security.x509.TestX509SecurityApplication.OPEN_ENDPOINT;
import static ie.aib.msf.security.x509.TestX509SecurityApplication.RESPONSE;
import static ie.aib.msf.security.x509.TestX509SecurityApplication.TEST_ENDPOINT;
import static ie.aib.msf.security.x509.X509TestUtil.configureRestTemplate;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestX509SecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"spring.profiles.active=clientregex","server.ssl.client-auth=want"})
@DirtiesContext
public class X509SecurityClientAuthWantedIT {

    @SuppressWarnings("WeakerAccess")
    @Autowired
    TestRestTemplate restTemplate;

    @Test
    public void testTrustedClientMatchingRegex() throws Exception {
        //Given: a keystore with a trusted cert that matches the regex
        configureRestTemplate(restTemplate, "classpath:x509-client1-keystore.jks");

        //When: The client requests a secured resource
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(TEST_ENDPOINT, String.class);

        //Then: Access is granted and the response is returned
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody()).isEqualTo(RESPONSE);
    }

    @Test
    public void testUntrustedClient() throws Exception {
        //Given: a keystore with an untrusted cert, but with a DN matching the regex
        configureRestTemplate(restTemplate, "classpath:x509-client3-keystore.jks");

        //When: The client requests a secured resource
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(TEST_ENDPOINT, String.class);

        //Then: Access is forbidden
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }

    @Test
    public void testUntrustedClientOpenEndpoint() throws Exception {
        //Given: a keystore with an untrusted cert, but with a DN matching the regex
        configureRestTemplate(restTemplate, "classpath:x509-client3-keystore.jks");

        //When: The client requests an open resource
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(OPEN_ENDPOINT, String.class);

        //Then: Access is granted and the response is returned
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody()).isEqualTo(RESPONSE);
    }
}
