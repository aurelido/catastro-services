package ie.aib.msf.security.jwt.exception;

import ie.aib.msf.errorhandling.ErrorCode;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("unused")
@ErrorCode(code = "401-0100-0005", info = "https://wiki.aib.pri/display/MSF/Generic+Error+Codes")
@ResponseStatus(HttpStatus.FORBIDDEN)
public class JwtAuthorizationException extends AccessDeniedException {

    public JwtAuthorizationException(String msg) {
        super(msg);
    }

    public JwtAuthorizationException(String msg, Throwable t) {
        super(msg, t);
    }
}