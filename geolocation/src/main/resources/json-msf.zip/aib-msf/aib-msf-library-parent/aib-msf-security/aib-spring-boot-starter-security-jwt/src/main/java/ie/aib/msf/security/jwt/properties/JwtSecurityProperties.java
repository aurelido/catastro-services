package ie.aib.msf.security.jwt.properties;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import java.util.Map;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Getter
@Setter
@ConfigurationProperties("ie.aib.msf.security.jwt")
public class JwtSecurityProperties {

    /**
     * Signing Key in Base64 format, set if using HS signatures.
     * Required if using a Base64 encoded symmetric key
     */
    private String signingKeyBase64;

    /**
     * JWT claim containing the user ID
     */
    private String userClaim = "user";

    /**
     * JWT claims containing roles, takes a comma-separated list
     */
    private String roleClaims = "role";

    /**
     * Name of the HTTP header containing the JWT
     */
    private String headerName = AUTHORIZATION;

    /**
     * Prefix of the header value containing the JWT, Usually "Bearer"
     */
    private String headerPrefix = "Bearer";

    /**
     * Keystore properties for the JWT public key
     */
    private KeyStore keystore;

    /**
     * If the JWT is present in the body of the request, set a JSON Path expression to extract it.
     * The property will only be used if location is set to {@link JwtLocation#BODY}
     */
    private String jsonPathExpression;

    /**
     * Location of the JWT in the incoming request
     */
    private JwtLocation location = JwtLocation.HEADER;
    private boolean enabled = true;
    /**
     * The allowed clock skew in seconds
     */
    private long allowedClockSkewSeconds = 0L;

    /**
     * Map of claim names to their expected values
     */
    private Map<String, Object> expectedClaims;

    /**
     * Suppress the detailed message in error responses
     */
    private boolean suppressErrorMessageDetail = false;

    private Audit audit = new Audit();

    /**
     * Claims that must be present in the JWT
     */
    private Set<String> requiredClaimNames;

    public enum JwtLocation {
        HEADER,
        BODY
    }

    /**
     * Keystore properties for JWT public key
     * Required if using a JKS file containing the public key
     */
    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    public static class KeyStore {

        /**
         * Keystore type
         */
        private String type = "JKS";
        /**
         * Keystore file location
         */
        private String file;
        /**
         * Keystore password
         */
        private String password;
        /**
         * Default Key alias if no kid set in JWT header.
         * If not set, kid becomes a required header.
         */
        private String alias;
    }

    /**
     * Audit event properties
     */
    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    public static class Audit {

        /**
         * Enabled audit events. <br/>
         * <p/>
         * This applies to AuthN/AuthZ events thrown by the security filters. <br/>
         * AuthZ events thrown from business logic
         * (e.g. using {@link org.springframework.security.access.prepost.PreAuthorize} annotations)
         * use a different mechanism, and can only be disabled by disabling the endpoint entirely with: <br/>
         * {@code endpoints.auditevents.enabled=false}
         */
        private boolean enabled = true;

        /**
         * Include the requested uri
         */
        private boolean includeRequestUri;

        /**
         * Include the query string
         */
        private boolean includeQueryString;
    }
}
