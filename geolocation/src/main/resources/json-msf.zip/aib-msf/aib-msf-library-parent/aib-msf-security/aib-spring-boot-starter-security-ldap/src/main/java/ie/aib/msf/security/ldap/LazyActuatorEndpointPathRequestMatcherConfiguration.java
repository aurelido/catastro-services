package ie.aib.msf.security.ldap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.springframework.boot.actuate.autoconfigure.ManagementContextResolver;
import org.springframework.boot.actuate.autoconfigure.ManagementServerProperties;
import org.springframework.boot.actuate.endpoint.mvc.EndpointHandlerMapping;
import org.springframework.boot.actuate.endpoint.mvc.MvcEndpoint;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.util.StringUtils;

/**
 * This class is based on {@link org.springframework.boot.actuate.autoconfigure.ManagementWebSecurityAutoConfiguration}
 * <p/>
 * Management/Actuator endpoints need to be resolved lazily, because they are not loaded by the time Spring Security is initialised <br/>
 * This class resolves all actuator endpoints at runtime, whether they have been moved to a different path or not
 */
class LazyActuatorEndpointPathRequestMatcherConfiguration implements RequestMatcher {

    private static final String[] NO_PATHS = new String[0];

    private static final RequestMatcher MATCH_NONE = new NegatedRequestMatcher(
            AnyRequestMatcher.INSTANCE);

    private final ManagementContextResolver contextResolver;

    private RequestMatcher delegate;

    static RequestMatcher getRequestMatcher(ManagementContextResolver contextResolver) {
        if (contextResolver == null) {
            return null;
        }
        ManagementServerProperties management = contextResolver
                .getApplicationContext().getBean(ManagementServerProperties.class);
        ServerProperties server = contextResolver.getApplicationContext().getBean(ServerProperties.class);
        String path = management.getContextPath();
        if (StringUtils.hasText(path)) {
            return new AntPathRequestMatcher(server.getPath(path) + "/**");
        }
        return new LazyActuatorEndpointPathRequestMatcherConfiguration(contextResolver);
    }

    private LazyActuatorEndpointPathRequestMatcherConfiguration(ManagementContextResolver contextResolver) {
        this.contextResolver = contextResolver;
    }

    @Override
    public boolean matches(HttpServletRequest request) {
        if (this.delegate == null) {
            this.delegate = createDelegate();
        }
        return this.delegate.matches(request);
    }

    private RequestMatcher createDelegate() {
        ServerProperties server = this.contextResolver.getApplicationContext()
                .getBean(ServerProperties.class);
        List<RequestMatcher> matchers = new ArrayList<>();
        EndpointHandlerMapping endpointHandlerMapping = getRequiredEndpointHandlerMapping();
        for (String path : this.getPaths(endpointHandlerMapping)) {
            matchers.add(new AntPathRequestMatcher(server.getPath(path)));
        }
        return (matchers.isEmpty() ? MATCH_NONE : new OrRequestMatcher(matchers));
    }

    private EndpointHandlerMapping getRequiredEndpointHandlerMapping() {
        EndpointHandlerMapping endpointHandlerMapping = null;
        ApplicationContext context = this.contextResolver.getApplicationContext();
        if (context.getBeanNamesForType(EndpointHandlerMapping.class).length > 0) {
            endpointHandlerMapping = context.getBean(EndpointHandlerMapping.class);
        }
        if (endpointHandlerMapping == null) {
            // Maybe there are actually no endpoints (e.g. management.port=-1)
            endpointHandlerMapping = new EndpointHandlerMapping(
                    Collections.<MvcEndpoint>emptySet());
        }
        return endpointHandlerMapping;
    }

    private String[] getPaths(EndpointHandlerMapping endpointHandlerMapping) {
        if (endpointHandlerMapping == null) {
            return NO_PATHS;
        }
        Set<? extends MvcEndpoint> endpoints = endpointHandlerMapping.getEndpoints();
        Set<String> paths = new LinkedHashSet<>(endpoints.size());
        for (MvcEndpoint endpoint : endpoints) {
            String path = endpointHandlerMapping.getPath(endpoint.getPath());
            paths.add(path);
            if (!path.equals("")) {
                paths.add(path + "/**");
                // Add Spring MVC-generated additional paths
                paths.add(path + ".*");
            }
            paths.add(path + "/");
        }
        return paths.toArray(new String[0]);
    }
}