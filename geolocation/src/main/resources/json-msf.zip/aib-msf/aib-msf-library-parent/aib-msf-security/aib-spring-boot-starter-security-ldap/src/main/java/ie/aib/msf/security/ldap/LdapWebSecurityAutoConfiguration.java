package ie.aib.msf.security.ldap;

import static org.springframework.util.CollectionUtils.isEmpty;

import ie.aib.msf.security.ldap.LdapProperties.PathMapping;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.ManagementContextResolver;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
@Configuration
@EnableConfigurationProperties(LdapProperties.class)
@ConditionalOnProperty(prefix = "ie.aib.msf.security.ldap", name = "enabled", matchIfMissing = true)
@ComponentScan
public class LdapWebSecurityAutoConfiguration extends AbstractLdapAutoConfiguration {

    private static final Log LOGGER = LogFactory.getLog(LdapWebSecurityAutoConfiguration.class);

    @Autowired
    public LdapWebSecurityAutoConfiguration(LdapProperties ldapProperties) {
        super(ldapProperties);
    }

    /**
     * LDAP Security for user defined endpoints
     */
    @SuppressWarnings({"SpringJavaInjectionPointsAutowiringInspection", "deprecation"})
    @Configuration
    @EnableWebSecurity
    @Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
    static class LdapWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

        final BaseLdapPathContextSource contextSource;
        final LdapProperties ldapProperties;
        private ManagementContextResolver contextResolver;
        private AuthenticationSuccessHandler successHandler;
        private AuthenticationFailureHandler failureHandler;


        @Autowired
        public LdapWebSecurityConfigurerAdapter(BaseLdapPathContextSource contextSource,
                LdapProperties ldapProperties,
                ObjectProvider<ManagementContextResolver> contextResolver,
                @Autowired(required = false) AuthenticationSuccessHandler successHandler,
                @Autowired(required = false) AuthenticationFailureHandler failureHandler) {
            this.contextSource = contextSource;
            this.ldapProperties = ldapProperties;
            this.contextResolver = contextResolver.getIfAvailable();
            this.successHandler = successHandler;
            this.failureHandler = failureHandler;
        }

        @Override
        protected void configure(AuthenticationManagerBuilder auth) throws Exception {
            configureAuth(ldapProperties, auth, contextSource);
        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            configureSecurity(ldapProperties, http, contextResolver, successHandler, failureHandler);
        }

        private static void configureAuth(LdapProperties ldapProperties, AuthenticationManagerBuilder auth,
                BaseLdapPathContextSource contextSource) throws Exception {
            auth.ldapAuthentication()
                    .contextSource(contextSource)
                    .userDnPatterns(ldapProperties.getUserDnArray())
                    .groupSearchBase(null)
                    .userDetailsContextMapper(ldapUserDetailsContextMapper(ldapProperties));
        }

        private static void configureSecurity(LdapProperties ldapProperties, HttpSecurity http,
                ManagementContextResolver contextResolver, AuthenticationSuccessHandler successHandler,
                AuthenticationFailureHandler failureHandler)
                throws Exception {
            setupOpenPaths(ldapProperties, http);
            setupOpenActuatorPaths(ldapProperties, http, contextResolver);
            setupPathsToGroups(ldapProperties, http);
            setupAllAuthenticatedUsersPaths(ldapProperties, http);
            //deny everything unless it's been explicitly allowed
            http.authorizeRequests().antMatchers("/**/*").denyAll();
            configureLoginAndLogout(ldapProperties, http, successHandler, failureHandler);
            http.csrf().disable();

            if (isEmpty(ldapProperties.getPaths()) && isEmpty(ldapProperties.getPathsToGroupsMapping())) {
                LOGGER.warn("No values for 'paths' or 'pathsToGroupsMapping'. "
                        + "Only paths defined by 'openPaths'/'permittedPaths' or 'allAuthenticatedUsersPaths'"
                        + " will be accessible");
            }
        }

        private static void setupOpenPaths(LdapProperties ldapProperties, HttpSecurity http) throws Exception {
            if (!isEmpty(ldapProperties.getOpenPaths())) {
                http.authorizeRequests()
                        .antMatchers(ldapProperties.getOpenPaths().toArray(new String[0]))
                        .permitAll();
            }
        }

        /*
            Disable/enabled LDAP security on actuator endpoints depending on configuration property
         */
        private static void setupOpenActuatorPaths(LdapProperties ldapProperties, HttpSecurity http,
                ManagementContextResolver contextResolver)
                throws Exception {
            if (!ldapProperties.isSecureActuatorEndpoints()) {
                http.authorizeRequests().requestMatchers(
                        LazyActuatorEndpointPathRequestMatcherConfiguration.getRequestMatcher(contextResolver))
                        .permitAll();
            }
        }

        private static void setupAllAuthenticatedUsersPaths(LdapProperties ldapProperties, HttpSecurity http)
                throws Exception {
            if (!isEmpty(ldapProperties.getAllAuthenticatedUsersPaths())) {
                List<RequestMatcher> requestMatchers = new ArrayList<>();

                for (String path : ldapProperties.getAllAuthenticatedUsersPaths()) {
                    requestMatchers.add(new AntPathRequestMatcher(path));
                }
                //allow any authenticated user to view these paths
                http.authorizeRequests()
                        .requestMatchers(new OrRequestMatcher(requestMatchers))
                        .authenticated();
            }
        }

        private static void setupPathsToGroups(LdapProperties ldapProperties, HttpSecurity http) throws Exception {
            Assert.isTrue(isEmpty(ldapProperties.getPaths()) || isEmpty(ldapProperties.getPathsToGroupsMapping()),
                    "paths/permittedGroups and pathsToGroupsMapping are mutually exclusive. Please use only one.");

            if (!isEmpty(ldapProperties.getPaths()) && !isEmpty(ldapProperties.getPermittedGroups())) {
                authorizePathsWithGroups(http, ldapProperties.getPaths(), ldapProperties.getPermittedGroups());
            } else if (!isEmpty(ldapProperties.getPathsToGroupsMapping())) {
                for (PathMapping pathMapping : ldapProperties.getPathsToGroupsMapping()) {
                    authorizePathsWithGroups(http, pathMapping.getPaths(), pathMapping.getGroups());
                }
            }
        }

        private static void authorizePathsWithGroups(HttpSecurity http, List<String> paths, List<String> groups)
                throws Exception {
            http.authorizeRequests().antMatchers(paths.toArray(new String[0]))
                    .hasAnyRole(groups.toArray(new String[0]));
        }

        private static void configureLoginAndLogout(LdapProperties ldapProperties, HttpSecurity http,
                AuthenticationSuccessHandler successHandler, AuthenticationFailureHandler failureHandler)
                throws Exception {
            FormLoginConfigurer<HttpSecurity> loginConfigurer = http.formLogin().permitAll();

            if (successHandler != null) {
                loginConfigurer.successHandler(successHandler);
            }

            if (failureHandler != null) {
                loginConfigurer.failureHandler(failureHandler);
            }

            if (!StringUtils.isEmpty(ldapProperties.getLoginProcessingUrl())) {
                loginConfigurer.loginProcessingUrl(ldapProperties.getLoginProcessingUrl());
            }

            if (!StringUtils.isEmpty(ldapProperties.getLoginPage())) {
                loginConfigurer.loginPage(ldapProperties.getLoginPage());
            }

            if (!StringUtils.isEmpty(ldapProperties.getLogoutUrl())) {
                http.logout().logoutUrl(ldapProperties.getLogoutUrl()).permitAll();
            }
        }
    }
}