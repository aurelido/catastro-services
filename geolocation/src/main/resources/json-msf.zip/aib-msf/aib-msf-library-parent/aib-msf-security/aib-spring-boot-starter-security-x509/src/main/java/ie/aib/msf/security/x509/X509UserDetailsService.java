package ie.aib.msf.security.x509;

import ie.aib.msf.security.x509.X509Properties.Client;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * {@link UserDetailsService} for X509 certificates
 * <p/>
 * Returns a user only if the username (usually the full DN) matches the specified regex
 */
class X509UserDetailsService implements UserDetailsService {

    private X509Properties x509Properties;

    X509UserDetailsService(X509Properties x509Properties) {
        this.x509Properties = x509Properties;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Client client = validateAuthorizationAndFindClient(username);

        Map<String, Object> clientProperties = null;
        if (client != null) {
            clientProperties = client.getProperties();
        }
        return new X509User(username,
                AuthorityUtils.commaSeparatedStringToAuthorityList(""), clientProperties);
    }

    /*
        Validate that the username matches one of the supplied authorization regex values.
        If it uses the clients property, then return the relevant client.
     */
    private Client validateAuthorizationAndFindClient(String username) {
        Client matchingClient = null;
        if (x509Properties.getClientAuthorizationRegex() != null) {
            if (!findMatch(x509Properties.getClientAuthorizationRegex(), username)) {
                throw badCredentials(username);
            }
        } else if (x509Properties.getClients() != null) {
            matchingClient = x509Properties.getClients()
                    .stream()
                    .filter(client -> findMatch(client.getClientAuthorizationRegex(), username))
                    .findFirst()
                    .orElseThrow(() -> badCredentials(username));
        }
        return matchingClient;
    }

    private BadCredentialsException badCredentials(String username) {
        return new BadCredentialsException(
                String.format("Subject %s does not match the allowed clients", username));
    }

    private boolean findMatch(List<Pattern> clientAuthorizationPatterns, String username) {
        return clientAuthorizationPatterns.stream().anyMatch(pattern -> pattern.matcher(username).find());
    }
}
