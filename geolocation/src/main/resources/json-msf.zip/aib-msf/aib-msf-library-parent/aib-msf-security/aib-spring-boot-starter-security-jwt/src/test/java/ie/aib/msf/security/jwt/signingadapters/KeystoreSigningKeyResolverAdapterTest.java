package ie.aib.msf.security.jwt.signingadapters;

import static org.assertj.core.api.Assertions.assertThat;

import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultJwsHeader;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

public class KeystoreSigningKeyResolverAdapterTest {

    private static final String KEYSTORE_FILE = "classpath:test-keystore.jks";
    private static final String KEYSTORE_PASSWORD = "password";

    private static KeystoreSigningKeyResolverAdapter resolverAdapter;
    private static ResourceLoader resourceLoader;

    @BeforeClass
    public static void setup() throws Exception {
        JwtSecurityProperties jwtSecurityProperties = new JwtSecurityProperties();
        JwtSecurityProperties.KeyStore keystore = new JwtSecurityProperties.KeyStore();
        keystore.setFile(KEYSTORE_FILE);
        keystore.setAlias("testKey");
        keystore.setPassword(KEYSTORE_PASSWORD);
        jwtSecurityProperties.setKeystore(keystore);
        resourceLoader = new DefaultResourceLoader();
        resolverAdapter = new KeystoreSigningKeyResolverAdapter(jwtSecurityProperties, resourceLoader);
        resolverAdapter.afterPropertiesSet();
    }

    @Test
    public void testResolveDefaultSigningKey() throws Exception {
        Key key = resolverAdapter.resolveSigningKey(null, (Claims) null);
        assertThat(key).isNotNull();
        assertThat(key).isEqualTo(getKey("testKey"));
    }

    @Test
    public void testResolveSigningKeySpecifiedKid() throws Exception {
        DefaultJwsHeader jwsHeader = new DefaultJwsHeader();
        String kid = "testKey2";
        jwsHeader.setKeyId(kid);
        Key key = resolverAdapter.resolveSigningKey(jwsHeader, (Claims) null);
        assertThat(key).isNotNull();
        assertThat(key).isEqualTo(getKey(kid));
    }

    @Test(expected = JwtTokenMalformedException.class)
    public void testResolveSigningKeyInvalidKid() throws Exception {
        DefaultJwsHeader jwsHeader = new DefaultJwsHeader();
        String kid = "wrongTestKey";
        jwsHeader.setKeyId(kid);
        resolverAdapter.resolveSigningKey(jwsHeader, (Claims) null);
    }

    private Key getKey(String alias) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("JKS");
        Resource resource = resourceLoader.getResource(KEYSTORE_FILE);
        Key publicKey;
        try (InputStream in = resource.getInputStream()) {
            keyStore.load(in, KEYSTORE_PASSWORD.toCharArray());
            publicKey = keyStore.getCertificate(alias).getPublicKey();
        }

        return publicKey;
    }

}