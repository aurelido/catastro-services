package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import ie.aib.msf.security.jwt.exception.JwtValidationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.signingadapters.Base64SigningKeyResolver;
import ie.aib.msf.security.jwt.test.JwtTestTokenGenerator;
import ie.aib.msf.security.jwt.validators.ClaimsValidator;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SigningKeyResolver;
import io.jsonwebtoken.impl.DefaultJwsHeader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class DefaultJwtValidatorImplTest {

    private static final String TEST_KEY = "test-key";
    private static DefaultJwtValidatorImpl jwtValidator;
    private static JwtSecurityProperties jwtSecurityProperties;
    private static SigningKeyResolver signingKeyResolver;

    @BeforeClass
    public static void setup() {
        jwtSecurityProperties = new JwtSecurityProperties();
        jwtSecurityProperties.setSigningKeyBase64(TEST_KEY);
        Map<String, Object> expectedClaims = new HashMap<>();
        expectedClaims.put("aud", "test");
        jwtSecurityProperties.setExpectedClaims(expectedClaims);
        signingKeyResolver = new Base64SigningKeyResolver(jwtSecurityProperties);
        jwtValidator = new DefaultJwtValidatorImpl(signingKeyResolver, jwtSecurityProperties, null);
    }

    @Test
    public void parseToken() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put("user", "test-user");
        claims.put("role", "USER");
        claims.put("aud", "test");
        String token = generateToken(claims);
        JwtUserDetails jwtUserDetails = jwtValidator.validateAndParseToken(token);
        assertNotNull(jwtUserDetails);
        assertEquals("test-user", jwtUserDetails.getUsername());
        assertEquals(token, jwtUserDetails.getToken());
        assertTrue(jwtUserDetails.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_USER")));
    }

    @Test(expected = JwtTokenMalformedException.class)
    public void parseTokenMalformed() throws Exception {
        jwtValidator.validateAndParseToken("Malformed");
    }

    @Test(expected = JwtTokenMalformedException.class)
    public void parseTokenWithNoneAlgorithmFails() throws Exception {
        Map<String, String> claimMap = new HashMap<>();
        claimMap.put("user", "test-user");
        claimMap.put("role", "USER");
        claimMap.put("aud", "test");

        Claims claims = Jwts.claims();
        claims.putAll(claimMap);
        JwtBuilder jwtBuilder = Jwts.builder().setClaims(claims);
        DefaultJwsHeader jwsHeader = new DefaultJwsHeader();
        jwsHeader.setAlgorithm(SignatureAlgorithm.NONE.getValue());
        String token = jwtBuilder.setHeader((Map<String, Object>) jwsHeader).compact();
        jwtValidator.validateAndParseToken(token);
    }

    @Test(expected = JwtValidationException.class)
    public void testExpectedClaimsNotMatched() {
        Map<String, String> claims = new HashMap<>();
        claims.put("user", "test-user");
        claims.put("role", "USER");
        claims.put("aud", "badvalue");
        String token = generateToken(claims);
        jwtValidator.validateAndParseToken(token);
    }

    @Test(expected = JwtValidationException.class)
    public void testCustomValidatorFails() {
        testCustomValidator("badValue");
    }

    @Test
    public void testCustomValidatorPasses() {
        assertThat(testCustomValidator("validValue")).isNotNull();
    }

    private JwtUserDetails testCustomValidator(String expectedValue) {
        ClaimsValidator claimsValidator = claims -> {
            if(!claims.get("validationClaim").equals(expectedValue)) {
                throw new JwtValidationException("Custom validator");
            }
        };

        List<ClaimsValidator> validators = new ArrayList<>();
        validators.add(claimsValidator);

        JwtValidator customClaimsJwtValidator = new DefaultJwtValidatorImpl(signingKeyResolver,
                jwtSecurityProperties, validators);

        Map<String, String> claims = new HashMap<>();
        claims.put("user", "test-user");
        claims.put("role", "USER");
        claims.put("aud", "test");
        claims.put("validationClaim", "validValue");
        String token = generateToken(claims);
        return customClaimsJwtValidator.validateAndParseToken(token);
    }

    private String generateToken(Map<String, String> claims) {
        return JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS512, TEST_KEY, claims);
    }

}