package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.Authentication;

public class JwtAuthenticationProviderTest {

    private JwtAuthenticationProvider jwtAuthenticationProvider;
    private JwtValidator jwtValidator = mock(JwtValidator.class);
    private JwtUserDetails jwtUserDetails = mock(JwtUserDetails.class);

    @Before
    public void before() {
        jwtAuthenticationProvider = new JwtAuthenticationProvider(jwtValidator);
        when(jwtValidator.validateAndParseToken(anyString())).thenReturn(jwtUserDetails);
    }

    @Test
    public void authenticate() {
        String tokenString = "test";
        Authentication token = new JwtAuthenticationToken(tokenString);
        Authentication authentication = jwtAuthenticationProvider.authenticate(token);
        verify(jwtValidator).validateAndParseToken(tokenString);
        assertThat(authentication).isInstanceOf(JwtAuthenticationToken.class);
    }

    @Test
    public void testSupports() {
        assertThat(jwtAuthenticationProvider.supports(JwtAuthenticationToken.class)).isTrue();
    }
}