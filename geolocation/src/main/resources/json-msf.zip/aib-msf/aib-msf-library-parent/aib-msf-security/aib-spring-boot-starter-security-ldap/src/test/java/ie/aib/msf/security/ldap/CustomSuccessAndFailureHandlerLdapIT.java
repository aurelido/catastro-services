package ie.aib.msf.security.ldap;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.unauthenticated;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;

import ie.aib.msf.security.ldap.CustomSuccessAndFailureHandlerLdapIT.SuccessAndFailureHandlerConfiguration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("single-group")
@SpringBootTest(classes = {TestLdapConfiguration.class, SuccessAndFailureHandlerConfiguration.class,
        TestLdapSecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.ldap.secure-actuator-endpoints=true"})
public class CustomSuccessAndFailureHandlerLdapIT extends AbstractLdapIT {

    private static final String TEST_HEADER = "testHeader";
    private static final String SUCCESS = "success";
    private static final String FAILURE = "failure";

    @Test
    public void testSuccessHandler() throws Exception {
        mockMvc.perform(formLogin().user(TEST_ADMIN).password(TEST_ADMIN_PASSWORD))
                .andExpect(authenticated())
                .andExpect(header().string(TEST_HEADER, SUCCESS));
    }

    @Test
    public void testFailureHandler() throws Exception {
        mockMvc.perform(formLogin().user(TEST_ADMIN).password("wrong password"))
                .andExpect(unauthenticated())
                .andExpect(header().string(TEST_HEADER, FAILURE));
    }

    @Configuration
    static class SuccessAndFailureHandlerConfiguration {

        @Bean
        AuthenticationSuccessHandler successHandler() {
            return new AuthenticationSuccessHandler() {
                @Override
                public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                        Authentication authentication) {
                    response.setHeader(TEST_HEADER, SUCCESS);
                }
            };
        }

        @Bean
        AuthenticationFailureHandler failureHandler() {
            return new AuthenticationFailureHandler() {
                @Override
                public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                        AuthenticationException exception) {
                    response.setHeader(TEST_HEADER, FAILURE);
                }
            };
        }
    }
}