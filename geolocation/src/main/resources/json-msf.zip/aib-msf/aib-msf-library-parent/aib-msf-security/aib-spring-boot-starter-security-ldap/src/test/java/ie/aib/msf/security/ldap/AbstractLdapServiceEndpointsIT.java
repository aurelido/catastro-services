package ie.aib.msf.security.ldap;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.unauthenticated;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders;

public abstract class AbstractLdapServiceEndpointsIT extends AbstractLdapIT {

    @Test
    public void loginWithValidUserThenAuthenticated() throws Exception {
        SecurityMockMvcRequestBuilders.FormLoginRequestBuilder login = formLogin()
                .user("testuser")
                .password("testpassword");

        mockMvc.perform(login)
                .andExpect(authenticated().withUsername("testuser"));
    }

    @Test
    public void loginWithInvalidUserThenUnauthenticated() throws Exception {
        SecurityMockMvcRequestBuilders.FormLoginRequestBuilder login = formLogin()
                .user("invalid")
                .password("invalidpassword");

        mockMvc.perform(login)
                .andExpect(unauthenticated());
    }

    @Test
    public void accessSensitiveEndpointWithoutUserThenRedirected() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_ENDPOINT))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    public void accessOpenEndpointWithoutUser() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.OPEN_ENDPOINT))
                .andExpect(status().isOk());
    }

    @Test
    public void loginWithValidUserWithPermissionsThenAccessUserDefinedSensitiveEndpoint() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_ENDPOINT)
                .session(login(TEST_DEVELOPER, TEST_DEVELOPER_PASSWORD)))
                .andExpect(status().isOk());
    }

    @Test
    public void loginWithValidUserWithoutPermissionsThenFailToAccessUserDefinedSensitiveEndpoint() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_ENDPOINT)
                .session(login("testuser", "testpassword")))
                .andExpect(status().is4xxClientError());
    }
}