package ie.aib.msf.security.jwt.extractors;

import ie.aib.msf.security.jwt.JwtExtractor;
import ie.aib.msf.security.jwt.exception.JwtTokenMissingException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.util.StringUtils;

/**
 * JwtExtractor for parsing the JWT from a HTTP header
 */
public class HttpHeaderJwtExtractor implements JwtExtractor {

    private JwtSecurityProperties jwtSecurityProperties;

    public HttpHeaderJwtExtractor(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
    }

    @Override
    public String extractJwt(HttpServletRequest request, HttpServletResponse response) {
        String header = request.getHeader(jwtSecurityProperties.getHeaderName());

        if (header == null || !header.startsWith(jwtSecurityProperties.getHeaderPrefix())) {
            throw new JwtTokenMissingException("No JWT token found in request headers");
        }

        String token = header.substring(jwtSecurityProperties.getHeaderPrefix().length()).trim();
        if (StringUtils.isEmpty(token)) {
            throw new JwtTokenMissingException("Token not present");
        }
        return token;
    }
}
