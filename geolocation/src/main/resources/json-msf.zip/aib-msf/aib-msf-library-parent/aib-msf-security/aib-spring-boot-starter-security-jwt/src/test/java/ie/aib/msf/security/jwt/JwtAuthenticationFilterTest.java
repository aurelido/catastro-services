package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.fail;
import static org.junit.Assert.assertEquals;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ie.aib.msf.security.jwt.exception.JwtAuthenticationException;
import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

public class JwtAuthenticationFilterTest {

    private AuthenticationManager authenticationManager;
    private JwtExtractor jwtExtractor;
    private JwtSecurityProperties securityProperties;

    @Before
    public void before() {
        authenticationManager = createMockAuthenticationManager();
        jwtExtractor = mock(JwtExtractor.class);
        securityProperties = new JwtSecurityProperties();
    }

    private AuthenticationManager createMockAuthenticationManager() {
        AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
        when(authenticationManager.authenticate(any(JwtAuthenticationToken.class))).then(returnsFirstArg());
        return authenticationManager;
    }

    @Test
    public void attemptAuthentication() {
        String token = "ABC.DEF.GHI";
        when(jwtExtractor.extractJwt(any(HttpServletRequest.class), any(HttpServletResponse.class)))
                .thenReturn(token);
        JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(jwtExtractor,
                securityProperties);
        jwtAuthenticationFilter.setAuthenticationManager(authenticationManager);
        Authentication authentication = jwtAuthenticationFilter.attemptAuthentication(
                mock(HttpServletRequest.class),
                null);

        assertEquals(token, ((JwtAuthenticationToken) authentication).getToken());
    }

    @Test
    public void testExceptionMessageSuppressed() {
        when(jwtExtractor.extractJwt(any(HttpServletRequest.class), any(HttpServletResponse.class)))
                .thenThrow(new JwtTokenMalformedException("Token malformed"));
        securityProperties.setSuppressErrorMessageDetail(true);
        JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(jwtExtractor,
                securityProperties);

        try {
            jwtAuthenticationFilter.attemptAuthentication(
                    mock(HttpServletRequest.class),
                    null);
            fail("Expected JwtTokenMalformedException to be thrown");
        } catch (JwtAuthenticationException e) {
            assertEquals("Unauthorized", e.getMessage());
        }
    }

    @Test
    public void testSuccessfulAuthentication() throws IOException, ServletException {
        JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(jwtExtractor,
                securityProperties);

        jwtAuthenticationFilter.successfulAuthentication(mock(HttpServletRequest.class), mock(HttpServletResponse.class),
                mock(FilterChain.class), mock(Authentication.class));
    }

    @Test
    public void testUnsuccessfulAuthentication() throws IOException, ServletException {
        JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(jwtExtractor,
                securityProperties);

        jwtAuthenticationFilter.unsuccessfulAuthentication(mock(HttpServletRequest.class), mock(HttpServletResponse.class),
                mock(AuthenticationException.class));
    }

}