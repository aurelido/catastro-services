package ie.aib.msf.security.jwt.autoconfigure;

import ie.aib.msf.security.jwt.JwtAuthenticationEntryPoint;
import ie.aib.msf.security.jwt.JwtAuthenticationFilter;
import ie.aib.msf.security.jwt.JwtAuthenticationProvider;
import ie.aib.msf.security.jwt.JwtAuthorizationFilter;
import ie.aib.msf.security.jwt.JwtExtractor;
import ie.aib.msf.security.jwt.JwtValidator;
import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * AutoConfiguration Class for validating JWTs in Web applications. Can be configured to apply validation to a set of
 * matching endpoints
 */
@SuppressWarnings({"SpringJavaAutowiringInspection", "SpringJavaInjectionPointsAutowiringInspection"})
@ConditionalOnWebApplication
@ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "enabled", matchIfMissing = true)
@AutoConfigureAfter(JwtSecurityAutoConfiguration.class)
@EnableConfigurationProperties(JwtSecurityProperties.class)
@EnableWebSecurity
public class JwtWebSecurityAutoConfiguration {

    private final RequestMappingHandlerMapping requestMappingHandlerMapping;
    private final JwtSecurityProperties jwtSecurityProperties;
    private final JwtAuthorizationFilter authorizationFilter;
    private final AuthenticationEventPublisher authenticationEventPublisher;

    @Autowired
    public JwtWebSecurityAutoConfiguration(RequestMappingHandlerMapping requestMappingHandlerMapping,
            JwtSecurityProperties jwtSecurityProperties,
            JwtAuthorizationFilter authorizationFilter,
            AuthenticationEventPublisher authenticationEventPublisher) {
        this.requestMappingHandlerMapping = requestMappingHandlerMapping;
        this.jwtSecurityProperties = jwtSecurityProperties;
        this.authorizationFilter = authorizationFilter;
        this.authenticationEventPublisher = authenticationEventPublisher;
    }

    @Autowired
    @Bean
    WebSecurityConfigurerAdapter webSecurityConfigurerAdapter(JwtValidator jwtValidator, JwtExtractor jwtExtractor) {
        return new WebSecurityConfigurerAdapter() {

            @Override
            protected void configure(HttpSecurity http) throws Exception {
                String[] jwtSecuredPaths = getJwtSecuredPaths();

                if (jwtSecuredPaths.length > 0) {
                    JwtAuthenticationFilter jwtAuthenticationFilter = jwtAuthenticationFilter(jwtValidator,
                            jwtExtractor, authenticationSuccessHandler(), jwtSecurityProperties);

                    //@formatter:off
                    http.requestMatchers()
                            .mvcMatchers(jwtSecuredPaths)
                            .and()
                                .authorizeRequests().anyRequest().authenticated()
                            .and()
                                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                                .addFilterBefore(authorizationFilter, FilterSecurityInterceptor.class)
                                .exceptionHandling().authenticationEntryPoint(unauthorized())
                            .and()
                                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
                    //@formatter:on
                    http.headers().cacheControl();
                }
                http.csrf().disable();
            }
        };
    }

    private String[] getJwtSecuredPaths() {
        Set<String> paths = new HashSet<>();

        for (Entry<RequestMappingInfo, HandlerMethod> entry : requestMappingHandlerMapping.getHandlerMethods()
                .entrySet()) {
            RequestMappingInfo requestMappingInfo = entry.getKey();
            HandlerMethod handlerMethod = entry.getValue();

            if (handlerMethod.hasMethodAnnotation(JwtAuthorization.class) || handlerMethod.getBeanType()
                    .isAnnotationPresent(JwtAuthorization.class)) {
                paths.addAll(requestMappingInfo.getPatternsCondition().getPatterns());
            }
        }

        return paths.toArray(new String[paths.size()]);
    }

    @Bean
    AuthenticationEntryPoint unauthorized() {
        return new JwtAuthenticationEntryPoint();
    }

    /*
        Creating our own AuthenticationManager here because creating one as a bean replaces Spring's default implementation.
        This ensure that the JwtAuthenticationProvider only applies to endpoints with JWT checking.
        Management endpoints ("/beans", "/env", etc) still use basic authentication from Spring
    */
    private JwtAuthenticationFilter jwtAuthenticationFilter(JwtValidator jwtValidator, JwtExtractor jwtExtractor,
            AuthenticationSuccessHandler authenticationSuccessHandler, JwtSecurityProperties jwtSecurityProperties) {
        JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(jwtExtractor,
                jwtSecurityProperties);
        List<AuthenticationProvider> providers = new ArrayList<>();
        providers.add(jwtAuthenticationProvider(jwtValidator));
        ProviderManager authenticationManager = new ProviderManager(providers);

        if (jwtSecurityProperties.getAudit().isEnabled()) {
            authenticationManager.setAuthenticationEventPublisher(authenticationEventPublisher);
        }

        jwtAuthenticationFilter.setAuthenticationManager(authenticationManager);
        jwtAuthenticationFilter.setAuthenticationSuccessHandler(authenticationSuccessHandler);

        return jwtAuthenticationFilter;
    }

    private JwtAuthenticationProvider jwtAuthenticationProvider(JwtValidator jwtValidator) {
        return new JwtAuthenticationProvider(jwtValidator);
    }

    private AuthenticationSuccessHandler authenticationSuccessHandler() {
        return (request, response, authentication) -> {
            //REST only implementation, no web page to redirect to
        };
    }
}