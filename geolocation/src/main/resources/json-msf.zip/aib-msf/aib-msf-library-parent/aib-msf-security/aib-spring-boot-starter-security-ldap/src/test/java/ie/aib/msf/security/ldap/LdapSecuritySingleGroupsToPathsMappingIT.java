package ie.aib.msf.security.ldap;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = {TestLdapConfiguration.class, TestLdapSecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("single-group")
public class LdapSecuritySingleGroupsToPathsMappingIT extends AbstractLdapServiceEndpointsIT {

    //runs common tests from base class with configuration above
}