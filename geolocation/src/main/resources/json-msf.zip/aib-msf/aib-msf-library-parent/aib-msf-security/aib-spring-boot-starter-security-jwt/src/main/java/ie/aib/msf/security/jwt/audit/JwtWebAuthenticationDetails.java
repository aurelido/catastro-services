package ie.aib.msf.security.jwt.audit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import javax.servlet.http.HttpServletRequest;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

/**
 * Holder of details for JWT authentication request
 */
@Getter
@EqualsAndHashCode(callSuper = true)
@JsonInclude(Include.NON_NULL)
public class JwtWebAuthenticationDetails extends WebAuthenticationDetails {

    private String requestUri;
    private String queryString;

    /**
     * Record the authentication request details
     *
     * @param request that the authentication request was received from
     * @param includeRequestUri include the request uri
     * @param includeQueryString include the query string
     */
    JwtWebAuthenticationDetails(HttpServletRequest request, boolean includeRequestUri,
            boolean includeQueryString) {
        super(request);
        if (includeRequestUri) {
            this.requestUri = request.getRequestURI();
        }
        if (includeQueryString) {
            this.queryString = request.getQueryString();
        }
    }

    @Override
    public String toString() {

        return super.toString() + "; "
                + "RequestURI: " + this.requestUri + "; "
                + "QueryString: " + this.queryString;
    }
}