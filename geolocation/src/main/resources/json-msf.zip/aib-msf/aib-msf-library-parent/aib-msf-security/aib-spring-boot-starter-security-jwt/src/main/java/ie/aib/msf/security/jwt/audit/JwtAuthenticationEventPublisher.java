package ie.aib.msf.security.jwt.audit;

import ie.aib.msf.security.jwt.exception.JwtAuthenticationException;
import java.util.Properties;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * Extension of {@link DefaultAuthenticationEventPublisher} to provide support for {@link JwtAuthenticationException} and subclasses
 */
public class JwtAuthenticationEventPublisher extends DefaultAuthenticationEventPublisher {

    public JwtAuthenticationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        super(applicationEventPublisher);
        addAdditionalExceptionMappings();
    }

    private void addAdditionalExceptionMappings() {
        Properties properties = new Properties();
        properties.setProperty(JwtAuthenticationException.class.getName(),
                AuthenticationFailureBadCredentialsEvent.class.getName());
        setAdditionalExceptionMappings(properties);
    }

    @Override
    public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {

        /*JwtAuthenticationException can have any number of subtypes.
        We can't know them in advance, and the event publisher maps concrete event classes to events.
        Most robust thing to do is wrap the exception in the super type and use that mapping
         */
        if (exception instanceof JwtAuthenticationException) {
            exception = new JwtAuthenticationException(exception.getMessage(), exception);
        }

        super.publishAuthenticationFailure(exception, authentication);
    }
}