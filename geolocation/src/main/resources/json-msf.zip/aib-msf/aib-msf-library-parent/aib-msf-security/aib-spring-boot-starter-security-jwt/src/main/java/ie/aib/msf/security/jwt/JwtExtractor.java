package ie.aib.msf.security.jwt;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Interface for extracting a JWT from an incoming HTTP request
 */
public interface JwtExtractor {

    /**
     * Extract the JWT from an incoming request.
     *
     * @param request The HttpServletRequest. This is an instance of {@link MultipleReadRequestWrapper}, so it can be
     * safely read without draining the InputStream
     * @param response The HttpServletResponse
     * @return The extracted JWT
     */
    String extractJwt(HttpServletRequest request, HttpServletResponse response);
}
