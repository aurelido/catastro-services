package ie.aib.msf.security.ldap;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

public class StringToLdapNameListConverterTest {

    @Test
    public void convert() {
        StringToLdapNameListConverter converter = new StringToLdapNameListConverter();
        assertThat(converter.convert("cn={0},ou=STAFF,ou=USERS")).hasSize(1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertInvalidName() {
        new StringToLdapNameListConverter().convert("test");
    }
}