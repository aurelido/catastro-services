package ie.aib.msf.security.jwt;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import org.springframework.util.StreamUtils;

/**
 * HttpServletRequestWrapper implementation to allow reading the InputStream multiple times
 */
public class MultipleReadRequestWrapper extends HttpServletRequestWrapper {

    private byte[] cachedContent;

    MultipleReadRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream(), getCharacterEncoding()));
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        if (cachedContent == null) {
            return super.getInputStream();
        } else {
            return new CachedServletInputStream();
        }
    }

    /**
     * Get The content as a byte array.
     * <p/>
     * If the stream has not be read before, it will read and copied to a byte array,
     * if it has the cached copy is returned
     *
     * @return The content as a byte array
     * @throws IOException if the stream could not be read
     */
    public byte[] getContentAsByteArray() throws IOException {
        if (cachedContent == null) {
            cachedContent = StreamUtils.copyToByteArray(getInputStream());
        }
        return cachedContent;
    }

    /**
     * Provides a new ServletInputStream based on the cached value
     */
    private class CachedServletInputStream extends ServletInputStream {

        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(cachedContent);

        @Override
        public boolean isFinished() {
            return false;
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setReadListener(ReadListener listener) {
            //NOOP
        }

        @Override
        public int read() throws IOException {
            return byteArrayInputStream.read();
        }
    }
}
