package ie.aib.msf.security.ldap;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = {TestLdapConfiguration.class, TestLdapSecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("multiple-paths")
public class LdapSecurityMultiplePathsToGroupsMappingIT extends AbstractLdapServiceEndpointsIT {

    //runs common tests from base class with configuration above

    @Test
    public void loginWithAdminGroupThenAccessAdminGroupProtectedEndpoint() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.ADMIN_ENDPOINT)
                .session(login(TEST_ADMIN, TEST_ADMIN_PASSWORD)))
                .andExpect(status().isOk());
    }

    @Test
    public void loginWithoutAdminGroupThenFailToAccessAdminGroupProtectedEndpoint() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.ADMIN_ENDPOINT)
                .session(login(TEST_DEVELOPER, TEST_DEVELOPER_PASSWORD)))
                .andExpect(status().isForbidden());
    }

    @Test
    public void testAllowedPathsForGroup() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_INCLUDED_ENDPOINT)
                .session(login(TEST_DEVELOPER, TEST_DEVELOPER_PASSWORD)))
                .andExpect(status().isOk());
    }

    @Test
    public void testExcludedPathsForGroup() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_EXCLUDED_ENDPOINT)
                .session(login(TEST_DEVELOPER, TEST_DEVELOPER_PASSWORD)))
                .andExpect(status().isForbidden());
    }

    @Test
    public void testUserInMultipleGroups() throws Exception {
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_INCLUDED_ENDPOINT)
                .session(login(TEST_OPERATOR, TEST_OPERATOR_PASSWORD)))
                .andExpect(status().isForbidden());

        //developer is in developers and operators group, should have access to the endpoint
        //due to membership of developers group
        mockMvc.perform(get(TestLdapSecurityApplication.TEST_INCLUDED_ENDPOINT)
                .session(login(TEST_DEVOPS, TEST_DEVOPS_PASSWORD)))
                .andExpect(status().isOk());

        //developer should have access to the operators only endpoint due to membership of operators group
        mockMvc.perform(get(TestLdapSecurityApplication.OPERATORS_ONLY_ENDPOINT)
                .session(login(TEST_DEVOPS, TEST_DEVOPS_PASSWORD)))
                .andExpect(status().isOk());

        //operators should have access to the operators endpoint
        mockMvc.perform(get(TestLdapSecurityApplication.OPERATORS_ONLY_ENDPOINT)
                .session(login(TEST_OPERATOR, TEST_OPERATOR_PASSWORD)))
                .andExpect(status().isOk());

        //operators should not have access to the operators endpoint
        mockMvc.perform(get(TestLdapSecurityApplication.OPERATORS_ONLY_ENDPOINT)
                .session(login(TEST_ADMIN, TEST_ADMIN_PASSWORD)))
                .andExpect(status().isForbidden());
    }

    @Test
    public void accessActuatorEndpointWithoutLoggingIn() throws Exception {
        mockMvc.perform(get("/actuator/env")).andExpect(status().isOk());
    }
}