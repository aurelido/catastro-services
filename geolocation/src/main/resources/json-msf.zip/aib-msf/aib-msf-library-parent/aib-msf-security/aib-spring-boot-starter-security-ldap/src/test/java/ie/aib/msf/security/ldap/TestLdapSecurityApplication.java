package ie.aib.msf.security.ldap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
class TestLdapSecurityApplication {

    static final String TEST_ENDPOINT = "/test";

    static final String TEST_INCLUDED_ENDPOINT = "/test/included";

    static final String TEST_EXCLUDED_ENDPOINT = "/test/excluded";

    static final String OPEN_ENDPOINT = "/open";

    static final String ADMIN_ENDPOINT = "/admin";

    static final String OPERATORS_ONLY_ENDPOINT = "/operators";

    public static void main(String[] args) {
        SpringApplication.run(TestLdapSecurityApplication.class, args);
    }

    @GetMapping(TEST_ENDPOINT)
    public String test() {
        return "test";
    }

    @GetMapping(TEST_INCLUDED_ENDPOINT)
    public String testIncluded() {
        return "test";
    }

    @GetMapping(TEST_EXCLUDED_ENDPOINT)
    public String testExcluded() {
        return "test";
    }

    @GetMapping(OPEN_ENDPOINT)
    public String open() {
        return "open";
    }


    @GetMapping(ADMIN_ENDPOINT)
    public String admin() {
        return "admin";
    }

    @GetMapping(OPERATORS_ONLY_ENDPOINT)
    public String operators() {
        return "operators";
    }
}