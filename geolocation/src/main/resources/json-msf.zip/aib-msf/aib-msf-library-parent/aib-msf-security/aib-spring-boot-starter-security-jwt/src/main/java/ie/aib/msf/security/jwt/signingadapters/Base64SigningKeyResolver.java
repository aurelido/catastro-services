package ie.aib.msf.security.jwt.signingadapters;

import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import io.jsonwebtoken.impl.TextCodec;
import org.springframework.beans.factory.annotation.Autowired;

public class Base64SigningKeyResolver extends SigningKeyResolverAdapter {

    private JwtSecurityProperties jwtSecurityProperties;

    @Autowired
    public Base64SigningKeyResolver(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
    }

    @Override
    public byte[] resolveSigningKeyBytes(JwsHeader header, Claims claims) {
        return TextCodec.BASE64.decode(jwtSecurityProperties.getSigningKeyBase64());
    }

    @Override
    public byte[] resolveSigningKeyBytes(JwsHeader header, String payload) {
        return resolveSigningKeyBytes(header, (Claims) null);
    }
}
