package ie.aib.msf.security.jwt;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import ie.aib.msf.security.jwt.exception.JwtAuthorizationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.validators.ClaimsAuthorizationValidator;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultClaims;
import java.util.Collections;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.access.event.AuthorizationFailureEvent;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class JwtAuthorizationFilterTest {

    private JwtAuthorizationFilter jwtAuthorizationFilter;
    private Claims claims = new DefaultClaims();
    private FilterChain filterChain = mock(FilterChain.class);
    private ApplicationEventPublisher eventPublisher = mock(ApplicationEventPublisher.class);

    @Before
    public void setUp() {
        jwtAuthorizationFilter = new JwtAuthorizationFilter(new JwtSecurityProperties(), eventPublisher);
        jwtAuthorizationFilter.setClaimsAuthorizationValidators(createValidators());
        SecurityContext securityContext = mock(SecurityContext.class);
        JwtAuthenticationToken jwtAuthenticationToken = createAuthenticationToken();
        when(securityContext.getAuthentication()).thenReturn(jwtAuthenticationToken);
        SecurityContextHolder.setContext(securityContext);
    }


    @Test(expected = JwtAuthorizationException.class)
    public void testValidateUnauthorizedClaim() throws Exception {
        claims.setIssuer("Bad Issuer");
        jwtAuthorizationFilter.doFilter(mock(HttpServletRequest.class), mock(HttpServletResponse.class), filterChain);
        verifyZeroInteractions(filterChain);
        verify(eventPublisher).publishEvent(any(AuthorizationFailureEvent.class));
    }

    @Test
    public void testValidateAuthorizedClaim() throws Exception {
        claims.setIssuer("Good Issuer");
        jwtAuthorizationFilter.doFilter(mock(HttpServletRequest.class), mock(HttpServletResponse.class), filterChain);
        verify(filterChain).doFilter(any(), any());
        verifyZeroInteractions(eventPublisher);
    }

    private List<ClaimsAuthorizationValidator> createValidators() {
        return Collections.singletonList(claims -> {
            if (claims.getIssuer().equals("Bad Issuer")) {
                throw new JwtAuthorizationException("bad claim");
            }
        });
    }

    private JwtAuthenticationToken createAuthenticationToken() {
        JwtUserDetails jwtUserDetails = new JwtUserDetails("", "", claims, null);
        return new JwtAuthenticationToken("", jwtUserDetails);
    }
}