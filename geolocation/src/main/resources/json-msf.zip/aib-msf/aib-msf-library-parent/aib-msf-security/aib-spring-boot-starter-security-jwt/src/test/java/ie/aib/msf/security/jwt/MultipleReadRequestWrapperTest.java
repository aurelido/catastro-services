package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.DelegatingServletInputStream;

public class MultipleReadRequestWrapperTest {

    private MultipleReadRequestWrapper requestWrapper;

    @Before
    public void setUp() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        DelegatingServletInputStream inputStream = new DelegatingServletInputStream(
                new ByteArrayInputStream(("test".getBytes(
                        StandardCharsets.UTF_8))));
        when(request.getInputStream()).thenReturn(inputStream);
        requestWrapper = new MultipleReadRequestWrapper(request);
    }

    @Test
    public void testGetInputStream() throws Exception {
        assertThat(requestWrapper.getInputStream()).isNotNull();
    }

    @Test
    public void testGetContent() throws IOException {
        assertThat(requestWrapper.getContentAsByteArray()).isNotNull();
    }

}