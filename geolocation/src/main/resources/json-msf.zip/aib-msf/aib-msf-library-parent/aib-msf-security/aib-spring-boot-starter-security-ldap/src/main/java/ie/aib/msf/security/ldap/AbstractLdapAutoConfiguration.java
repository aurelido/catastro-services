package ie.aib.msf.security.ldap;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.util.Assert;

class AbstractLdapAutoConfiguration {

    private final LdapProperties ldapProperties;

    AbstractLdapAutoConfiguration(LdapProperties ldapProperties) {
        this.ldapProperties = ldapProperties;
    }

    static UserDetailsContextMapper ldapUserDetailsContextMapper(LdapProperties ldapProperties) {
        LdapUserDetailsMapper ldapUserDetailsMapper = new GroupConvertingLdapUserDetailsMapper(
                ldapProperties.getRoleAttributeKey());
        ldapUserDetailsMapper.setRoleAttributes(ldapProperties.getRoleAttributes().toArray(new String[0]));
        return ldapUserDetailsMapper;
    }

    @ConditionalOnMissingBean(BaseLdapPathContextSource.class)
    @Bean
    BaseLdapPathContextSource contextSource() {
        Assert.notEmpty(ldapProperties.getProviderUrls(), "LDAP provider url must be set");
        return new DefaultSpringSecurityContextSource(ldapProperties.getProviderUrls(), ldapProperties.getBaseDN());
    }

}