package ie.aib.msf.security.jwt.validators;

import ie.aib.msf.security.jwt.exception.JwtAuthorizationException;
import io.jsonwebtoken.Claims;

@FunctionalInterface
public interface ClaimsAuthorizationValidator {

    /**
     * Validate JWT claims for authorization.
     * <p/>
     * Implementations of this class should throw {@link JwtAuthorizationException}
     * if the JWT claims do not allow access to the service.<br/>
     * This will result in an Forbidden (403) response status.
     *
     * @param claims The claims retrieved from the JWT
     * @throws JwtAuthorizationException if claims are not valid
     */
    void validate(Claims claims) throws JwtAuthorizationException;
}