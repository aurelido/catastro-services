package ie.aib.msf.security.x509;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.util.EnvironmentTestUtils;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Tests that properties can be refresh while the application is running, using @RefreshScope
 */
@RunWith(SpringRunner.class)
@SpringBootTest(properties = {"ie.aib.msf.security.x509.clientAuthorizationRegex[0]=client1",
        "ie.aib.msf.security.x509.clientAuthorizationRegex[1]=client2"})
public class RefreshScopeIT {

    @Autowired
    private X509Properties properties;

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Autowired
    private org.springframework.cloud.context.scope.refresh.RefreshScope scope;

    @Autowired
    private ConfigurableEnvironment environment;

    @Test
    @DirtiesContext
    public void testListValuesChanged() {
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(2);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[client1, client2]");
        EnvironmentTestUtils
                .addEnvironment(this.environment, "ie.aib.msf.security.x509.clientAuthorizationRegex[0]=clientA",
                        "ie.aib.msf.security.x509.clientAuthorizationRegex[1]=clientB");
        this.scope.refreshAll();
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(2);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[clientA, clientB]");
    }

    @Test
    @DirtiesContext
    public void testListValueRemoved() {
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(2);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[client1, client2]");
        EnvironmentTestUtils
                .addEnvironment(this.environment, "ie.aib.msf.security.x509.clientAuthorizationRegex[0]=client1");
        this.scope.refreshAll();
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(1);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[client1]");
    }

    @Test
    @DirtiesContext
    public void testListValuesAdded() {
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(2);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[client1, client2]");
        EnvironmentTestUtils
                .addEnvironment(this.environment, "ie.aib.msf.security.x509.clientAuthorizationRegex[0]=client1",
                        "ie.aib.msf.security.x509.clientAuthorizationRegex[1]=client2",
                        "ie.aib.msf.security.x509.clientAuthorizationRegex[2]=client3");
        this.scope.refreshAll();
        assertThat(this.properties.getClientAuthorizationRegex()).hasSize(3);
        assertThat(this.properties.getClientAuthorizationRegex().toString())
                .isEqualTo("[client1, client2, client3]");
    }
}
