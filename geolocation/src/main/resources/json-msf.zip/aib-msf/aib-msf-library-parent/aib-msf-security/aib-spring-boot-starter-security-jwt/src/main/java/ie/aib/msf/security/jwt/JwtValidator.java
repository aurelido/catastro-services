package ie.aib.msf.security.jwt;

/**
 * Validator/Parser for JWT tokens
 */
public interface JwtValidator {

    /**
     * Validate and parse the {@link JwtUserDetails} from a JWT
     *
     * @param token the Base64 encoded JWT
     * @return A {@link JwtUserDetails} instance created from the claims
     */
    JwtUserDetails validateAndParseToken(String token);
}
