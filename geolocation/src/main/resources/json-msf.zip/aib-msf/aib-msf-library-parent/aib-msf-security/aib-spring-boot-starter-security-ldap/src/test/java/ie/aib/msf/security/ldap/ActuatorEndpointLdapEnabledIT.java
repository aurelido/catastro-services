package ie.aib.msf.security.ldap;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("single-group")
@SpringBootTest(classes = {TestLdapConfiguration.class, TestLdapSecurityApplication.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.msf.security.ldap.secure-actuator-endpoints=true"})
public class ActuatorEndpointLdapEnabledIT extends AbstractLdapIT {

    @Test
    public void accessActuatorEndpointWithoutUserCausesRedirection() throws Exception {
        mockMvc.perform(get("/actuator/env"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    public void loginWithAdminGroupThenAccessAdminGroupProtectedEndpoint() throws Exception {
        mockMvc.perform(get("/actuator/env")
                .session(login(TEST_ADMIN, TEST_ADMIN_PASSWORD)))
                .andExpect(status().isOk());
    }
}