package ie.aib.msf.security.x509;

import java.io.InputStream;
import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

class X509TestUtil {

    private static final String KEYSTORE_PASSWORD = "password";
    private static ResourceLoader resourceLoader = new DefaultResourceLoader();

    static void configureRestTemplate(TestRestTemplate restTemplate, String keyStoreLocation) throws Exception {
        SSLContext sslContext = createSslContext(keyStoreLocation);
        SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext,
                NoopHostnameVerifier.INSTANCE);

        CloseableHttpClient closeableHttpClient =
                HttpClientBuilder.create().setSSLSocketFactory(connectionFactory).build();

        HttpComponentsClientHttpRequestFactory httpRequestFactory =
                (HttpComponentsClientHttpRequestFactory) restTemplate.getRestTemplate().getRequestFactory();
        httpRequestFactory.setHttpClient(closeableHttpClient);
    }

    private static SSLContext createSslContext(String keyStoreLocation) throws Exception {
        return SSLContexts.custom()
                .loadKeyMaterial(getStore(keyStoreLocation), KEYSTORE_PASSWORD.toCharArray())
                .loadTrustMaterial(getStore("classpath:x509-truststore.jks"), new TrustSelfSignedStrategy())
                .build();
    }

    private static KeyStore getStore(String filename) throws Exception {
        KeyStore keyStore;
        keyStore = KeyStore.getInstance("JKS");
        Resource resource = resourceLoader.getResource(filename);
        try (InputStream in = resource.getInputStream()) {
            keyStore.load(in, KEYSTORE_PASSWORD.toCharArray());
        }

        return keyStore;
    }
}
