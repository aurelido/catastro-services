package ie.aib.msf.security.x509;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class TestX509SecurityApplication {

    static final String TEST_ENDPOINT = "/test";
    static final String OPEN_ENDPOINT = "/open";
    static final String PRINCIPAL_ENDPOINT = "/principal";
    static final String RESPONSE = "Test";

    public static void main(String[] args) {
        SpringApplication.run(TestX509SecurityApplication.class, args);
    }

    @GetMapping(TEST_ENDPOINT)
    public String test() {
        return RESPONSE;
    }

    @GetMapping(OPEN_ENDPOINT)
    public String open() {
        return RESPONSE;
    }

    @GetMapping(PRINCIPAL_ENDPOINT)
    public Map<String, Object> principal(@AuthenticationPrincipal X509User principal) {
        //return the client properties so we can verify they were assigned to the principal
        return principal.getProperties();
    }
}
