package ie.aib.msf.security.jwt;

import io.jsonwebtoken.Claims;
import org.springframework.security.authentication.AbstractAuthenticationToken;

/**
 * JWTAuthenticationToken created from the Base64 encoded JWT
 */
@SuppressWarnings("WeakerAccess")
public class JwtAuthenticationToken extends AbstractAuthenticationToken {

    private String authToken;
    private JwtUserDetails jwtUserDetails;

    public JwtAuthenticationToken(String authToken) {
        super(null);
        this.authToken = authToken;
        setAuthenticated(false);
    }

    /**
     * The authentication token representing the user, which wraps the JWT in a Spring Security token.
     *
     * @param authToken The authentication token, which is the JWT in String format
     * @param jwtUserDetails The JwtUserDetails object
     */
    public JwtAuthenticationToken(String authToken, JwtUserDetails jwtUserDetails) {
        super(jwtUserDetails.getAuthorities());
        this.authToken = authToken;
        this.jwtUserDetails = jwtUserDetails;
        //if JwtValidator was successful then authentication has succeeded
        setAuthenticated(true);
    }

    public String getToken() {
        return this.authToken;
    }

    @Override
    public Object getCredentials() {
        return jwtUserDetails != null ? jwtUserDetails.getUsername() : null;
    }

    @Override
    public JwtUserDetails getPrincipal() {
        return this.jwtUserDetails;
    }

    @SuppressWarnings("unused")
    public Claims getClaims() {
        return jwtUserDetails != null ? jwtUserDetails.getClaims() : null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        JwtAuthenticationToken that = (JwtAuthenticationToken) o;

        return authToken.equals(that.authToken);
    }

    @Override
    public int hashCode() {
        return 31 * authToken.hashCode();
    }
}
