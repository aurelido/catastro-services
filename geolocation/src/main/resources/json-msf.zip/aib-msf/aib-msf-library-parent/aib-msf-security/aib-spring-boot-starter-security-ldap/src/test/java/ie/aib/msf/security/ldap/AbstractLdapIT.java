package ie.aib.msf.security.ldap;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
//need to mark the context as dirty before the test starts to refresh the properties for group mappings
@DirtiesContext(classMode = ClassMode.BEFORE_CLASS)
public abstract class AbstractLdapIT {

    static final String TEST_DEVELOPER = "testdeveloper";
    static final String TEST_DEVELOPER_PASSWORD = "testdeveloperpassword";
    static final String TEST_DEVOPS = "testdevops";
    static final String TEST_DEVOPS_PASSWORD = "testdevopspassword";
    static final String TEST_ADMIN = "testadmin";
    static final String TEST_ADMIN_PASSWORD = "testadminpassword";
    static final String TEST_OPERATOR = "testoperator";
    static final String TEST_OPERATOR_PASSWORD = "testoperatorpassword";

    @SuppressWarnings("SpringJavaAutowiredMembersInspection")
    @Autowired
    protected MockMvc mockMvc;


    MockHttpSession login(String user, String password) throws Exception {
        SecurityMockMvcRequestBuilders.FormLoginRequestBuilder login = formLogin()
                .user(user)
                .password(password);

        MvcResult mvcResult = mockMvc.perform(login).andReturn();
        return (MockHttpSession) mvcResult.getRequest().getSession();
    }
}
