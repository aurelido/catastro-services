package ie.aib.msf.security.jwt.signingadapters;

import ie.aib.msf.security.jwt.autoconfigure.JwtSecurityAutoConfiguration;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;

@ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(JwtSecurityProperties.class)
@AutoConfigureBefore(JwtSecurityAutoConfiguration.class)
@Configuration
public class SigningAdapterAutoConfiguration {

    @ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "signingKeyBase64")
    @Autowired
    @Bean
    SigningKeyResolverAdapter base64SigningKeyResolver(JwtSecurityProperties jwtSecurityProperties) {
        return new Base64SigningKeyResolver(jwtSecurityProperties);
    }

    @ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt.keystore", name = "file")
    @Autowired
    @Bean
    SigningKeyResolverAdapter keystoreSigningKeyResolver(JwtSecurityProperties jwtSecurityProperties,
            ResourceLoader resourceLoader) {
        return new KeystoreSigningKeyResolverAdapter(jwtSecurityProperties, resourceLoader);
    }
}
