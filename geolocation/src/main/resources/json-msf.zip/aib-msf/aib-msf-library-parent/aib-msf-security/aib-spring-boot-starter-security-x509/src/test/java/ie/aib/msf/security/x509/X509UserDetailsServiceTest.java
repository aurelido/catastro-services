package ie.aib.msf.security.x509;

import static org.assertj.core.api.Assertions.assertThat;

import ie.aib.msf.security.x509.X509Properties.Client;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.junit.Test;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;

public class X509UserDetailsServiceTest {

    @Test
    public void testValidRegexReturnsUser() {
        String distinguishedName = "CN=test-client1,OU=test,O=AIB";
        UserDetails userDetails = createUserDetailsService().loadUserByUsername(distinguishedName);
        assertThat(userDetails).isNotNull();
        assertThat(userDetails.getUsername()).isEqualTo(distinguishedName);
        assertThat(((X509User)userDetails).getProperties()).isEmpty();
        assertThat(((X509User)userDetails).getProperty("testProperty", String.class)).isNull();
    }

    @Test(expected = BadCredentialsException.class)
    public void testInValidRegexThrowsException() {
        String distinguishedName = "CN=invalid-client,OU=test,O=AIB";
        createUserDetailsService().loadUserByUsername(distinguishedName);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testValidRegexInClientListReturnsUserWithProperties() {
        String distinguishedName = "CN=test-client1,OU=test,O=AIB";
        UserDetails userDetails = createUserDetailsServiceWithClientList().loadUserByUsername(distinguishedName);
        assertThat(userDetails).isNotNull();
        assertThat(userDetails.getUsername()).isEqualTo(distinguishedName);
        assertThat(((X509User)userDetails).getProperties()).isNotEmpty();
        assertThat(((X509User)userDetails).getProperty("testProperty", String.class)).isEqualTo("testValue");
        assertThat(((X509User)userDetails).getProperty("missingProperty", List.class)).isNull();
        assertThat(((X509User)userDetails).getProperty("testList", List.class)).isInstanceOf(List.class);
    }

    @Test(expected = BadCredentialsException.class)
    public void testInvalidRegexInClientListThrowsException() {
        String distinguishedName = "CN=invalid-client,OU=test,O=AIB";
        createUserDetailsServiceWithClientList().loadUserByUsername(distinguishedName);
    }

    private X509UserDetailsService createUserDetailsService() {
        List<Pattern> regexList = new ArrayList<>();
        regexList.add(Pattern.compile("CN=test-client.*,OU=test,O=AIB"));
        X509Properties x509Properties = new X509Properties();
        x509Properties.setClientAuthorizationRegex(regexList);
        return new X509UserDetailsService(x509Properties);
    }

    private X509UserDetailsService createUserDetailsServiceWithClientList() {
        List<Pattern> regexList = new ArrayList<>();
        regexList.add(Pattern.compile("CN=test-client.*,OU=test,O=AIB"));

        Map<String, Object> properties = new HashMap<>();
        properties.put("testProperty", "testValue");
        properties.put("testList", new ArrayList<String>());

        Client client = new Client();
        client.setName("testClient1");
        client.setProperties(properties);
        client.setClientAuthorizationRegex(regexList);
        List<Client> clients = Collections.singletonList(client);

        X509Properties x509Properties = new X509Properties();
        x509Properties.setClients(clients);
        return new X509UserDetailsService(x509Properties);
    }
}