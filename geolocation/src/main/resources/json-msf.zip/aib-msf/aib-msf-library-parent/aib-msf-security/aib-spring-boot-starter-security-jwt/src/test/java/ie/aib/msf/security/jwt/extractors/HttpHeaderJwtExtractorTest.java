package ie.aib.msf.security.jwt.extractors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;

import ie.aib.msf.security.jwt.exception.JwtTokenMissingException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import javax.servlet.http.HttpServletRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;

@RunWith(MockitoJUnitRunner.class)
public class HttpHeaderJwtExtractorTest {

    private HttpHeaderJwtExtractor httpHeaderJwtExtractor;

    private JwtSecurityProperties jwtSecurityProperties = new JwtSecurityProperties();

    @Mock
    private HttpServletRequest request;

    @Before
    public void setup() {
        httpHeaderJwtExtractor = new HttpHeaderJwtExtractor(jwtSecurityProperties);
    }

    @Test
    public void testExtractJWT() throws Exception {
        //when
        String testJwt = "A.B.C";
        when(request.getHeader(HttpHeaders.AUTHORIZATION))
                .thenReturn(jwtSecurityProperties.getHeaderPrefix() + " " + testJwt);
        //then
        String extractedJWT = httpHeaderJwtExtractor.extractJwt(request, null);
        assertThat(extractedJWT, is(testJwt));
    }

    @Test(expected = JwtTokenMissingException.class)
    public void testHeaderPresentButTokenMissing() throws Exception {
        //when
        when(request.getHeader(HttpHeaders.AUTHORIZATION))
                .thenReturn(jwtSecurityProperties.getHeaderPrefix() + " ");
        //then
        httpHeaderJwtExtractor.extractJwt(request, null);
        //then
        //expect exception
    }

    @Test(expected = JwtTokenMissingException.class)
    public void testHeaderMissing() throws Exception {
        //when
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(null);
        //then
        httpHeaderJwtExtractor.extractJwt(request, null);
    }

}