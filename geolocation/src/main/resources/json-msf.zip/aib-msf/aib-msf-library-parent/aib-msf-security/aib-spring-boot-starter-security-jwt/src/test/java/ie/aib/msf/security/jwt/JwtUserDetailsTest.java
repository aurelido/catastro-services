package ie.aib.msf.security.jwt;

import static org.assertj.core.api.Assertions.assertThat;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultClaims;
import java.util.ArrayList;
import java.util.Collection;
import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class JwtUserDetailsTest {

    @Test
    public void testJwtUserDetails() {
        String username = "testUser";
        String token = "testToken";
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("user"));
        Claims claims = new DefaultClaims();
        claims.setSubject("test");

        JwtUserDetails userDetails = new JwtUserDetails(username, token, claims, authorities);

        assertThat(userDetails.getPassword()).isNull();
        assertThat(userDetails.getUsername()).isEqualTo(username);
        assertThat(userDetails.getAuthorities()).isEqualTo(authorities);
        assertThat(userDetails.getToken()).isEqualTo(token);
        assertThat(userDetails.getClaims()).isEqualTo(claims);
        assertThat(userDetails.isAccountNonExpired()).isEqualTo(true);
        assertThat(userDetails.isAccountNonLocked()).isEqualTo(true);
        assertThat(userDetails.isCredentialsNonExpired()).isEqualTo(true);
        assertThat(userDetails.isEnabled()).isEqualTo(true);
    }
}