package ie.aib.msf.security.jwt.exception;

import ie.aib.msf.errorhandling.ErrorCode;

@ErrorCode(code = "401-0100-0002", info = "https://wiki.aib.pri/display/MSF/Generic+Error+Codes")
public class JwtTokenMalformedException extends JwtAuthenticationException {

    public JwtTokenMalformedException(String s) {
        super(s);
    }
}
