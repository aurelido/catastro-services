package ie.aib.msf.security.jwt.autoconfigure;

import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.validators.ClaimsValidator;
import ie.aib.msf.security.jwt.validators.RequiredClaimNamesValidator;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AutoConfigureBefore(JwtSecurityAutoConfiguration.class)
@EnableConfigurationProperties(JwtSecurityProperties.class)
public class JwtValidatorAutoConfiguration {

    private final JwtSecurityProperties jwtSecurityProperties;

    public JwtValidatorAutoConfiguration(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
    }

    @ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "requiredClaimNames")
    @Bean
    ClaimsValidator requiredClaimNamesValidator() {
        return new RequiredClaimNamesValidator(jwtSecurityProperties);
    }
}