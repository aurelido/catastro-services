package ie.aib.msf.security.jwt;

import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import ie.aib.msf.security.jwt.exception.JwtValidationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.validators.ClaimsValidator;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.InvalidClaimException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SigningKeyResolver;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

/**
 * Default Jwt Parser. Validates signature and parses claims
 */
public class DefaultJwtValidatorImpl implements JwtValidator {

    private static final Log LOG = LogFactory.getLog(DefaultJwtValidatorImpl.class);

    private static final String ROLE_PREFIX = "ROLE_";
    private JwtSecurityProperties jwtSecurityProperties;
    private final List<ClaimsValidator> claimsValidators;
    private JwtParser jwtParser;

    /**
     * Create a new instance of the DefaultJwtValidatorImpl.
     *
     * @param signingKeyResolver The signing key resolver
     * @param jwtSecurityProperties The JWT security properties
     */
    public DefaultJwtValidatorImpl(SigningKeyResolver signingKeyResolver, JwtSecurityProperties jwtSecurityProperties,
            List<ClaimsValidator> claimsValidators) {
        this.jwtSecurityProperties = jwtSecurityProperties;
        this.claimsValidators = claimsValidators;
        this.jwtParser = Jwts.parser()
                .setSigningKeyResolver(signingKeyResolver)
                .setAllowedClockSkewSeconds(jwtSecurityProperties.getAllowedClockSkewSeconds());

        setExpectedClaims(jwtParser, jwtSecurityProperties);
    }

    private void setExpectedClaims(JwtParser jwtParser, JwtSecurityProperties jwtSecurityProperties) {
        Map<String, Object> expectedClaims = jwtSecurityProperties.getExpectedClaims();
        if (!CollectionUtils.isEmpty(expectedClaims)) {
            for (Entry<String, Object> entry : expectedClaims.entrySet()) {
                jwtParser.require(entry.getKey(), entry.getValue());
            }
        }
    }

    @Override
    public JwtUserDetails validateAndParseToken(String token) {
        Jws<Claims> jws = parseClaims(token);
        validateAlg(jws);

        Claims claims = jws.getBody();
        validateClaims(claims);

        return createUserDetails(token, claims);
    }

    private Jws<Claims> parseClaims(String token) {
        Jws<Claims> jws;
        try {
            jws = jwtParser.parseClaimsJws(token);

        } catch (InvalidClaimException e) {
            logWarning(e);
            throw new JwtValidationException(String.format("Invalid value for claim: %s", e.getClaimName()));
        } catch (Exception e) {
            logWarning(e);
            throw new JwtTokenMalformedException("JWT is not valid");
        }

        return jws;
    }

    private void validateAlg(Jws<Claims> jws) {
        SignatureAlgorithm alg = SignatureAlgorithm.NONE;
        if (jws.getHeader() != null && jws.getHeader().getAlgorithm() != null) {
            try {
                alg = SignatureAlgorithm.valueOf(jws.getHeader().getAlgorithm());
            } catch (IllegalArgumentException e) {
                logWarning(e);
                throw new JwtTokenMalformedException("Alg is invalid: " + jws.getHeader().getAlgorithm());
            }
        }

        if (alg.equals(SignatureAlgorithm.NONE)) {
            throw new JwtTokenMalformedException("alg header is required, and cannot be 'none'");
        }
    }

    private void validateClaims(Claims claims) {
        if (claimsValidators != null) {
            for (ClaimsValidator validator : claimsValidators) {
                try {
                    validator.validate(claims);
                } catch (JwtValidationException e) {
                    logWarning(e);
                    throw e;
                }
            }
        }
    }

    private JwtUserDetails createUserDetails(String token, Claims claims) {
        //TODO: need to get more GrantedAuthorities, instead of just Roles
        List<GrantedAuthority> authorityList = new ArrayList<>();
        String principalName;
        try {
            for (String roleClaim : StringUtils
                    .commaDelimitedListToStringArray(jwtSecurityProperties.getRoleClaims())) {
                authorityList.addAll(AuthorityUtils
                        .commaSeparatedStringToAuthorityList(ROLE_PREFIX + (claims.get(roleClaim, String.class))));
            }

            principalName = claims.get(jwtSecurityProperties.getUserClaim(), String.class);
        } catch (Exception e) {
            logWarning(e);
            throw new JwtTokenMalformedException("JWT is not valid");
        }

        if (principalName == null) {
            throw new JwtTokenMalformedException(
                    "Claim " + jwtSecurityProperties.getUserClaim() + " must be present");
        }

        return new JwtUserDetails(principalName, token, claims, authorityList);
    }

    private void logWarning(Exception e) {
        if (LOG.isWarnEnabled()) {
            LOG.warn(e.getMessage(), e);
        }
    }
}
