package ie.aib.msf.security.jwt;

import io.jsonwebtoken.Claims;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * {@link UserDetails} parsed from a JWT
 */
@SuppressWarnings("WeakerAccess")
public class JwtUserDetails implements UserDetails {

    private String username;
    private String token;
    private Collection<? extends GrantedAuthority> authorities;
    private transient Claims claims;

    /**
     * Create a new instance of JwtUserDetails.
     *
     * @param username The username, extracted from the JWT
     * @param token The JWT in String format
     * @param claims The JWT claims
     * @param authorities The granted authorities that this user belongs to
     */
    public JwtUserDetails(String username, String token, Claims claims,
            Collection<? extends GrantedAuthority> authorities) {
        this.username = username;
        this.token = token;
        this.claims = claims;
        this.authorities = authorities;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return username;
    }

    //TODO: get values from claims in JWT, e.g. exp
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public String getToken() {
        return token;
    }

    public Claims getClaims() {
        return claims;
    }
}
