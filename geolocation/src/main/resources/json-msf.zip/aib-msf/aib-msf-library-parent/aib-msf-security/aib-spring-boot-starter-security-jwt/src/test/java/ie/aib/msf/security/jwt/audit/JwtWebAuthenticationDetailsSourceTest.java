package ie.aib.msf.security.jwt.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import javax.servlet.http.HttpServletRequest;
import org.junit.Test;

public class JwtWebAuthenticationDetailsSourceTest {

    @Test
    public void buildDetails() {
        JwtWebAuthenticationDetailsSource detailsSource = new JwtWebAuthenticationDetailsSource(
                new JwtSecurityProperties());

        assertThat(detailsSource.buildDetails(mock(HttpServletRequest.class))).isNotNull();
    }
}