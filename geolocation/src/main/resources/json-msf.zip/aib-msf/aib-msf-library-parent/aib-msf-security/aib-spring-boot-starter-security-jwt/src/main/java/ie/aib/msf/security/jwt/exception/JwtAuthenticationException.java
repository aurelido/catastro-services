package ie.aib.msf.security.jwt.exception;

import ie.aib.msf.errorhandling.ErrorCode;
import org.springframework.security.core.AuthenticationException;

@ErrorCode(code = "401-0100-0001", info = "https://wiki.aib.pri/display/MSF/Generic+Error+Codes")
public class JwtAuthenticationException extends AuthenticationException {

    public JwtAuthenticationException(String msg) {
        super(msg);
    }

    public JwtAuthenticationException(String msg, Throwable t) {
        super(msg, t);
    }
}
