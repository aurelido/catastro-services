package ie.aib.msf.security.jwt;

import ie.aib.msf.errorhandling.ErrorCode;
import ie.aib.msf.errorhandling.RestErrorContext;
import ie.aib.msf.security.jwt.audit.JwtWebAuthenticationDetailsSource;
import ie.aib.msf.security.jwt.exception.JwtAuthenticationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

/**
 * Filter for authenticating JWTs in an incoming request
 */
public class JwtAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

    private static final Log LOG = LogFactory.getLog(JwtAuthenticationFilter.class);

    private final JwtExtractor jwtExtractor;
    private final JwtSecurityProperties jwtSecurityProperties;

    /**
     * Create a new instance of the JWTAuthenticationFilter.
     *
     * @param jwtExtractor The JWT Extractor
     * @param jwtSecurityProperties Properties for the JWT starter module
     */
    public JwtAuthenticationFilter(JwtExtractor jwtExtractor,
            JwtSecurityProperties jwtSecurityProperties) {
        super("/**");
        this.jwtExtractor = jwtExtractor;
        this.jwtSecurityProperties = jwtSecurityProperties;
        this.setAuthenticationDetailsSource(new JwtWebAuthenticationDetailsSource(jwtSecurityProperties));
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        MultipleReadRequestWrapper requestWrapper = new MultipleReadRequestWrapper((HttpServletRequest) request);
        super.doFilter(requestWrapper, response, chain);
    }

    @Override
    protected boolean requiresAuthentication(HttpServletRequest request, HttpServletResponse response) {
        return true;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException {

        try {
            String authToken = jwtExtractor.extractJwt(request, response);
            //create an authentication token without user details. The authentication manager will validate
            //the token and fill in the claims if successful
            JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(authToken);
            authenticationToken.setDetails(authenticationDetailsSource.buildDetails(request));
            return getAuthenticationManager().authenticate(authenticationToken);
        } catch (JwtAuthenticationException e) {
            if (jwtSecurityProperties.isSuppressErrorMessageDetail()) {
                throw new JwtAuthenticationException("Unauthorized");
            }
            throw e;
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
            Authentication authResult) throws IOException, ServletException {
        super.successfulAuthentication(request, response, chain, authResult);
        chain.doFilter(request, response);
    }

    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException failed) throws IOException, ServletException {
        if (LOG.isWarnEnabled()) {
            LOG.warn(String.format("Unsuccessful authentication: %s", failed.getMessage()));
        }
        //the exception is discarded before the error handler, so code and info would be lost
        setErrorAndInfo(failed);
        super.unsuccessfulAuthentication(request, response, failed);
    }

    private void setErrorAndInfo(AuthenticationException failed) {
        ErrorCode errorCode = AnnotationUtils.getAnnotation(failed.getClass(), ErrorCode.class);

        if (errorCode != null) {
            RestErrorContext.setInfo(errorCode.info());
            RestErrorContext.setCode(errorCode.code());
        }
    }
}
