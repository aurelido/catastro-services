package ie.aib.msf.security.jwt.extractors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.msf.security.jwt.JsonPathTestRequest;
import ie.aib.msf.security.jwt.MultipleReadRequestWrapper;
import ie.aib.msf.security.jwt.exception.JwtTokenMissingException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import java.nio.charset.StandardCharsets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class JsonPathJwtExtractorTest {

    private JsonPathJwtExtractor jsonPathJwtExtractor;

    @Mock
    private MultipleReadRequestWrapper httpServletRequest;

    @Before
    public void setup() {
        JwtSecurityProperties jwtSecurityProperties = new JwtSecurityProperties();
        jwtSecurityProperties.setJsonPathExpression("$.security.jwt");
        jsonPathJwtExtractor = new JsonPathJwtExtractor(jwtSecurityProperties);
    }

    @Test
    public void testExtractJWT() throws Exception {
        //when
        String testJwt = "A.B.C";
        JsonPathTestRequest jsonPathTestRequest = new JsonPathTestRequest(
                new JsonPathTestRequest.SecurityContext(testJwt));
        when(httpServletRequest.getContentAsByteArray())
                .thenReturn(new ObjectMapper().writeValueAsBytes(jsonPathTestRequest));

        //then
        String extractedJWT = jsonPathJwtExtractor.extractJwt(httpServletRequest, null);
        assertThat(extractedJWT, is(testJwt));
    }

    @Test(expected = JwtTokenMissingException.class)
    public void testJWTAbsent() throws Exception {
        //when
        JsonPathTestRequest jsonPathTestRequest = new JsonPathTestRequest(
                new JsonPathTestRequest.SecurityContext(null));
        when(httpServletRequest.getContentAsByteArray())
                .thenReturn(new ObjectMapper().writeValueAsBytes(jsonPathTestRequest));

        //then
        jsonPathJwtExtractor.extractJwt(httpServletRequest, null);
    }

    @Test(expected = JwtTokenMissingException.class)
    public void testPathMissing() throws Exception {
        //when
        when(httpServletRequest.getContentAsByteArray()).thenReturn("test".getBytes(StandardCharsets.UTF_8));
        //then
        jsonPathJwtExtractor.extractJwt(httpServletRequest, null);
    }

}