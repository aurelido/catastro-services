package ie.aib.msf.security.jwt.autoconfigure;

import ie.aib.msf.security.jwt.DefaultJwtValidatorImpl;
import ie.aib.msf.security.jwt.JwtAuthorizationFilter;
import ie.aib.msf.security.jwt.JwtExtractor;
import ie.aib.msf.security.jwt.JwtValidator;
import ie.aib.msf.security.jwt.audit.JwtAuthenticationEventPublisher;
import ie.aib.msf.security.jwt.extractors.HttpHeaderJwtExtractor;
import ie.aib.msf.security.jwt.extractors.JsonPathJwtExtractor;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.validators.ClaimsValidator;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

/**
 * AutoConfiguration Class for Validating JWTs
 */
@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
@ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "enabled", matchIfMissing = true)
@AutoConfigureBefore(SecurityAutoConfiguration.class)
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class JwtSecurityAutoConfiguration {

    private final JwtSecurityProperties jwtSecurityProperties;

    private List<ClaimsValidator> claimsValidators;

    @Autowired
    public JwtSecurityAutoConfiguration(JwtSecurityProperties jwtSecurityProperties) {
        this.jwtSecurityProperties = jwtSecurityProperties;
    }

    @Autowired(required = false)
    void setClaimsValidators(List<ClaimsValidator> claimsValidators) {
        this.claimsValidators = claimsValidators;
    }

    @ConditionalOnMissingBean(JwtValidator.class)
    @Autowired
    @Bean
    JwtValidator jwtValidator(SigningKeyResolverAdapter signingKeyResolver,
            JwtSecurityProperties jwtSecurityProperties) {
        return new DefaultJwtValidatorImpl(signingKeyResolver, jwtSecurityProperties, claimsValidators);
    }

    @ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "location", havingValue = "BODY")
    @ConditionalOnMissingBean(JwtExtractor.class)
    @Bean
    JwtExtractor jsonPathJwtExtractor() {
        return new JsonPathJwtExtractor(jwtSecurityProperties);
    }

    @ConditionalOnProperty(prefix = "ie.aib.msf.security.jwt", name = "location", havingValue = "HEADER",
            matchIfMissing = true)
    @ConditionalOnMissingBean(JwtExtractor.class)
    @Bean
    JwtExtractor jwtExtractor() {
        return new HttpHeaderJwtExtractor(jwtSecurityProperties);
    }

    @Bean
    JwtAuthorizationFilter jwtAuthorizationFilter(ApplicationEventPublisher eventPublisher) {
        return new JwtAuthorizationFilter(jwtSecurityProperties, eventPublisher);
    }

    @ConditionalOnMissingBean(AuthenticationEventPublisher.class)
    @Bean
    JwtAuthenticationEventPublisher authenticationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        return new JwtAuthenticationEventPublisher(applicationEventPublisher);
    }
}