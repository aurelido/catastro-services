package ie.aib.msf.security.jwt;

import ie.aib.msf.security.jwt.exception.JwtAuthorizationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import ie.aib.msf.security.jwt.validators.ClaimsAuthorizationValidator;
import io.jsonwebtoken.Claims;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.access.event.AuthorizationFailureEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.FilterInvocation;
import org.springframework.web.filter.GenericFilterBean;

/**
 * Filter to provide authorization based on JWT claims.<br/>
 * <p/>
 * This filter tests checks authorization for every resource in a service annotated with
 * {@link ie.aib.msf.security.jwt.annotation.JwtAuthorization} <br/>
 * <br/>
 * For more fine grained authorization, use Spring Security's
 * {@link org.springframework.security.access.prepost.PreAuthorize} mechanism
 */
public class JwtAuthorizationFilter extends GenericFilterBean {

    private static final Log LOG = LogFactory.getLog(JwtAuthorizationFilter.class);

    private final JwtSecurityProperties jwtSecurityProperties;
    private final ApplicationEventPublisher eventPublisher;
    private List<ClaimsAuthorizationValidator> claimsAuthorizationValidators;

    public JwtAuthorizationFilter(JwtSecurityProperties jwtSecurityProperties,
            ApplicationEventPublisher eventPublisher) {
        this.jwtSecurityProperties = jwtSecurityProperties;
        this.eventPublisher = eventPublisher;
    }

    @Autowired(required = false)
    public void setClaimsAuthorizationValidators(List<ClaimsAuthorizationValidator> claimsAuthorizationValidators) {
        this.claimsAuthorizationValidators = claimsAuthorizationValidators;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication instanceof JwtAuthenticationToken) {
            Claims claims = ((JwtAuthenticationToken) authentication).getClaims();
            validateClaims((JwtAuthenticationToken) authentication, claims, request, response, chain);
        }
        chain.doFilter(request, response);
    }

    private void validateClaims(JwtAuthenticationToken authentication, Claims claims, ServletRequest request,
            ServletResponse response, FilterChain chain) {
        if (claimsAuthorizationValidators != null) {
            for (ClaimsAuthorizationValidator validator : claimsAuthorizationValidators) {
                try {
                    validator.validate(claims);
                } catch (JwtAuthorizationException e) {
                    handleAuthorizationException(authentication, e, request, response, chain);
                    return;
                }
            }
        }
    }

    private void handleAuthorizationException(JwtAuthenticationToken authentication, JwtAuthorizationException e,
            ServletRequest request, ServletResponse response, FilterChain chain) {
        if (LOG.isWarnEnabled()) {
            LOG.warn(e.getMessage(), e);
        }
        if (jwtSecurityProperties.isSuppressErrorMessageDetail()) {
            e = new JwtAuthorizationException("Forbidden");
        }

        if (jwtSecurityProperties.getAudit().isEnabled()) {
            FilterInvocation fi = new FilterInvocation(request, response, chain);
            eventPublisher.publishEvent(new AuthorizationFailureEvent(fi, Collections.emptyList(), authentication, e));
        }
        throw e;
    }
}