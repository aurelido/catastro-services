package ie.aib.msf.security.jwt;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * Authentication Provider for JWT
 */
public class JwtAuthenticationProvider implements AuthenticationProvider {

    private final JwtValidator jwtValidator;

    public JwtAuthenticationProvider(JwtValidator jwtValidator) {
        this.jwtValidator = jwtValidator;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String authToken = ((JwtAuthenticationToken) authentication).getToken();
        JwtUserDetails jwtUserDetails = jwtValidator.validateAndParseToken(authToken);
        JwtAuthenticationToken validatedToken = new JwtAuthenticationToken(authToken, jwtUserDetails);
        validatedToken.setDetails(authentication.getDetails());
        return validatedToken;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return JwtAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
