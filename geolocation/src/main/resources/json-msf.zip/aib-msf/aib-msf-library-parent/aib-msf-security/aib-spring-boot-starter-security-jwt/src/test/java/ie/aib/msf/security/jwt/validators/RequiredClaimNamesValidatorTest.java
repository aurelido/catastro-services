package ie.aib.msf.security.jwt.validators;

import ie.aib.msf.security.jwt.exception.JwtValidationException;
import ie.aib.msf.security.jwt.properties.JwtSecurityProperties;
import io.jsonwebtoken.impl.DefaultClaims;
import java.util.Collections;
import org.junit.Test;

public class RequiredClaimNamesValidatorTest {

    private JwtSecurityProperties properties = new JwtSecurityProperties();
    private RequiredClaimNamesValidator validator = new RequiredClaimNamesValidator(properties);

    @Test(expected = JwtValidationException.class)
    public void validateWithMissingClaim() {
        properties.setRequiredClaimNames(Collections.singleton("testClaim"));
        DefaultClaims defaultClaims = new DefaultClaims();
        defaultClaims.put("testClaim2", "testValue");
        validator.validate(defaultClaims);
    }

    @Test
    public void validateWithExpectedClaim() {
        properties.setRequiredClaimNames(Collections.singleton("testClaim"));
        DefaultClaims defaultClaims = new DefaultClaims();
        defaultClaims.put("testClaim", "testValue");
        validator.validate(defaultClaims);
    }
}