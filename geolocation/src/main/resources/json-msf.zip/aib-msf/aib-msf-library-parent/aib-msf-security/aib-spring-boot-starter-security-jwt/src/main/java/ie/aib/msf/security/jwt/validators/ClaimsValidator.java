package ie.aib.msf.security.jwt.validators;

import ie.aib.msf.security.jwt.exception.JwtValidationException;
import io.jsonwebtoken.Claims;

@FunctionalInterface
public interface ClaimsValidator {

    /**
     * Validate JWT claims.
     * <p/>
     * Implementations of this class should throw {@link JwtValidationException} if the JWT is not valid.<br/>
     * This will result in an Unauthorized (401) response status.
     *
     * @param claims The claims retrieved from the JWT
     * @throws JwtValidationException if claims are not valid
     */
    void validate(Claims claims) throws JwtValidationException;
}
