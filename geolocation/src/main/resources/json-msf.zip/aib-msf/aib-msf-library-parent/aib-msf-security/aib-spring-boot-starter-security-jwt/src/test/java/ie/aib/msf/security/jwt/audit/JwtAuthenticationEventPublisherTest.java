package ie.aib.msf.security.jwt.audit;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import ie.aib.msf.security.jwt.JwtAuthenticationToken;
import ie.aib.msf.security.jwt.exception.JwtTokenMalformedException;
import org.junit.Test;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;

public class JwtAuthenticationEventPublisherTest {

    @Test
    public void publishAuthenticationFailure() {

        ApplicationEventPublisher applicationEventPublisher = mock(ApplicationEventPublisher.class);
        JwtAuthenticationEventPublisher jwtAuthenticationEventPublisher = new JwtAuthenticationEventPublisher(
                applicationEventPublisher);

        jwtAuthenticationEventPublisher.publishAuthenticationFailure(new JwtTokenMalformedException("test"), mock(
                JwtAuthenticationToken.class));

        verify(applicationEventPublisher).publishEvent(any(AuthenticationFailureBadCredentialsEvent.class));
    }
}