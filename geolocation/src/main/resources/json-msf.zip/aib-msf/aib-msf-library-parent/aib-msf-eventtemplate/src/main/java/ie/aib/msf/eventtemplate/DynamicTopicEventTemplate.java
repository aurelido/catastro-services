package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

/**
 * EventTemplate for sending an event to a dynamic topic
 */
public interface DynamicTopicEventTemplate {

    /**
     * Send an event to a topic dynamically
     *
     * @param entry The event
     * @param topic The Kafka topic
     */
    void send(AbstractLogEntry entry, String topic);

    /**
     * Send an event to a topic dynamically, and return a ListenableFuture
     *
     * @param entry The event
     * @param topic The Kafka topic
     * @return A Future for the {@link SendResult}
     */
    ListenableFuture<SendResult<byte[], byte[]>> sendAsync(AbstractLogEntry entry, String topic);
}
