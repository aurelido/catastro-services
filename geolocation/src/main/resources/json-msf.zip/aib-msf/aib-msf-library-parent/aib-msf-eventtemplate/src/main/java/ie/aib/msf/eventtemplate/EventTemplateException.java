package ie.aib.msf.eventtemplate;

public class EventTemplateException extends RuntimeException {

    public EventTemplateException() {
        super();
    }

    public EventTemplateException(String message) {
        super(message);
    }

    public EventTemplateException(String message, Throwable cause) {
        super(message, cause);
    }

    public EventTemplateException(Throwable cause) {
        super(cause);
    }
}
