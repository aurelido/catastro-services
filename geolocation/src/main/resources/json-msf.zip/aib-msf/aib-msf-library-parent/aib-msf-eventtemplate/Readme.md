##Event Template

The EventTemplate writes events based on: [Event Bus Standards](https://wiki.aib.pri/display/SDA/Event+Bus+Standards+v2.0)

By including the project in your pom, the EventTemplate is automatically configured using [Spring Cloud Stream](http://docs.spring.io/spring-cloud-stream/docs/current/reference/htmlsingle/)

###Channels

There are 5 channels defined, which map to topics on Kafka : 

Channel | Topic
--- | ---
`application` | ${PREFIX}_applog
`audit` | ${PREFIX}_audit
`business` | ${PREFIX}_business
`notification` | ${PREFIX}_notification
`performance` | ${PREFIX}_perf

Where PREFIX is defined by `ie.aib.msf.eventtemplate.prefix`, which is a required property.

Events are written as `json` converted to `byte[]`

[Spring Cloud Stream writes embedded headers to the payload by default](http://docs.spring.io/spring-cloud-stream/docs/current/reference/htmlsingle/#_producer_properties), but this has been disabled for the EventTemplate. 

###Configuration

The only properties that should need to be set are:

Property | Description
--- | ---
`spring.cloud.stream.kafka.binder.brokers` | The address(es) of the Kafka broker(s),
`spring.cloud.stream.kafka.binder.autoCreateTopics` | Set to `false` to disable autocreation of topics on Kafka (and disable the need to specify the Zookeeper address)
`ie.aib.msf.eventtemplate.prefix` | The topic prefix
`ie.aib.msf.eventtemplate.enabledChannels` | A comma-separated list of the channels to enable. Valid values are the 5 channels listed above. They are disabled by default, due to Spring Cloud Stream not supporting late binding of channels.
`ie.aib.msf.eventtemplate.appVersion` | The application version
`spring.application.name` | The application name. This is a standard Spring Boot setting, but is used by the EventTemplate to determine the application name

Any other Kafka configuration can be done through the Spring Cloud Stream Kafka Binder.

###Interfaces
There are two main interfaces that can be wired into applications.

Interface | Description
--- | ---
`EventTemplate` | This providers methods to send to channels bound to each of the 5 topics above
`KafkaEventTemplate` | This extends `EventTemplate`, but also adds methods to send to topics dynamically, by specifying the topic name in the method signature. The Kafka Producer in this case uses the default properties configured by the Spring Cloud Stream Kafka Binder. See [Kafka Binder Properties](http://docs.spring.io/spring-cloud-stream/docs/current/reference/htmlsingle/#_kafka_binder_properties)

###Notes
1. If testing with Kafka on Docker, application startup can seen slow. This is because when the application creates a new KafkaProducer, there is a reverse lookup on the IP address of the Docker Machine (typically 192.168.99.100).

    Due to some DNS issue, the appears to be very slow. Adding an entry in your `hosts` file for the Docker Machine should solve the problem.


2. The EventTemplate uses `kafka` as the binder by default. This should be fine in most cases, but if your application has multiple binders (e.g. two separate kafka instances), then the properties may need to be overwritten.
    e.g. `spring.cloud.stream.bindings.application.binder=kafka` would need to be set the name of your new binder.