package ie.aib.msf.eventtemplate.channels;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface AuditChannel {

    String AUDIT = "audit";

    //Suppress Sonar warning about field and method names being the same
    @SuppressWarnings("squid:S1845")
    @Output(AUDIT)
    MessageChannel audit();
}
