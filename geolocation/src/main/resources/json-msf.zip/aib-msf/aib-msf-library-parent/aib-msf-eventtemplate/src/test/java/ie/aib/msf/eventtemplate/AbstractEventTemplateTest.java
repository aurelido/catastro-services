package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {AbstractEventTemplateTest.TestConfiguration.class, TestEventTemplateApplication.class})
public class AbstractEventTemplateTest {

    @Autowired
    TestEventTemplate testEventTemplate;
    @Autowired
    private ObjectMapperHelper objectMapperHelper;

    @Test
    public void testFormatOfOutputJson() {

        testEventTemplate.application(LogLevel.CRITICAL, "myEvent", "some mesage", "my payload");

        String entryString = testEventTemplate.getEntryString();

        Assert.assertTrue(entryString.contains("\"type\":\"application\""));
        Assert.assertTrue(entryString.contains("\"severity\":\"critical\""));
    }

    @Test
    public void testDeserializationOfMixedCaseEventLogEntry() {

        String eventLogJson =
                "{\"type\":\"application\",\"severity\":\"critical\",\"timestamp\":\"2016-11-02T16:02:08.051+0000\",\"host\":\"DSK-7TVRBB2.prd.aib.pri\",\"ip\":\"10.28.123.213\",\"eventType\":\"myEvent\",\"application\":\"aib-msf-eventtemplate\",\"appVersion\":\"1.0.0\",\"message\":\"some mesage\",\"payload\":\"my payload\",\"topic\":\"application\",\"version\":\"v1.0\"}";

        ApplicationLogEntry applicationLogEntry = objectMapperHelper.fromJson(eventLogJson, ApplicationLogEntry.class);

        Assert.assertEquals(LogLevel.CRITICAL, applicationLogEntry.getSeverity());
    }

    @Configuration
    static class TestConfiguration {

        @Value("${spring.application.name}")
        private String appName;

        @Value("${ie.aib.msf.eventtemplate.appVersion}")
        private String appVersion;

        @Autowired
        private ObjectMapperHelper objectMapperHelper;

        @Bean
        public EventTemplate testEventTemplate() {
            return new TestEventTemplate(appName, appVersion, objectMapperHelper, null);
        }
    }
}
