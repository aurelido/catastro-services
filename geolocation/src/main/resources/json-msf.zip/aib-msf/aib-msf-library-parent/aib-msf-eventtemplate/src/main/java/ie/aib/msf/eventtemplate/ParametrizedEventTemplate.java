package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.MessageType;

/**
 * Event template for logging Audit, Event, Business, Performance and Application events
 */
public interface ParametrizedEventTemplate {

    /**
     * Send an audit
     *
     * @param logLevel The send level
     * @param eventType The type of event
     * @param message A text description of the send
     * @param payload The send payload
     * @param messageType The message type
     * @param content The content of the request
     * @param contentType the content type of the request
     */

    void audit(LogLevel logLevel, String eventType, String message, Object payload, MessageType messageType,
            Object content, String contentType);

    /**
     * Send a notification
     *
     * @param logLevel The send level
     * @param eventType The type of event
     * @param message A text description of the send
     * @param payload The send payload
     */
    void notification(LogLevel logLevel, String eventType, String message, Object payload);

    /**
     * Send a business event
     *
     * @param logLevel The send level
     * @param eventType The type of event
     * @param message A text description of the send
     * @param payload The send payload
     */
    void business(LogLevel logLevel, String eventType, String message, Object payload);

    /**
     * Send a performance event
     *
     * @param logLevel The send level
     * @param eventType The type of event
     * @param message A text description of the send
     * @param payload The send payload
     */
    void performance(LogLevel logLevel, String eventType, String message, Object payload);

    /**
     * Send an application event
     *
     * @param logLevel The send level
     * @param eventType The type of event
     * @param message A text description of the send
     * @param payload The send payload
     */
    void application(LogLevel logLevel, String eventType, String message, Object payload);
}
