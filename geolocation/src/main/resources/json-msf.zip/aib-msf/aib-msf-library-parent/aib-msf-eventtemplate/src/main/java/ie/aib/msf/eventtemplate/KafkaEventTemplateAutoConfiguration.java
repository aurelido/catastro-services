package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.conditions.ConditionalOnPropertyList;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.eventtemplate.channels.ApplicationChannel;
import ie.aib.msf.eventtemplate.channels.AuditChannel;
import ie.aib.msf.eventtemplate.channels.BusinessChannel;
import ie.aib.msf.eventtemplate.channels.EventTemplateChannels;
import ie.aib.msf.eventtemplate.channels.NotificationChannel;
import ie.aib.msf.eventtemplate.channels.PerformanceChannel;
import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.binder.kafka.properties.KafkaBinderConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.ObjectUtils;

@SuppressWarnings("SpringJavaAutowiringInspection")
@Configuration
@ConditionalOnMissingBean(EventTemplate.class)
@PropertySource("classpath:/ie/aib/msf/eventtemplate/eventtemplate.properties")
@EnableConfigurationProperties({EventTemplateConfigurationProperties.class, KafkaBinderConfigurationProperties.class})
@ComponentScan(basePackageClasses = EventTemplateChannels.class)
public class KafkaEventTemplateAutoConfiguration {

    private final KafkaBinderConfigurationProperties kafkaBinderConfigurationProperties;
    @Value("${spring.application.name}")
    private String appName;
    private EventTemplateConfigurationProperties eventTemplateConfigurationProperties;

    @Autowired
    public KafkaEventTemplateAutoConfiguration(
            EventTemplateConfigurationProperties eventTemplateConfigurationProperties,
            KafkaBinderConfigurationProperties kafkaBinderConfigurationProperties) {
        this.eventTemplateConfigurationProperties = eventTemplateConfigurationProperties;
        this.kafkaBinderConfigurationProperties = kafkaBinderConfigurationProperties;
    }

    @Autowired
    @Bean
    KafkaEventTemplateImpl kafkaEventTemplate(ObjectMapperHelper objectMapperHelper,
            EventTemplateChannels eventTemplateChannels, KafkaTemplate<byte[], byte[]> kafkaTemplate) {
        return new KafkaEventTemplateImpl(appName, eventTemplateConfigurationProperties.getAppVersion(),
                objectMapperHelper, eventTemplateChannels, null, kafkaTemplate);
    }

    @ConditionalOnMissingBean(KafkaTemplate.class)
    @Bean
    KafkaTemplate<byte[], byte[]> defaultKafkaTemplate() {
        DefaultKafkaProducerFactory<byte[], byte[]> producerFB = getProducerFactory();
        return new KafkaTemplate<>(producerFB);
    }

    private DefaultKafkaProducerFactory<byte[], byte[]> getProducerFactory() {
        Map<String, Object> props = new HashMap<>();

        //Defaults taken from Spring Cloud Stream's KafkaMessageChannelBinder
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                this.kafkaBinderConfigurationProperties.getKafkaConnectionString());
        props.put(ProducerConfig.RETRIES_CONFIG, 0);
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 1);
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        props.put(ProducerConfig.ACKS_CONFIG,
                String.valueOf(this.kafkaBinderConfigurationProperties.getRequiredAcks()));

        if (!ObjectUtils.isEmpty(kafkaBinderConfigurationProperties.getConfiguration())) {
            props.putAll(kafkaBinderConfigurationProperties.getConfiguration());
        }
        return new DefaultKafkaProducerFactory<>(props);
    }

    @ConditionalOnPropertyList(name = "ie.aib.msf.eventtemplate.enabledChannels", havingValue = "APPLICATION")
    @EnableBinding(ApplicationChannel.class)
    static class ApplicationChannelBindingAutoConfiguration {

    }

    @ConditionalOnPropertyList(name = "ie.aib.msf.eventtemplate.enabledChannels", havingValue = "AUDIT")
    @EnableBinding(AuditChannel.class)
    static class AuditChannelBindingAutoConfiguration {

    }

    @ConditionalOnPropertyList(name = "ie.aib.msf.eventtemplate.enabledChannels", havingValue = "BUSINESS")
    @EnableBinding(BusinessChannel.class)
    static class BusinessChannelBindingAutoConfiguration {

    }

    @ConditionalOnPropertyList(name = "ie.aib.msf.eventtemplate.enabledChannels", havingValue = "NOTIFICATION")
    @EnableBinding(NotificationChannel.class)
    static class NotificationChannelBindingAutoConfiguration {

    }

    @ConditionalOnPropertyList(name = "ie.aib.msf.eventtemplate.enabledChannels", havingValue = "PERFORMANCE")
    @EnableBinding(PerformanceChannel.class)
    static class PerformanceChannelBindingAutoConfiguration {

    }
}
