package ie.aib.msf.eventtemplate.channels;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

@Component
public class EventTemplateChannels {

    private MessageChannel application;
    private MessageChannel audit;
    private MessageChannel business;
    private MessageChannel notification;
    private MessageChannel performance;

    public MessageChannel getApplication() {
        return application;
    }

    @Autowired(required = false)
    @Qualifier(ApplicationChannel.APPLICATION)
    public void setApplication(MessageChannel application) {
        this.application = application;
    }

    public MessageChannel getAudit() {
        return audit;
    }

    @Autowired(required = false)
    @Qualifier(AuditChannel.AUDIT)
    public void setAudit(MessageChannel audit) {
        this.audit = audit;
    }

    public MessageChannel getBusiness() {
        return business;
    }

    @Autowired(required = false)
    @Qualifier(BusinessChannel.BUSINESS)
    public void setBusiness(MessageChannel business) {
        this.business = business;
    }

    public MessageChannel getNotification() {
        return notification;
    }

    @Autowired(required = false)
    @Qualifier(NotificationChannel.NOTIFICATION)
    public void setNotification(MessageChannel notification) {
        this.notification = notification;
    }

    public MessageChannel getPerformance() {
        return performance;
    }

    @Autowired(required = false)
    @Qualifier(PerformanceChannel.PERFORMANCE)
    public void setPerformance(MessageChannel performance) {
        this.performance = performance;
    }
}
