package ie.aib.msf.eventtemplate;

/**
 * EventTemplate for Kafka, that Extends the default {@link EventTemplate}, but allows dynamically sending to a topic
 */
public interface KafkaEventTemplate extends EventTemplate, DynamicTopicEventTemplate {

}
