package ie.aib.msf.eventtemplate;

/**
 * Event template for logging Audit, Event, Business, Performance and Application events
 */
public interface EventTemplate extends ObjectEventTemplate, ParametrizedEventTemplate {

}
