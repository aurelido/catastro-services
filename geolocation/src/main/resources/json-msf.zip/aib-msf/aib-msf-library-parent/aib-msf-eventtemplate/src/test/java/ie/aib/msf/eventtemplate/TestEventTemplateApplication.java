package ie.aib.msf.eventtemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@EnableAutoConfiguration
public class TestEventTemplateApplication {

    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(TestEventTemplateApplication.class, args);
    }
}