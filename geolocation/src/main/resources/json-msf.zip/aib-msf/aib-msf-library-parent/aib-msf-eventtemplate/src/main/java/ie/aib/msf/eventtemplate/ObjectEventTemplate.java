package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.core.domain.model.event.entry.BusinessLogEntry;
import ie.aib.msf.core.domain.model.event.entry.NotificationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.PerformanceLogEntry;

public interface ObjectEventTemplate {

    /**
     * Send an event
     *
     * @param entry Entry to send
     */
    void send(AbstractLogEntry entry);

    /**
     * Send an audit
     *
     * @param auditLogEntry The audit send entry
     */
    void audit(AuditLogEntry auditLogEntry);

    /**
     * Send a notification
     *
     * @param notificationLogEntry The notification send entry
     */
    void notification(NotificationLogEntry notificationLogEntry);

    /**
     * Send a business event
     */
    void business(BusinessLogEntry businessLogEntry);

    /**
     * Send a performance event
     */
    void performance(PerformanceLogEntry performanceLogEntry);

    /**
     * Send an application event
     *
     * @param applicationLogEntry The application send entry
     */
    void application(ApplicationLogEntry applicationLogEntry);
}
