package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.eventtemplate.channels.EventTemplateChannels;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutionException;
import javax.validation.Validator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.MessageChannel;
import org.springframework.util.Assert;
import org.springframework.util.concurrent.ListenableFuture;

/**
 * Implementation of {@link KafkaEventTemplate}
 */
public class KafkaEventTemplateImpl extends AbstractEventTemplate implements KafkaEventTemplate {

    private static final Log LOG = LogFactory.getLog(KafkaEventTemplateImpl.class);

    private final EventTemplateChannels eventTemplateChannels;

    private final KafkaTemplate<byte[], byte[]> kafkaTemplate;

    /**
     * Create a new KafkaEventTenplateImpl instance.
     *
     * @param applicationName The application name
     * @param applicationVersion The application version
     * @param objectMapperHelper The objectMapperHelper instance for converting to/from Json
     * @param eventTemplateChannels The event template channels to instantiate
     * @param validator The object validator
     * @param kafkaTemplate The underlying KafkaTemplate instance
     */
    @SuppressWarnings("WeakerAccess")
    public KafkaEventTemplateImpl(String applicationName, String applicationVersion,
            ObjectMapperHelper objectMapperHelper, EventTemplateChannels eventTemplateChannels, Validator validator,
            KafkaTemplate<byte[], byte[]> kafkaTemplate) {
        super(applicationName, applicationVersion, objectMapperHelper, validator);
        this.eventTemplateChannels = eventTemplateChannels;
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    protected void innerLog(AbstractLogEntry entry, String entryString) {
        MessageChannel channel;
        switch (entry.getType()) {
            case APPLICATION:
                channel = eventTemplateChannels.getApplication();
                break;
            case AUDIT:
                channel = eventTemplateChannels.getAudit();
                break;
            case BUSINESS:
                channel = eventTemplateChannels.getBusiness();
                break;
            case NOTIFICATION:
                channel = eventTemplateChannels.getNotification();
                break;
            case PERFORMANCE:
                channel = eventTemplateChannels.getPerformance();
                break;
            default:
                throw new EventTemplateException("Undefined send entry type: " + entry.getType());
        }

        if (channel == null) {
            throw new EventTemplateException("Event Template disabled for event type: " + entry.getType());
        }

        try {
            boolean sent = channel.send(MessageBuilder.withPayload(entryString.getBytes(StandardCharsets.UTF_8))
                    .build());

            if (!sent) {
                LOG.debug("unable to send event to Kafka: " + entryString);
                throw new EventTemplateException("Failed to send message to eventtemplate: " + entry);
            }
        } catch (Exception e) {
            throw new EventTemplateException(e);
        }
    }

    @Override
    public void send(AbstractLogEntry entry, String topic) {
        ListenableFuture<SendResult<byte[], byte[]>> listenableFuture = sendAsync(entry, topic);
        try {
            RecordMetadata recordMetadata = listenableFuture.get().getRecordMetadata();

            if (LOG.isDebugEnabled() && recordMetadata != null) {
                LOG.debug(
                        "Sent message to Kakfa partition: " + recordMetadata.partition() + ", offset: " + recordMetadata
                                .offset());
            }

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new EventTemplateException("Thread interrupted while waiting to receive ack from send to Kafka topic",
                    e);
        } catch (ExecutionException e) {
            throw new EventTemplateException("Unable to get result of ack from send to Kafka topic", e);
        }
    }

    @Override
    public ListenableFuture<SendResult<byte[], byte[]>> sendAsync(AbstractLogEntry entry, String topic) {
        Assert.notNull(entry, "entry must not be null");
        Assert.notNull(topic, "topic must not be null");
        String entryString = getObjectMapperHelper().toJson(entry);
        return kafkaTemplate.send(topic, entryString.getBytes(StandardCharsets.UTF_8));
    }
}
