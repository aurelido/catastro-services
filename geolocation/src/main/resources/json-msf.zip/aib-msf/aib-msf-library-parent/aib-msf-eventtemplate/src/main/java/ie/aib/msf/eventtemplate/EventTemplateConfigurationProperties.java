package ie.aib.msf.eventtemplate;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "ie.aib.msf.eventtemplate")
public class EventTemplateConfigurationProperties {

    private String prefix;

    private String appVersion;

    private List<String> enabledChannels;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public List<String> getEnabledChannels() {
        return enabledChannels;
    }

    public void setEnabledChannels(List<String> enabledChannels) {
        this.enabledChannels = enabledChannels;
    }
}
