package ie.aib.msf.eventtemplate;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.MessageType;
import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.core.domain.model.event.entry.BusinessLogEntry;
import ie.aib.msf.core.domain.model.event.entry.NotificationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.PerformanceLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.eventtemplate.channels.EventTemplateChannels;
import java.util.concurrent.ExecutionException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.util.concurrent.ListenableFuture;

@RunWith(MockitoJUnitRunner.class)
public class KafkaEventTemplateTest {

    @Mock
    private EventTemplateChannels eventTemplateChannels;

    @Mock
    private MessageChannel applicationChannel;

    @Mock
    private MessageChannel auditChannel;

    @Mock
    private MessageChannel businessChannel;

    @Mock
    private MessageChannel notificationChannel;

    @Mock
    private MessageChannel performanceChannel;

    @Mock
    private KafkaTemplate<byte[], byte[]> kafkaTemplate;

    private KafkaEventTemplateImpl kafkaEventTemplate;

    private ListenableFuture<SendResult<byte[], byte[]>> listenableFuture;

    @Before
    @SuppressWarnings("unchecked")
    public void initMock() throws ExecutionException, InterruptedException {
        String applicationName = "testAppName";
        String applicationVersion = "1.0.TEST";
        kafkaEventTemplate = new KafkaEventTemplateImpl(applicationName, applicationVersion, new ObjectMapperHelper(),
                eventTemplateChannels, null, kafkaTemplate);

        //channnels
        when(eventTemplateChannels.getApplication()).thenReturn(applicationChannel);
        when(eventTemplateChannels.getAudit()).thenReturn(auditChannel);
        when(eventTemplateChannels.getBusiness()).thenReturn(businessChannel);
        when(eventTemplateChannels.getNotification()).thenReturn(notificationChannel);
        when(eventTemplateChannels.getPerformance()).thenReturn(performanceChannel);

        //sending results
        when(applicationChannel.send(any(Message.class))).thenReturn(true);
        when(auditChannel.send(any(Message.class))).thenReturn(true);
        when(businessChannel.send(any(Message.class))).thenReturn(true);
        when(notificationChannel.send(any(Message.class))).thenReturn(true);
        when(performanceChannel.send(any(Message.class))).thenReturn(true);

        listenableFuture = mock(ListenableFuture.class);
        when(listenableFuture.get()).thenReturn(mock(SendResult.class));
        when(kafkaTemplate.send(anyString(), any(byte[].class))).thenReturn(listenableFuture);
    }

    @Test
    public void testParametrizedApplicationLog() throws Exception {
        kafkaEventTemplate
                .application(LogLevel.INFO, "testApplication", "test application message", "test application payload");
        verify(applicationChannel).send(any(Message.class));
    }

    @Test
    public void testSendLogEntryToApplicationChannel() throws Exception {
        sendApplicationLog();
        verify(applicationChannel).send(any(Message.class));
    }

    @Test(expected = EventTemplateException.class)
    public void testSendingFailureThrowsException() throws Exception {
        when(applicationChannel.send(any(Message.class))).thenReturn(false);
        sendApplicationLog();
    }

    @Test
    public void testParametrizedAuditLog() {
        kafkaEventTemplate
                .audit(LogLevel.WARNING, "testAudit", "test audit message", "test audit payload", MessageType.NOTIFY,
                        "test audit content", "text/plain");
        verify(auditChannel).send(any(Message.class));
    }

    @Test
    public void testSendLogEntryToAuditChannel() {
        kafkaEventTemplate.audit(AuditLogEntry.builder().message("audit message").build());
        verify(auditChannel).send(any(Message.class));
    }

    @Test
    public void testParametrizedBusinessLog() {
        kafkaEventTemplate
                .business(LogLevel.CRITICAL, "testBusiness", "test business message", "test business payload");
        verify(businessChannel).send(any(Message.class));
    }

    @Test
    public void testSendLogEntryToBusinessChannel() {
        kafkaEventTemplate.business(BusinessLogEntry.builder().message("audit message").build());
        verify(businessChannel).send(any(Message.class));
    }

    @Test
    public void testParametrizedNotificationLog() {
        kafkaEventTemplate.notification(LogLevel.DEBUG, "testNotification", "test notification message",
                "test notification payload");
        verify(notificationChannel).send(any(Message.class));
    }

    @Test
    public void testSendLogEntryToNotificationChannel() {
        kafkaEventTemplate.notification(NotificationLogEntry.builder().message("audit message").build());
        verify(notificationChannel).send(any(Message.class));
    }

    @Test
    public void testParametrizedPerformanceLog() {
        kafkaEventTemplate
                .performance(LogLevel.ERROR, "testPerformance", "test performance message", "test performance payload");
        verify(performanceChannel).send(any(Message.class));
    }

    @Test
    public void testSendLogEntryToPerformanceChannel() {
        kafkaEventTemplate.performance(PerformanceLogEntry.builder().message("audit message").build());
        verify(performanceChannel).send(any(Message.class));
    }

    @Test
    public void testSendingToDynamicTopic() {
        kafkaEventTemplate.send(ApplicationLogEntry.builder().severity(LogLevel.INFO).eventType("test event")
                .message("test message").build(), "testtopic");
        verify(kafkaTemplate).send(anyString(), any(byte[].class));
    }

    @Test
    public void testSendingToDynamicTopicAsync() {
        ListenableFuture<SendResult<byte[], byte[]>> listenableFuture = kafkaEventTemplate.sendAsync(
                ApplicationLogEntry.builder().severity(LogLevel.INFO).eventType("test event").message("test message")
                        .build(),
                "testtopic");
        assertNotNull(listenableFuture);
        verify(kafkaTemplate).send(anyString(), any(byte[].class));
    }

    @Test(expected = EventTemplateException.class)
    public void testSendingFailed() throws ExecutionException, InterruptedException {
        when(listenableFuture.get()).thenThrow(new ExecutionException("test", null));
        kafkaEventTemplate.send(ApplicationLogEntry.builder().severity(LogLevel.INFO).eventType("test event")
                .message("test message").build(), "testtopic");
    }

    private void sendApplicationLog() {
        ApplicationLogEntry applicationLogEntry = ApplicationLogEntry.builder()
                .severity(LogLevel.INFO)
                .eventType("")
                .message("")
                .build();

        kafkaEventTemplate.application(applicationLogEntry);
    }

}
