package ie.aib.msf.eventtemplate;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import java.util.Map;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestEventTemplateApplication.class},
        properties = {"spring.cloud.stream.kafka.binder.configuration.max.block.ms=1000"})
@DirtiesContext
public class KafkaEventTemplateIT {

    private static final String DYNAMIC_TOPIC = "dynamicTopic";
    private static final String TEST_MESSAGE = "testMessage";
    private static final String TEST_APPLICATION = "test_applog";
    @ClassRule
    public static final KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, TEST_APPLICATION, DYNAMIC_TOPIC);
    private static Consumer<String, String> consumer;

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Autowired
    KafkaEventTemplate eventTemplate;

    @BeforeClass
    public static void setupEnvironment() {
        System.setProperty("spring.cloud.stream.kafka.binder.auto-create-topics", "false");
        System.setProperty("spring.cloud.stream.kafka.binder.brokers", embeddedKafka.getBrokersAsString());
        Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("test", "false", embeddedKafka);
        DefaultKafkaConsumerFactory<String, String> cf = new DefaultKafkaConsumerFactory<>(
                consumerProps);
        consumer = cf.createConsumer();
    }

    @AfterClass
    public static void shutdownKafka() {
        embeddedKafka.getKafkaServer(0).shutdown();
    }

    @Test
    public void testSendApplicationLog() throws Exception {
        embeddedKafka.consumeFromAnEmbeddedTopic(consumer, TEST_APPLICATION);
        eventTemplate.application(ApplicationLogEntry.builder().message(TEST_MESSAGE).build());
        ConsumerRecords<String, String> consumerRecords = consumer.poll(1000);
        assertNotNull(consumerRecords);
        assertEquals(1, consumerRecords.count());

        String kafkaMessage = consumerRecords.iterator().next().value();

        assertThat(kafkaMessage, containsString(TEST_MESSAGE));
    }

    @Test(expected = EventTemplateException.class)
    public void testSendingToDisabledChannelFails() {
        String testMessage = "testMessage";
        eventTemplate.audit(AuditLogEntry.builder().message(testMessage).build());
    }

    @Test
    public void testSendToDynamicChannel() throws Exception {
        embeddedKafka.consumeFromAnEmbeddedTopic(consumer, DYNAMIC_TOPIC);
        eventTemplate.send(ApplicationLogEntry.builder().message(TEST_MESSAGE).build(), DYNAMIC_TOPIC);
        ConsumerRecords<String, String> consumerRecords = consumer.poll(1000);
        assertNotNull(consumerRecords);
        assertEquals(1, consumerRecords.count());

        String kafkaMessage = consumerRecords.iterator().next().value();

        assertThat(kafkaMessage, containsString(TEST_MESSAGE));
    }
}


