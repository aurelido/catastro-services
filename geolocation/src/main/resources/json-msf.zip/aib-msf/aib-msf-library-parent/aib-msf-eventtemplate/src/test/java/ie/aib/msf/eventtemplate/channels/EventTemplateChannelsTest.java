package ie.aib.msf.eventtemplate.channels;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import org.junit.Test;
import org.springframework.messaging.MessageChannel;

public class EventTemplateChannelsTest {

    @Test
    public void testCreateChannels() {
        MessageChannel application = mock(MessageChannel.class);
        MessageChannel audit = mock(MessageChannel.class);
        MessageChannel business = mock(MessageChannel.class);
        MessageChannel notification = mock(MessageChannel.class);
        MessageChannel performance = mock(MessageChannel.class);

        EventTemplateChannels channels = new EventTemplateChannels();
        channels.setApplication(application);
        channels.setAudit(audit);
        channels.setBusiness(business);
        channels.setNotification(notification);
        channels.setPerformance(performance);

        assertThat(channels.getApplication()).isEqualTo(application);
        assertThat(channels.getAudit()).isEqualTo(audit);
        assertThat(channels.getBusiness()).isEqualTo(business);
        assertThat(channels.getNotification()).isEqualTo(notification);
        assertThat(channels.getPerformance()).isEqualTo(performance);
    }

}