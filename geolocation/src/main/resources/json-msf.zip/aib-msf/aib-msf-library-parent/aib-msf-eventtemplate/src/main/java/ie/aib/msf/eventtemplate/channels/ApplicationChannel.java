package ie.aib.msf.eventtemplate.channels;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface ApplicationChannel {

    String APPLICATION = "application";

    //Suppress Sonar warning about field and method names being the same
    @SuppressWarnings("squid:S1845")
    @Output(APPLICATION)
    MessageChannel application();
}
