package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import javax.validation.Validator;

public class TestEventTemplate extends AbstractEventTemplate {

    private String entryString;

    public TestEventTemplate(String applicationName, String applicationVersion, ObjectMapperHelper objectMapperHelper,
            Validator validator) {
        super(applicationName, applicationVersion, objectMapperHelper, validator);
    }

    @Override
    protected void innerLog(AbstractLogEntry entry, String entryString) {
        this.entryString = entryString;
    }

    public String getEntryString() {
        return entryString;
    }

}
