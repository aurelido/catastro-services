package ie.aib.msf.eventtemplate.channels;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface BusinessChannel {

    String BUSINESS = "business";

    //Suppress Sonar warning about field and method names being the same
    @SuppressWarnings("squid:S1845")
    @Output(BUSINESS)
    MessageChannel business();
}
