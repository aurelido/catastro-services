package ie.aib.msf.eventtemplate;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.LogType;
import ie.aib.msf.core.domain.model.event.MessageType;
import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry.AbstractLogEntryBuilder;
import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry.AuditLogEntryBuilder;
import ie.aib.msf.core.domain.model.event.entry.BusinessLogEntry;
import ie.aib.msf.core.domain.model.event.entry.NotificationLogEntry;
import ie.aib.msf.core.domain.model.event.entry.PerformanceLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ValidationException;
import javax.validation.Validator;

/**
 * Implementation of {@link EventTemplate}
 */
public abstract class AbstractEventTemplate implements EventTemplate {

    private final Validator validator;

    private String applicationName;
    private String applicationVersion;

    private ObjectMapperHelper objectMapperHelper;

    /**
     * EventTemplate Implementation
     *
     * @param applicationName Application name
     * @param applicationVersion Application version
     * @param validator Validation engine to use. If null, no validation will be performed.
     */
    @SuppressWarnings("WeakerAccess")
    public AbstractEventTemplate(String applicationName, String applicationVersion,
            ObjectMapperHelper objectMapperHelper, Validator validator) {
        this.applicationName = applicationName;
        this.applicationVersion = applicationVersion;
        this.objectMapperHelper = objectMapperHelper;
        this.validator = validator;
    }

    @SuppressWarnings("WeakerAccess")
    public ObjectMapperHelper getObjectMapperHelper() {
        return objectMapperHelper;
    }

    @Override
    public void send(AbstractLogEntry entry) {

        setApplicationNameAndVersion(entry);
        if (validator != null) {
            Set<ConstraintViolation<AbstractLogEntry>> validationResults = validator.validate(entry);
            if (!validationResults.isEmpty()) {
                throw new ValidationException("Invalid send message: " + entry + ". Reason: " + validationResults);
            }
        }

        String entryString = objectMapperHelper.toJson(entry);
        innerLog(entry, entryString);
    }

    private void setApplicationNameAndVersion(AbstractLogEntry entry) {

        if (entry.getApplication() == null) {
            entry.setApplication(applicationName);
        }
        if (entry.getAppVersion() == null) {
            entry.setAppVersion(applicationVersion);
        }
    }

    protected abstract void innerLog(AbstractLogEntry entry, String entryString);

    @Override
    public void audit(LogLevel logLevel, String eventType, String message, Object payload, MessageType messageType,
            Object content, String contentType) {
        AuditLogEntryBuilder builder = (AuditLogEntryBuilder) createLogMessageBuilder(logLevel, eventType,
                LogType.AUDIT, message, payload);
        builder.messageType(messageType).contentType(contentType);

        builder.content(content);

        send(builder.build());
    }

    @Override
    public void audit(AuditLogEntry auditLogEntry) {
        send(auditLogEntry);
    }

    @Override
    public void notification(LogLevel logLevel, String eventType, String message, Object payload) {
        AbstractLogEntry eventMessage = createLogMessageBuilder(logLevel, eventType, LogType.NOTIFICATION, message,
                payload).build();
        send(eventMessage);
    }

    @Override
    public void notification(NotificationLogEntry notificationLogEntry) {
        send(notificationLogEntry);
    }

    @Override
    public void business(LogLevel logLevel, String eventType, String message, Object payload) {
        AbstractLogEntry businessMessage = createLogMessageBuilder(logLevel, eventType, LogType.BUSINESS, message,
                payload).build();

        send(businessMessage);
    }

    @Override
    public void business(BusinessLogEntry businessLogEntry) {
        send(businessLogEntry);
    }

    @Override
    public void performance(LogLevel logLevel, String eventType, String message, Object payload) {
        AbstractLogEntry performanceMessage = createLogMessageBuilder(logLevel, eventType, LogType.PERFORMANCE, message,
                payload).build();
        send(performanceMessage);
    }

    @Override
    public void performance(PerformanceLogEntry performanceLogEntry) {
        send(performanceLogEntry);
    }


    @Override
    public void application(LogLevel logLevel, String eventType, String message, Object payload) {
        AbstractLogEntry eventMessage = createLogMessageBuilder(logLevel, eventType, LogType.APPLICATION, message,
                payload).build();
        send(eventMessage);
    }

    @Override
    public void application(ApplicationLogEntry applicationLogEntry) {
        send(applicationLogEntry);
    }

    @SuppressWarnings("rawtypes")
    private AbstractLogEntryBuilder createLogMessageBuilder(LogLevel logLevel, String eventType, LogType type,
            String message, Object payload) {
        AbstractLogEntryBuilder logEntryBuilder = createLogEntryBuilder(type);
        logEntryBuilder.severity(logLevel)
                .application(applicationName)
                .appVersion(applicationVersion)
                .eventType(eventType)
                .message(message)
                .payload(payload);

        return logEntryBuilder;
    }

    @SuppressWarnings("rawtypes")
    private AbstractLogEntryBuilder createLogEntryBuilder(LogType type) {
        AbstractLogEntryBuilder logEntryBuilder;
        switch (type) {
            case APPLICATION:
                logEntryBuilder = ApplicationLogEntry.builder();
                break;
            case AUDIT:
                logEntryBuilder = AuditLogEntry.builder();
                break;
            case BUSINESS:
                logEntryBuilder = BusinessLogEntry.builder();
                break;
            case NOTIFICATION:
                logEntryBuilder = NotificationLogEntry.builder();
                break;
            case PERFORMANCE:
                logEntryBuilder = PerformanceLogEntry.builder();
                break;
            default:
                throw new UnsupportedOperationException("LogType not supported:" + type);
        }

        return logEntryBuilder;
    }
}
