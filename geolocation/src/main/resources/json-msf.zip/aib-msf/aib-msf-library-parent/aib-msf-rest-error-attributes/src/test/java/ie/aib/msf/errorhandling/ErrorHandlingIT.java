package ie.aib.msf.errorhandling;

import static org.assertj.core.api.Assertions.assertThat;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ErrorHandlingIT {

    @Autowired
    TestRestTemplate restTemplate;

    @Test
    public void testAnnotatedExceptionResponse() {
        String path = "/test/2";
        getAndValidateResponse(path, HttpStatus.BAD_REQUEST);
    }

    @Test
    public void testErrorDetailsExceptionResponse() {
        String path = "/test/2";
        getAndValidateResponse(path, HttpStatus.BAD_REQUEST);
    }

    @Test
    public void testErrorContextExceptionResponse() {
        String path = "/test/3";
        getAndValidateResponse(path, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private void getAndValidateResponse(String path, HttpStatus status) {
        String response = restTemplate.getForObject(path, String.class);
        assertThat(response).isNotNull();
        DocumentContext jsonContext = JsonPath.parse(response);
        assertThat(jsonContext.read("$.code", String.class)).isEqualTo(TestApplication.TEST_CODE);
        assertThat(jsonContext.read("$.message", String.class)).isEqualTo(TestApplication.TEST_MESSAGE);
        assertThat(jsonContext.read("$.info", String.class)).isEqualTo(TestApplication.TEST_INFO);
        assertThat(jsonContext.read("$.timestamp", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.uuid", String.class)).isNotEmpty();
        assertThat(jsonContext.read("$.error", String.class)).isEqualTo(status.getReasonPhrase());
        assertThat(jsonContext.read("$.status", Integer.class)).isEqualTo(status.value());
        assertThat(jsonContext.read("$.path", String.class)).isEqualTo(path);
    }
}
