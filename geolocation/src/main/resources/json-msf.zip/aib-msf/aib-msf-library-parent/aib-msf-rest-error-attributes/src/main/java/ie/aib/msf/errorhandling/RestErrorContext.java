package ie.aib.msf.errorhandling;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.WebRequest;

@SuppressWarnings({"unused", "WeakerAccess"})
public class RestErrorContext {

    private static final String NAMESPACE = "ie.aib.msf.errorhandling";
    private static final String CODE = NAMESPACE + ".code";
    private static final String INFO = NAMESPACE + ".info";

    //private constructor to disallow instantiation
    private RestErrorContext() {

    }

    public static void setCode(String errorCode) {
        getCurrentRequest().setAttribute(CODE, errorCode, WebRequest.SCOPE_REQUEST);
    }

    public static String getCode() {
        return (String) getCurrentRequest().getAttribute(CODE, WebRequest.SCOPE_REQUEST);
    }

    public static void setInfo(String info) {
        getCurrentRequest().setAttribute(INFO, info, WebRequest.SCOPE_REQUEST);
    }

    public static String getInfo() {
        return (String) getCurrentRequest().getAttribute(INFO, WebRequest.SCOPE_REQUEST);
    }

    private static RequestAttributes getCurrentRequest() {
        return RequestContextHolder.currentRequestAttributes();
    }

}
