package ie.aib.msf.errorhandling;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public class RestErrorAttributesTest {

    private static final String TEST_CODE = "400-1000-2000";
    private static final String UUID = "uuid";
    private static final String INFO = "info";
    private static final String CODE = "code";
    private static final String TEST_INFO = "test info";
    private static final String JAVAX_SERVLET_ERROR_EXCEPTION = "javax.servlet.error.exception";
    private RestErrorAttributes restErrorAttributes = new RestErrorAttributes();
    private RequestAttributes requestAttributes;

    @Before
    public void setup() {
        requestAttributes = mock(RequestAttributes.class);
        RequestContextHolder.setRequestAttributes(requestAttributes);
        when(requestAttributes.getAttribute("javax.servlet.error.status_code", RequestAttributes.SCOPE_REQUEST))
                .thenReturn(999);
        when(requestAttributes.getAttribute("javax.servlet.error.message", RequestAttributes.SCOPE_REQUEST))
                .thenReturn("test");
        when(requestAttributes.getAttribute("javax.servlet.error.request_uri", RequestAttributes.SCOPE_REQUEST))
                .thenReturn("/test");
    }

    @Test
    public void testAnnotatedExceptionWithInfo() {
        when(requestAttributes.getAttribute(JAVAX_SERVLET_ERROR_EXCEPTION, RequestAttributes.SCOPE_REQUEST))
                .thenReturn(new TestExceptionWithInfo());

        Map<String, Object> errorAttributes = restErrorAttributes.getErrorAttributes(requestAttributes, false);
        assertThat(errorAttributes.get(UUID)).isNotNull();
        assertThat(errorAttributes.get(INFO)).isEqualTo(TEST_INFO);
        assertThat(errorAttributes.get(CODE)).isEqualTo(TEST_CODE);
    }

    @Test
    public void testAnnotatedExceptionWithoutInfo() {
        when(requestAttributes.getAttribute(JAVAX_SERVLET_ERROR_EXCEPTION, RequestAttributes.SCOPE_REQUEST))
                .thenReturn(new TestExceptionWithoutInfo());
        Map<String, Object> errorAttributes = restErrorAttributes.getErrorAttributes(requestAttributes, false);
        assertThat(errorAttributes.get(UUID)).isNotNull();
        assertThat(errorAttributes.get(INFO)).isNull();
        assertThat(errorAttributes.get(CODE)).isEqualTo(TEST_CODE);
    }

    @Test
    public void testNonAnnotatedException() {
        when(requestAttributes.getAttribute(JAVAX_SERVLET_ERROR_EXCEPTION, RequestAttributes.SCOPE_REQUEST))
                .thenReturn(new RuntimeException());
        Map<String, Object> errorAttributes = restErrorAttributes.getErrorAttributes(requestAttributes, false);
        assertThat(errorAttributes.get(UUID)).isNotNull();
        assertThat(errorAttributes.get(INFO)).isNull();
        assertThat(errorAttributes.get(CODE)).isEqualTo("999-0000-0000");
    }

    @Test
    public void testErrorDetails() {
        when(requestAttributes.getAttribute(JAVAX_SERVLET_ERROR_EXCEPTION, RequestAttributes.SCOPE_REQUEST))
                .thenReturn(new TestExceptionWithDetails(TEST_CODE, TEST_INFO));
        Map<String, Object> errorAttributes = restErrorAttributes.getErrorAttributes(requestAttributes, false);
        assertThat(errorAttributes.get(UUID)).isNotNull();
        assertThat(errorAttributes.get(INFO)).isEqualTo(TEST_INFO);
        assertThat(errorAttributes.get(CODE)).isEqualTo(TEST_CODE);
    }

    @Test
    public void testErrorContext() {
        when(RestErrorContext.getCode()).thenReturn(TEST_CODE);
        when(RestErrorContext.getInfo()).thenReturn(TEST_INFO);
        Map<String, Object> errorAttributes = restErrorAttributes.getErrorAttributes(requestAttributes, false);
        assertThat(errorAttributes.get(UUID)).isNotNull();
        assertThat(errorAttributes.get(INFO)).isEqualTo(TEST_INFO);
        assertThat(errorAttributes.get(CODE)).isEqualTo(TEST_CODE);
    }

    @ErrorCode(code = TEST_CODE, info = TEST_INFO)
    private static class TestExceptionWithInfo extends RuntimeException {

    }

    @ErrorCode(TEST_CODE)
    private static class TestExceptionWithoutInfo extends RuntimeException {

    }

    private static class TestExceptionWithDetails extends RuntimeException implements RestErrorDetails {

        private String code;
        private String info;

        TestExceptionWithDetails(String code, String info) {
            this.code = code;
            this.info = info;
        }

        @Override
        public String getCode() {
            return code;
        }

        @Override
        public String getInfo() {
            return info;
        }
    }

}