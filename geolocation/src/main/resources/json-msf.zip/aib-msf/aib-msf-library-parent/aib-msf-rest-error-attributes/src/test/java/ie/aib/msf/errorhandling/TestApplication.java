package ie.aib.msf.errorhandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@RequestMapping("/test")
public class TestApplication {

    static final String TEST_CODE = "400-1000-2000";
    static final String TEST_MESSAGE = "test message";
    static final String TEST_INFO = "test info";

    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(TestApplication.class, args);
    }

    @GetMapping("/1")
    public String test1() {
        throw new TestException();
    }

    @GetMapping("/2")
    public String test2() {
        throw new TestException2();
    }

    @GetMapping("/3")
    public String test3() {
        RestErrorContext.setCode(TEST_CODE);
        RestErrorContext.setInfo(TEST_INFO);
        throw new RuntimeException(TEST_MESSAGE);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ErrorCode(code = TEST_CODE, info = TEST_INFO)
    private static class TestException extends RuntimeException {

        TestException() {
            super(TestApplication.TEST_MESSAGE);
        }
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private static class TestException2 extends RuntimeException implements RestErrorDetails {

        private String code;
        private String info;

        TestException2() {
            super(TestApplication.TEST_MESSAGE);
            this.code = TestApplication.TEST_CODE;
            this.info = TestApplication.TEST_INFO;
        }

        @Override
        public String getCode() {
            return code;
        }

        @Override
        public String getInfo() {
            return info;
        }
    }
}
