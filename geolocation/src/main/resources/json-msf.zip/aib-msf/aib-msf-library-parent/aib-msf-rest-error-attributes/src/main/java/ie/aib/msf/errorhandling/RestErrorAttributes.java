package ie.aib.msf.errorhandling;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;

/**
 * Standard REST error attributes for all errors returned from Spring
 */
public class RestErrorAttributes extends DefaultErrorAttributes {

    @Override
    public Map<String, Object> getErrorAttributes(RequestAttributes requestAttributes, boolean includeStackTrace) {
        Map<String, Object> errorAttributes = super.getErrorAttributes(requestAttributes, includeStackTrace);
        errorAttributes.put("uuid", UUID.randomUUID());

        Throwable error = getError(requestAttributes);
        addCode(errorAttributes, error);
        addInfo(errorAttributes, error);
        return errorAttributes;
    }

    private void addCode(Map<String, Object> errorAttributes, Throwable error) {
        Optional<String> codeOptional = Optional.ofNullable(RestErrorContext.getCode());
        String code = codeOptional.orElseGet(() -> getAttributeFromError(error, RestErrorDetails::getCode,
                ErrorCode::code));

        if (code == null) {
            code = errorAttributes.get("status") + "-0000-0000";
        }
        errorAttributes.put("code", code);
    }

    private void addInfo(Map<String, Object> errorAttributes, Throwable error) {
        Optional<String> infoOptional = Optional.ofNullable(RestErrorContext.getInfo());
        String info = infoOptional.orElseGet(() -> getAttributeFromError(error, RestErrorDetails::getInfo,
                ErrorCode::info));

        if (!StringUtils.isEmpty(info)) {
            errorAttributes.put("info", info);
        }
    }

    private String getAttributeFromError(Throwable error, Function<RestErrorDetails, String> errorDetailsFunction,
            Function<ErrorCode, String> errorCodeFunction) {
        String attribute = null;
        if (error != null) {
            if (error instanceof RestErrorDetails) {
                // if the error implements RestErrorDetails, use that as a higher precedence than the annotation
                attribute = errorDetailsFunction.apply((RestErrorDetails) error);
            } else {
                //otherwise, look for the ErrorCode annotation
                attribute = getAnnotationAttribute(error, errorCodeFunction);
            }
        }
        return attribute;
    }

    private String getAnnotationAttribute(Throwable error, Function<ErrorCode, String> attributeFunction) {
        String attribute = null;

        ErrorCode annotation = AnnotationUtils.findAnnotation(error.getClass(), ErrorCode.class);
        if (annotation != null) {
            attribute = attributeFunction.apply(annotation);
        }
        return attribute;
    }
}
