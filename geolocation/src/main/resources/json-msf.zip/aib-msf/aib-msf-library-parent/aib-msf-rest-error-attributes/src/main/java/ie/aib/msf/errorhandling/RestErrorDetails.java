package ie.aib.msf.errorhandling;

public interface RestErrorDetails {

    /**
     * Get the code
     * @return the code
     */
    String getCode();

    /**
     * Get the info message
     * @return the info message
     */
    String getInfo();

}
