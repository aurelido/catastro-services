package ie.aib.msf.errorhandling.autoconfigure;

import ie.aib.msf.errorhandling.RestErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class ErrorHandlingAutoConfiguration {

    @Bean
    ErrorAttributes errorAttributes() {
        return new RestErrorAttributes();
    }
}
