package ie.aib.msf.errorhandling;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class RestErrorContextTest {

    @Before
    public void setUp() throws Exception {
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(new MockHttpServletRequest()));
    }

    @Test
    public void testCode() {
        String code = "testCode";
        RestErrorContext.setCode(code);
        assertThat(RestErrorContext.getCode()).isEqualTo(code);
    }

    @Test
    public void testInfo() {
        String info = "testInfo";
        RestErrorContext.setInfo(info);
        assertThat(RestErrorContext.getInfo()).isEqualTo(info);
    }
}