package ie.aib.msf.kafka.server;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import kafka.admin.AdminUtils;
import kafka.admin.RackAwareMode;
import kafka.server.KafkaConfig;
import kafka.server.KafkaServer;
import kafka.utils.MockTime;
import kafka.utils.TestUtils;
import kafka.utils.Time;
import kafka.utils.ZKStringSerializer$;
import kafka.utils.ZkUtils;
import kafka.zk.EmbeddedZookeeper;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.apache.kafka.common.protocol.SecurityProtocol;
import scala.Option;

/**
 * Kafka / Zookeeper test server for unit testing
 */
public class KafkaTestServer {

    public static final int KAFKA_PORT = 9097;
    private static final String LOCALHOST = getLocalHostIp();
    private static final int SESSION_TIMEOUT = 30000;
    private static final int CONNECTION_TIMEOUT = 30000;
    private static final int METADATA_TIMEOUT = 5000;
    private static final int PARTITIONS = 1;
    private static final int REPLICATION_FACTOR = 1;
    private static final int PARTITION_NUMBER = 0;

    private KafkaServer kafkaServer;

    private EmbeddedZookeeper zkServer;

    /**
     * Create a new Kakfa test server instance with the specified topics.
     *
     * @param topics The topics to create
     */
    public KafkaTestServer(String... topics) {
        zkServer = new EmbeddedZookeeper();
        Option<SecurityProtocol> opSec = Option.apply(SecurityProtocol.PLAINTEXT);

        String zkConnectionString = LOCALHOST + ":" + zkServer.port();

        Properties brokerProperties = TestUtils.createBrokerConfig(
                // nodeId: Int,
                0,
                // zkConnect: String,
                zkConnectionString,
                // enableControlledShutdown: Boolean = true,
                true,
                // enableDeleteTopic: Boolean = false,
                false,
                // port: Int = RandomPort,
                KAFKA_PORT,
                // interBrokerSecurityProtocol: Option[SecurityProtocol] = None
                opSec,
                // trustStoreFile: Option[File] = None,
                null,
                null, // enablePlaintext: Boolean = true,
                true,
                // enableSaslPlaintext: Boolean = false,
                false,
                // saslPlaintextPort: Int = RandomPort,
                0,
                // enableSsl: Boolean = false,
                false,
                // sslPort: Int = RandomPort,
                0,
                // enableSaslSsl: Boolean = false,
                false,
                // saslSslPort: Int = RandomPort
                0,
                // Rack mode
                Option.apply("Enforced"));

        Time mock = new MockTime();
        KafkaConfig config = new KafkaConfig(brokerProperties);
        kafkaServer = TestUtils.createServer(config, mock);
        createTopics(zkConnectionString, topics);
    }

    private static String getLocalHostIp() {
        return InetAddress.getLoopbackAddress().getHostAddress();
    }

    private void createTopics(String zkConnectionString, String... topics) {
        List<KafkaServer> servers = new ArrayList<>();
        servers.add(kafkaServer);

        ZkClient zkClient = new ZkClient(zkConnectionString, SESSION_TIMEOUT, CONNECTION_TIMEOUT,
                ZKStringSerializer$.MODULE$);
        ZkConnection zkConnection = new ZkConnection(zkConnectionString);

        ZkUtils zkUtils = new ZkUtils(zkClient, zkConnection, false);

        if (topics != null) {
            for (String topic : topics) {
                createTopic(servers, zkUtils, topic);
            }
        }
    }

    private void createTopic(List<KafkaServer> servers, ZkUtils zkUtils, String topic) {

        AdminUtils.createTopic(zkUtils, topic, PARTITIONS, REPLICATION_FACTOR, new Properties(),
                RackAwareMode.Enforced$.MODULE$);

        TestUtils.waitUntilMetadataIsPropagated(scala.collection.JavaConversions.asScalaBuffer(servers), topic,
                PARTITION_NUMBER, METADATA_TIMEOUT);
    }

    public String getKafkaBrokerString() {
        return String.format("%s:%d", LOCALHOST, KAFKA_PORT);
    }

    public String getZkConnectString() {
        return String.format("%s:%d", LOCALHOST, zkServer.port());
    }

    public void stop() {
        kafkaServer.shutdown();
        zkServer.shutdown();
    }
}