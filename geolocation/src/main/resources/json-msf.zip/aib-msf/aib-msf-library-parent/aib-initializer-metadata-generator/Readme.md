# AIB Initializer Metadata Generator

This project generates and publishes metadata for the Spring Initializer project to use.

Each build updates the generated json metadata and publishes to the artifact repository.

Version updates are automatically taken care of, but new modules need to be manually added in `aib-metadata.json`, 
if they need to be made available as starters through the initializer