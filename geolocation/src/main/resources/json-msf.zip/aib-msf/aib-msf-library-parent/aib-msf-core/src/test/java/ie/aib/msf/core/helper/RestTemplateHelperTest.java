package ie.aib.msf.core.helper;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ie.aib.msf.core.domain.exceptions.http.BadRequestException;
import ie.aib.msf.core.domain.exceptions.http.ServiceUnavailableException;
import java.net.URI;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings("unchecked")
public class RestTemplateHelperTest {

    private RestTemplateHelper restTemplateHelper;
    private RestTemplate restTemplate;
    private static final String PROCESS = "test";
    private URI uri;

    @Before
    public void setUp() throws Exception {
        restTemplate = mock(RestTemplate.class);

        restTemplateHelper = new RestTemplateHelper(restTemplate);
        uri = new URI("http://test");
    }

    @Test
    public void getForEntity() throws Exception {
        restTemplateHelper.getForEntity(PROCESS, uri, String.class);
        verify(restTemplate, times(1)).exchange(any(), any(), any(), (Class<Object>) any());
    }

    @Test
    public void getForEntityWithEntity() throws Exception {
        RequestEntity<String> entity = new RequestEntity<>(HttpMethod.GET, uri);
        restTemplateHelper.getForEntity(PROCESS, uri, entity, String.class);
        verify(restTemplate, times(1)).exchange(any(), any(), any(), (Class<Object>) any());
    }

    @Test
    public void postForEntity() throws Exception {
        RequestEntity<String> entity = new RequestEntity<>(HttpMethod.POST, uri);
        restTemplateHelper.postForEntity(PROCESS, uri, entity, String.class);
        verify(restTemplate, times(1)).exchange(any(), any(), any(), (Class<Object>) any());
    }

    @Test
    public void exchange() throws Exception {
        RequestEntity<String> entity = new RequestEntity<>(HttpMethod.GET, uri);
        restTemplateHelper.exchange(HttpMethod.GET, PROCESS, uri, entity, String.class);
        verify(restTemplate, times(1)).exchange(any(), any(), any(), (Class<Object>) any());
    }

    @Test(expected = BadRequestException.class)
    public void testBadRequest() {
        when(restTemplate.exchange(any(), any(), any(), (Class<Object>) any()))
                .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
        RequestEntity<String> entity = new RequestEntity<>(HttpMethod.GET, uri);
        restTemplateHelper.exchange(HttpMethod.GET, PROCESS, uri, entity, String.class);
    }

    @Test(expected = ServiceUnavailableException.class)
    public void testServiceUnavailable() {
        when(restTemplate.exchange(any(), any(), any(), (Class<Object>) any()))
                .thenThrow(new IndexOutOfBoundsException());
        RequestEntity<String> entity = new RequestEntity<>(HttpMethod.GET, uri);
        restTemplateHelper.exchange(HttpMethod.GET, PROCESS, uri, entity, String.class);
    }
}