package ie.aib.msf.core.domain.exceptions.http;

public class UnauthorizedException extends AbstractResponseStatusException {

    private static final long serialVersionUID = -7568337166159003272L;

    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(Throwable cause) {
        super(cause);
    }

    public UnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }
}
