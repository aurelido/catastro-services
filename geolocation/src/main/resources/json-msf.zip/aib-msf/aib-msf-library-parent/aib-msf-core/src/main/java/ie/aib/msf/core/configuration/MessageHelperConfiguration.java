package ie.aib.msf.core.configuration;

import ie.aib.msf.core.helper.ObjectMapperHelper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MessageHelperConfiguration {

    @Bean
    public ObjectMapperHelper objectMapperHelper() {

        return new ObjectMapperHelper();
    }
}
