package ie.aib.msf.core.helper;

import static org.assertj.core.api.Assertions.assertThat;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.entry.ApplicationLogEntry;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import org.junit.Before;
import org.junit.Test;

public class ObjectMapperHelperTest {

    private ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper();
    private ApplicationLogEntry applicationLogEntry;

    @Before
    public void setup() {
        applicationLogEntry = ApplicationLogEntry.builder()
                .severity(LogLevel.INFO)
                .application("blah")
                .appVersion("1.0")
                .message("some payload")
                .build();
    }

    @Test
    public void validateDeserializeAndReserialize() {

        String json = objectMapperHelper.toJson(applicationLogEntry);

        ApplicationLogEntry logEntry = objectMapperHelper.fromJson(json, ApplicationLogEntry.class);
        assertThat(applicationLogEntry).isEqualTo(logEntry);
    }

    @Test
    public void testConvertValue() {
        assertThat(objectMapperHelper.convertValue(applicationLogEntry, ApplicationLogEntry.class)).isNotNull();
    }

    @Test
    public void testDecodeMessage() throws UnsupportedEncodingException {
        String message = "test";
        assertThat(objectMapperHelper.decodeMessage(message.getBytes(StandardCharsets.UTF_8))).isEqualTo(message);
    }

    @Test
    public void testToString() {
        String message = "test";
        assertThat(objectMapperHelper.toString(message)).isEqualTo("\"" + message + "\"");
    }

    @Test
    public void testToBytes() {
        String message = "test";
        assertThat(objectMapperHelper.toBytes(message))
                .isEqualTo(("\"" + message + "\"").getBytes(StandardCharsets.UTF_8));
    }

    @Test
    public void testPrettyPrint() {
        assertThat(objectMapperHelper.prettyPrint("test")).isNotEmpty();
    }

    @Test
    public void testXmlToJsonNode() throws IOException {
        assertThat(objectMapperHelper.xmlToJsonNode("<test>value</test>").toString()).isEqualTo("{\"test\":\"value\"}");
    }

    @Test
    public void testXmlToJsonString() throws IOException {
        assertThat(objectMapperHelper.xmlToJsonString("<test>value</test>")).isEqualTo("{\"test\":\"value\"}");
    }

    @Test
    public void testGetXpathStyleNode() throws IOException {
        assertThat(objectMapperHelper.getXPathStyleNode("{\"test\":\"value\"}", "/test")).isNotNull();
    }

    @Test
    public void testCopy() {
        assertThat(objectMapperHelper.copy(applicationLogEntry)).isEqualTo(applicationLogEntry);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFromInvalidJson() {
        objectMapperHelper.fromJson("test", Integer.class);
    }

}
