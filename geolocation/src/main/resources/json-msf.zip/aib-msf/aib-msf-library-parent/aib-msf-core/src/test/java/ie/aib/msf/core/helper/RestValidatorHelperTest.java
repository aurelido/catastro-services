package ie.aib.msf.core.helper;

import static org.assertj.core.api.Assertions.assertThat;

import ie.aib.msf.core.domain.exceptions.http.BadRequestWithBindingResultException;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

public class RestValidatorHelperTest {

    private RestValidatorHelper restValidatorHelper;

    @Before
    public void setUp() throws Exception {
        restValidatorHelper = new RestValidatorHelper(createTestValidator());
    }

    private Validator createTestValidator() {
        return new Validator() {
            @Override
            public boolean supports(Class<?> clazz) {
                return true;
            }

            @Override
            public void validate(Object target, Errors errors) {
                if(target.equals(String.class.getSimpleName())) {
                    ((BindingResult) errors).addError(new ObjectError("test", "error"));
                }
            }
        };
    }

    @Test(expected = BadRequestWithBindingResultException.class)
    public void validateAndThrowBadRequestInvalid() throws Exception {
        restValidatorHelper.validateAndThrowBadRequest("String");
    }

    @Test
    public void validateAndThrowBadRequestValid() {
        assertThat(restValidatorHelper.validateAndThrowBadRequest(1).hasErrors()).isEqualTo(false);
    }

    @Test
    public void validate() {
        assertThat(restValidatorHelper.validate(1).hasErrors()).isEqualTo(false);
    }

}