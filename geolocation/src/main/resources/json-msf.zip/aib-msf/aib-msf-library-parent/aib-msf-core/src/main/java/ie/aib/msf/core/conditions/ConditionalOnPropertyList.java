package ie.aib.msf.core.conditions;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Conditional;

/**
 * Similar to {@link org.springframework.boot.autoconfigure.condition.ConditionalOnProperty}, but tests for a (case
 * insensitive) value in a comma-separated list
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
@Documented
@Conditional(OnPropertyListCondition.class)
public @interface ConditionalOnPropertyList {

    /**
     * Name of the fully-qualified property to test
     *
     * @return the property to test
     */
    String name();

    /**
     * Value to check for, case insensitive
     *
     * @return the value to check for
     */
    String havingValue();
}
