package ie.aib.msf.core.domain.exceptions;

public class MicroservicesFrameworkRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public MicroservicesFrameworkRuntimeException() {
        super();

    }

    public MicroservicesFrameworkRuntimeException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public MicroservicesFrameworkRuntimeException(String message, Throwable cause) {
        super(message, cause);

    }

    public MicroservicesFrameworkRuntimeException(String message) {
        super(message);

    }

    public MicroservicesFrameworkRuntimeException(Throwable cause) {
        super(cause);

    }


}
