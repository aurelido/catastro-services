package ie.aib.msf.core.domain.exceptions.http;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Subclasses <strong>must</strong> be annotated with an appropriate @ResponseStatus(HttpStatus)
 */
@ResponseStatus(HttpStatus.NOT_IMPLEMENTED)
public abstract class AbstractResponseStatusException extends RuntimeException {

    private static final long serialVersionUID = -2650245013864070968L;

    public AbstractResponseStatusException() {
        super();
    }

    public AbstractResponseStatusException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public AbstractResponseStatusException(String message, Throwable cause) {
        super(message, cause);
    }

    public AbstractResponseStatusException(String message) {
        super(message);
    }

    public AbstractResponseStatusException(Throwable cause) {
        super(cause);
    }
}
