package ie.aib.msf.core.conditions;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

public class OnPropertyListConditionTest {

    private static final String TEST_PROPERTY = "testProperty";
    private OnPropertyListCondition onPropertyListCondition = new OnPropertyListCondition();
    private ConditionContext context;
    private AnnotatedTypeMetadata metadata;
    private MultiValueMap<String, Object> annotationAttributes;

    @Before
    public void setup() {
        setupMetadata();
        setupContext();
    }

    // Create the mock metadata
    private void setupMetadata() {
        metadata = mock(AnnotatedTypeMetadata.class);
        annotationAttributes = new LinkedMultiValueMap<>();
        List<Object> properties = new ArrayList<>();
        properties.add(TEST_PROPERTY);
        annotationAttributes.put("name", properties);

        when(metadata.getAllAnnotationAttributes(ConditionalOnPropertyList.class.getName())).thenReturn(
                annotationAttributes);
    }

    // Create the mock context
    private void setupContext() {
        context = mock(ConditionContext.class);
        StandardEnvironment environment = mock(StandardEnvironment.class);
        when(environment.containsProperty(TEST_PROPERTY)).thenReturn(true);
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty(TEST_PROPERTY, String.class)).thenReturn("testValue1,testValue2");
    }

    // Test that the list of values contains the expected value
    @Test
    public void testOutcomeMatches()  {
        List<Object> expectedValues = new ArrayList<>();
        expectedValues.add("testValue1");
        annotationAttributes.put("havingValue", expectedValues);
        assertThat(onPropertyListCondition.getMatchOutcome(context, metadata).isMatch())
                .isEqualTo(true);
    }

    // Test that the list of values does not contain an expected value
    @Test
    public void testOutcomeDoesNotMatch() {
        List<Object> expectedValues = new ArrayList<>();
        expectedValues.add("testValue3");
        annotationAttributes.put("havingValue", expectedValues);
        assertThat(onPropertyListCondition.getMatchOutcome(context, metadata).isMatch())
                .isEqualTo(false);
    }

}