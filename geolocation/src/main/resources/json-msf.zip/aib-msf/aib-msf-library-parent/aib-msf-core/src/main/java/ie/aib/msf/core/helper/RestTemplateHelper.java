package ie.aib.msf.core.helper;

import ie.aib.msf.core.domain.exceptions.http.BadRequestException;
import ie.aib.msf.core.domain.exceptions.http.ServiceUnavailableException;
import java.net.URI;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

public class RestTemplateHelper {

    private static final Log LOG = LogFactory.getLog(RestTemplateHelper.class);

    private RestTemplate restTemplate;

    public RestTemplateHelper(RestTemplate restTemplate) {
        Assert.notNull(restTemplate, "RestTemplate must not be null");
        this.restTemplate = restTemplate;
    }

    /**
     * Helper GET method that throws an AbstractResponseStatusException which can be used to return response codes
     * directly
     *
     * @see RestTemplate
     * @see DefaultResponseErrorHandler
     */
    public <T> ResponseEntity<T> getForEntity(String process, URI uri, Class<T> responseType)
            throws BadRequestException, ServiceUnavailableException {
        return getForEntity(process, uri, null, responseType);
    }

    /**
     * Helper GET method that throws an AbstractResponseStatusException which can be used to return response codes
     * directly
     *
     * @see RestTemplate
     * @see DefaultResponseErrorHandler
     */
    public <T> ResponseEntity<T> getForEntity(String process, URI uri, HttpEntity<?> requestEntity,
            Class<T> responseType) throws BadRequestException, ServiceUnavailableException {
        return exchange(HttpMethod.GET, process, uri, requestEntity, responseType);
    }

    /**
     * Helper POST method that throws an AbstractResponseStatusException which can be used to return response codes
     * directly
     *
     * @see RestTemplate
     * @see DefaultResponseErrorHandler
     */
    public <T> ResponseEntity<T> postForEntity(String process, URI uri, HttpEntity<?> requestEntity,
            Class<T> responseType) throws BadRequestException, ServiceUnavailableException {
        return exchange(HttpMethod.POST, process, uri, requestEntity, responseType);
    }

    /**
     * Helper (RestTemplate) exchange method that throws an AbstractResponseStatusException which can be used to return
     * response codes directly
     *
     * @see RestTemplate
     * @see DefaultResponseErrorHandler
     */
    public <T> ResponseEntity<T> exchange(HttpMethod method, String process, URI uri, HttpEntity<?> requestEntity,
            Class<T> responseType) throws BadRequestException, ServiceUnavailableException {
        if (LOG.isDebugEnabled()) {
            LOG.debug(String.format("Calling %s for %s, %s, %s and expecting %s.class", method, process, uri,
                    requestEntity, responseType.getSimpleName()));
        }

        try {
            return restTemplate.exchange(uri, method, requestEntity, responseType);
        } catch (HttpClientErrorException e) {
            throw new BadRequestException(process + " returned " + e.getRawStatusCode(), e);
        } catch (RestClientResponseException e) {
            throw new ServiceUnavailableException(process + " returned " + e.getRawStatusCode(), e);
        } catch (RuntimeException e) {
            throw new ServiceUnavailableException(process + " threw " + e, e);
        }
    }
}
