package ie.aib.msf.core.domain.exceptions;

public class MicroservicesFrameworkException extends Exception {

    private static final long serialVersionUID = 1L;

    public MicroservicesFrameworkException() {
        super();

    }

    public MicroservicesFrameworkException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public MicroservicesFrameworkException(String message, Throwable cause) {
        super(message, cause);

    }

    public MicroservicesFrameworkException(String message) {
        super(message);

    }

    public MicroservicesFrameworkException(Throwable cause) {
        super(cause);

    }


}
