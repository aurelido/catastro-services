package ie.aib.msf.core.helper;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.json.XML;

@SuppressWarnings("WeakerAccess")
public class ObjectMapperHelper {

    private ObjectMapper objectMapper;

    /**
     * Create a new instance of the ObjectMapperHelper
     */
    public ObjectMapperHelper() {

        this.objectMapper = new ObjectMapper();

        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public <T> T convertValue(Object fromValue, Class<T> toValueType) {
        return objectMapper.convertValue(fromValue, toValueType);
    }

    /**
     * Decode a message.
     *
     * @param message The message to decode
     * @return The message decoded to String format, in UTF-8 format
     */
    public String decodeMessage(Object message) {
        String decoded = message.toString();

        // workaround for ContentType not being set in incoming message

        if (message instanceof byte[]) {
            decoded = new String((byte[]) message, StandardCharsets.UTF_8);
        }

        return decoded;
    }

    /**
     * Convert the message to a String.
     *
     * @param message The message to convert
     * @return The converted message
     */
    public String toString(Object message) {
        try {
            return objectMapper.writeValueAsString(message);
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * Convert the message to a byte array.
     *
     * @param message The message to convert
     * @return The converted message, as a byte array
     */
    public byte[] toBytes(Object message) {

        try {
            return objectMapper.writeValueAsBytes(message);

        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * Pretty print the message.
     *
     * @param message The message to pretty print
     * @return The message, formatted in a pretty printed way.
     */
    public String prettyPrint(Object message) {

        try {

            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(message);

        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * Convert XML into a Json Node.
     *
     * @param xml The XML to convert
     * @return The JsonNode converted from XML
     * @throws IOException if there was a conversion problem
     */
    public JsonNode xmlToJsonNode(String xml) throws IOException {
        return xml == null ? null : objectMapper.readTree(xmlToJsonString(xml));
    }

    /**
     * Convert XML to a Json String.
     *
     * @param xml The XML to convert
     * @return The Json String converted from XML
     * @throws org.json.JSONException if there was a conversion problem
     */
    public String xmlToJsonString(String xml) {

        return xml == null ? null : XML.toJSONObject(xml).toString();
    }

    /**
     * Gets an attribute using a xpath style path. (eg. "body.request.field1").
     *
     * @param message The Json message to extract an attribute from
     * @param path The path location of the attribute
     * @return The Json Node containing the attribute
     */
    public JsonNode getXPathStyleNode(String message, String path) throws IOException {
        JsonNode root = objectMapper.readTree(message);
        return root.at(path);
    }

    /**
     * Deserialize an object from a JSON String
     *
     * @param json The Json String
     * @param type The class type to convert into
     * @return the de-serialized object of type T
     * @throws IllegalArgumentException if the json cannot be converted to a T (see cause for more information)
     */
    public <T> T fromJson(String json, Class<T> type) {
        try {
            return objectMapper.readValue(json, type);
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * Serialize a T object into a JSON String
     *
     * @param object type object to serialize
     * @return String
     * @throws IllegalStateException if the T cannot be converted to a json string (see cause for more information)
     */
    public <T> String toJson(T object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Create a copy of a T type object which is translated by serializing and
     * de-serializing to/from a json representation.
     *
     * @param commandObject to copy
     * @return copy of type
     * @throws IllegalStateException if the T cannot be copied
     */
    @SuppressWarnings("unchecked")
    public <T> T copy(T commandObject) {
        String json = toJson(commandObject);

        return (T) fromJson(json, commandObject.getClass());
    }
}
