package ie.aib.msf.core.helper;

import ie.aib.msf.core.domain.exceptions.http.BadRequestWithBindingResultException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.validation.Validator;

public class RestValidatorHelper {

    private static final Log LOG = LogFactory.getLog(RestValidatorHelper.class);

    private Validator validator;

    public RestValidatorHelper(Validator validator) {
        Assert.notNull(validator, "Validator must not be null");
        this.validator = validator;
    }

    public BindingResult validateAndThrowBadRequest(Object object) {
        return validateAndThrowBadRequest(object, object.getClass().getSimpleName());
    }

    /**
     * Validate an object and throw a {@link BadRequestWithBindingResultException} if there are errors.
     *
     * @param object The object to validate
     * @param objectName The object name
     * @return a Binding result, if the object was valid
     * @throws BadRequestWithBindingResultException, if the object was not valid
     */
    public BindingResult validateAndThrowBadRequest(Object object, String objectName) {
        BindingResult bindingResult = validate(object, objectName);

        if (LOG.isDebugEnabled()) {
            LOG.debug(String.format("Validator results for %s: %s", objectName, bindingResult));
        }

        if (bindingResult.hasErrors()) {
            throw new BadRequestWithBindingResultException("Invalid " + objectName, bindingResult);
        }

        return bindingResult;
    }

    public BindingResult validate(Object object) {
        return validate(object, object.getClass().getSimpleName());
    }

    /**
     * Create a {@link BindingResult} from the specified object.
     *
     * @param object The object to bind
     * @param objectName The object name
     * @return The binding result
     */
    public BindingResult validate(Object object, String objectName) {
        DataBinder dataBinder = new DataBinder(object, objectName);
        dataBinder.setValidator(validator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }
}
