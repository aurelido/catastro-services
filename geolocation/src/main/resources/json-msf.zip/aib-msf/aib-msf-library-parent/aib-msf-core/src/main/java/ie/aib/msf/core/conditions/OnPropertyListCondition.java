package ie.aib.msf.core.conditions;

import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.PropertyResolver;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

class OnPropertyListCondition extends SpringBootCondition {

    @Override
    public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
        MultiValueMap<String, Object> allAnnotationAttributes = metadata.getAllAnnotationAttributes(
                ConditionalOnPropertyList.class.getName());

        //each value is required and can only have one value
        String name = (String) allAnnotationAttributes.get("name").get(0);
        String expectedValue = (String) allAnnotationAttributes.get("havingValue").get(0);

        return determineOutcome(name, expectedValue, context.getEnvironment());
    }

    private ConditionOutcome determineOutcome(String name, String expectedValue, PropertyResolver resolver) {
        PropertyResolver relaxedPropertyResolver = new RelaxedPropertyResolver(resolver);
        String propertyValue = relaxedPropertyResolver.getProperty(name);

        String[] values = StringUtils.delimitedListToStringArray(propertyValue, ",", " ");

        for (String value : values) {
            if (value.equalsIgnoreCase(expectedValue)) {
                return ConditionOutcome.match();
            }
        }

        return ConditionOutcome.noMatch(name + " does not contain: " + expectedValue);
    }
}
