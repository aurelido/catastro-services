package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

// import org.eclipse.persistence.oxm.annotations.XmlPath; /* TODO - bjenkins-onewiew - removed */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "errorNode")
public class ErrorNode {

    private Integer errorCode;

    private String errorMsg;

    private String errorSev;

    // @XmlPath("errorCode/@actualHostCode") /* TODO - bjenkins-onewiew - removed */
    // private String actualHostCode; /* TODO - bjenkins-onewiew - removed */

    private String shortErrorMsg;

    private String errorSource;

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getErrorSev() {
        return errorSev;
    }

    public void setErrorSev(String errorSev) {
        this.errorSev = errorSev;
    }

    public String getShortErrorMsg() {
        return shortErrorMsg;
    }

    public void setShortErrorMsg(String shortErrorMsg) {
        this.shortErrorMsg = shortErrorMsg;
    }

    public String getErrorSource() {
        return errorSource;
    }

    public void setErrorSource(String errorSource) {
        this.errorSource = errorSource;
    }
}
