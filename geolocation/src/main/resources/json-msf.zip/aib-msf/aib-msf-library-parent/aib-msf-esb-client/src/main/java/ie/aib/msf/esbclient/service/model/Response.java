package ie.aib.msf.esbclient.service.model;

import ie.aib.msf.esbclient.service.model.cltviewinsertcustpersmessage.CltviewInsertCustPersMessageResponse;
import ie.aib.msf.esbclient.service.model.cltviewselectmessagereftext.CltviewSelectMessageRefTextResponse;
import ie.aib.msf.esbclient.service.model.cltviewservice007.CltviewService007Response;
import ie.aib.msf.esbclient.service.model.cltviewservice021.CltviewService021Response;
import ie.aib.msf.esbclient.service.model.cltviewservice093.CltviewService093Response;
import ie.aib.msf.esbclient.service.model.cltviewservice519.CltviewService519Response;
import ie.aib.msf.esbclient.service.model.cltviewservicecustinsertpersonalmsg.CltviewServiceCustomerInsertPersonalMsgResponse;
import ie.aib.msf.esbclient.service.model.cltviewservicecustomerrelmgmt.CltviewServiceCustomerRelMgmtResponse;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Response")
@XmlSeeAlso({
        CltviewService007Response.class, /* TODO - bjenkins-onewiew - new */
        CltviewService021Response.class,
        CltviewService093Response.class, /* TODO - bjenkins-onewiew - new */
        CltviewServiceCustomerRelMgmtResponse.class, /* TODO - bjenkins-onewiew - new */
        CltviewServiceCustomerInsertPersonalMsgResponse.class,
        CltviewSelectMessageRefTextResponse.class,
        CltviewInsertCustPersMessageResponse.class,
        CltviewService519Response.class
})

/**
 * Class for marshaling response objects.
 * For clientService - you have to add you class to the XML list.
 *
 */
public class Response {

    @XmlElementRef
    private ResponseBody body;

    public ResponseBody getBody() {
        return body;
    }

    public void setBody(ResponseBody body) {
        this.body = body;
    }
}
