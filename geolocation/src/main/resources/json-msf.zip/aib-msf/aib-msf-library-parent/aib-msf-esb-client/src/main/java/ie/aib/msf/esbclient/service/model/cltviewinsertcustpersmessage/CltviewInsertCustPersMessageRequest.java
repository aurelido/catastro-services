package ie.aib.msf.esbclient.service.model.cltviewinsertcustpersmessage;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by 38188 on 03/05/2017.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewInsertCustPersMessage")
public class CltviewInsertCustPersMessageRequest extends CustNumRequest {


    @XmlElement(name = "CUST_KEY")
    private String customerKey;

    @XmlElement(name = "PROCESS")
    private String process;

    @XmlElement(name = "STATUS")
    private String status;

    @XmlElement(name = "CHAN_ID")
    private String channelId;

    @XmlElement(name = "MSG_TEXT")
    private String messageText;

    @XmlElement(name = "STAFF_CD")
    private String staffCd;

    @XmlElement(name = "NSC")
    private String nsc;

    public String getCustomerKey() {
        return customerKey;
    }

    public void setCustomerKey(String customerKey) {
        this.customerKey = customerKey;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getStaffCd() {
        return staffCd;
    }

    public void setStaffCd(String staffCd) {
        this.staffCd = staffCd;
    }

    public String getNsc() {
        return nsc;
    }

    public void setNsc(String nsc) {
        this.nsc = nsc;
    }
}
