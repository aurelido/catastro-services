package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public abstract class CifResponseBody extends ResponseBody {

    @XmlElement(name = "CUST_NUM")
    private String cifKey;

    @XmlElement(name = "UpdateKey")
    private String updateKey;

    public String getCifKey() {
        return cifKey;
    }

    public void setCifKey(String cifKey) {
        this.cifKey = cifKey;
    }

    public String getUpdateKey() {
        return updateKey;
    }

    public void setUpdateKey(String updateKey) {
        this.updateKey = updateKey;
    }
}
