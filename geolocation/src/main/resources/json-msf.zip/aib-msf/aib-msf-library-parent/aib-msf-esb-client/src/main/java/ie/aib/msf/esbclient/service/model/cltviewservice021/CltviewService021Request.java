package ie.aib.msf.esbclient.service.model.cltviewservice021;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CltviewService021")
public class CltviewService021Request extends
        CustNumRequest { // TODO - bjenkins-onewiew - new - not using PersonalDemographicsRequest

}
