package ie.aib.msf.esbclient.configuration;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties("ie.aib.msf.esbclient.request")
public class EsbClientRequestProperties {

    @NotNull
    private String appId;
    @NotNull
    private String appName;
    @NotNull
    private String uri;
    @NotNull
    private String unqId;
    @NotNull
    private String usrId;
    @NotNull
    private String regionCode;
    @NotNull
    private String sourceNsc;
    @NotNull
    private String staffNumber;

    private String version;

    private RetryProperties retry = new RetryProperties();

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getUnqId() {
        return unqId;
    }

    public void setUnqId(String unqId) {
        this.unqId = unqId;
    }

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getSourceNsc() {
        return sourceNsc;
    }

    public void setSourceNsc(String sourceNsc) {
        this.sourceNsc = sourceNsc;
    }

    public String getStaffNumber() {
        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {
        this.staffNumber = staffNumber;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public RetryProperties getRetry() {
        return retry;
    }

    public void setRetry(RetryProperties retry) {
        this.retry = retry;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RetryProperties {

        private int maxCount = 1;
        private int multiplier;
        private long initialInterval;
        private long maxInterval;
        private Class<? extends Throwable> retryForException = Exception.class;


    }

}
