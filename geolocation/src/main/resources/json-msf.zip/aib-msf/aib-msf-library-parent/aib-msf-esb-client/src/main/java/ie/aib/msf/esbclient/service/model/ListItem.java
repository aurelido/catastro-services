package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlAttribute;

public class ListItem extends Fields implements ResponseBodyFieldCollection {

    @XmlAttribute(name = "updateIndex")
    private String updateIndex;

    public String getUpdateIndex() {
        return updateIndex;
    }

    public void setUpdateIndex(String updateIndex) {
        this.updateIndex = updateIndex;
    }

    @Override
    public Fields getFields() {
        return this;
    }

    @Override
    public String getUpdateKey() {
        return null;
    }
}
