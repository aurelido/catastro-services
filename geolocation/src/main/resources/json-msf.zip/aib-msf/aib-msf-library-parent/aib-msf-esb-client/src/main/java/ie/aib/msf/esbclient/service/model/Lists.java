package ie.aib.msf.esbclient.service.model;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Lists {

    @XmlElement(name = "List")
    private List<ListItems> listOfListItems; // i didn't design this nonsense

    public List<ListItems> getListOfListItems() {
        return listOfListItems;
    }

    public void setListOfListItems(List<ListItems> listOfListItems) {
        this.listOfListItems = listOfListItems;
    }
}
