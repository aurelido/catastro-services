package ie.aib.msf.esbclient.service;

import ie.aib.msf.core.domain.exceptions.http.BadRequestException;
import ie.aib.msf.core.domain.exceptions.http.ForbiddenException;
import ie.aib.msf.core.domain.exceptions.http.NotFoundException;
import ie.aib.msf.core.domain.exceptions.http.ServiceUnavailableException;
import ie.aib.msf.core.helper.RestTemplateHelper;
import ie.aib.msf.esbclient.configuration.EsbClientRequestProperties;
import ie.aib.msf.esbclient.retry.EsbClientRecoverer;
import ie.aib.msf.esbclient.service.model.CifListsResponseBody;
import ie.aib.msf.esbclient.service.model.CustNumRequest;
import ie.aib.msf.esbclient.service.model.ListItem;
import ie.aib.msf.esbclient.service.model.ListItems;
import ie.aib.msf.esbclient.service.model.Lists;
import ie.aib.msf.esbclient.service.model.Request;
import ie.aib.msf.esbclient.service.model.RequestBody;
import ie.aib.msf.esbclient.service.model.Response;
import ie.aib.msf.esbclient.service.model.ResponseBody;
import ie.aib.msf.esbclient.service.model.ResponseBodyFieldCollection;
import ie.aib.msf.esbclient.service.model.ServiceDataMapper;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;

@SuppressWarnings({"WeakerAccess", "SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiredMembersInspection",
        "unused"})
@Data
public class EsbClient {

    private static final Log LOG = LogFactory.getLog(EsbClient.class);

    @Autowired
    private RestTemplateHelper restTemplateHelper;

    @Autowired
    private EsbClientRequestProperties esbClientRequestProperties;

    private URI uri;
    private HttpHeaders headers;
    private ServiceDataMapper serviceDataMapper = new ServiceDataMapper();

    @Autowired
    private RetryTemplate retryTemplate;

    @Autowired(required = false)
    private EsbClientRecoverer recoverer;

    @PostConstruct
    void init() throws URISyntaxException {
        uri = new URI(esbClientRequestProperties.getUri());
        HttpHeaders tempHeaders = new HttpHeaders();
        tempHeaders.setContentType(MediaType.APPLICATION_XML);
        headers = HttpHeaders.readOnlyHttpHeaders(tempHeaders);
    }

    /**
     * Create a request using the default request properties and a requestBody
     *
     * @param requestBody The request body
     * @return A request object
     */
    public Request createRequest(RequestBody requestBody) {
        return createRequest(esbClientRequestProperties, requestBody);
    }

    /**
     * Create a request using specific request properties and a requestBody
     *
     * @param esbRequestProperties The request properties
     * @param requestBody The request body
     * @return A request object
     */
    public Request createRequest(EsbClientRequestProperties esbRequestProperties, RequestBody requestBody) {
        final Request request = new Request();
        Request.ID id = new Request.ID();
        id.setAppID(esbRequestProperties.getAppId());
        id.setAppName(esbRequestProperties.getAppName());
        id.setUnqID(esbRequestProperties.getUnqId());
        id.setUsrID(esbRequestProperties.getUsrId());
        if (esbRequestProperties.getVersion() != null) {
            id.setVersion(esbRequestProperties.getVersion());
        }

        request.setId(id);
        request.setRegionCode(esbRequestProperties.getRegionCode());
        request.setSourceNSC(esbRequestProperties.getSourceNsc());
        request.setStaffNumber(esbRequestProperties.getStaffNumber());

        XmlRootElement xmlRootElement = requestBody.getClass().getAnnotation(XmlRootElement.class);
        if (xmlRootElement == null) {
            throw new IllegalArgumentException("XmlRootElement annotation is required");
        }
        request.setTransaction(xmlRootElement.name());
        request.setBody(requestBody);

        return request;
    }

    /**
     * Create a request - convenience given request body type, uniqueId and region
     *
     * @param requestBodyType The RequestBody type
     * @param uniqueId The value of referenceId
     * @param region The region, ie "ROI"
     * @return A request object
     */
    public Request createRequest(Class<? extends RequestBody> requestBodyType, String uniqueId, String region) {
        RequestBody requestBody;
        try {
            requestBody = requestBodyType.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException("Cannot instantiate RequestBody", e);
        }
        Request r = createRequest(requestBody);
        r.setRegionCode(region);
        r.getId().setUnqID(uniqueId);

        return r;
    }

    /**
     * Create customer number request - convenience given customer number request type and customer number (identifier)
     *
     * @param custNumRequestType The CustNumRequest type
     * @param customer The customer number (identifier)
     * @return A customer number request object
     */
    public Request createCustNumRequest(Class<? extends CustNumRequest> custNumRequestType, String customer) {
        final CustNumRequest custNumRequest;
        try {
            custNumRequest = custNumRequestType.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException("Cannot instantiate CustNumRequest", e);
        }
        custNumRequest.setCustNum(customer);

        return createRequest(esbClientRequestProperties, custNumRequest);
    }

    /**
     * Send a request and extract the response body.
     *
     * @param request The request to send
     * @return The response body
     * @throws BadRequestException if the request is invalid
     * @throws ForbiddenException if permission to access the resource is denied
     * @throws ServiceUnavailableException if the service can't be reached
     */
    public ResponseBody getResponseBody(final Request request) {

        RecoveryCallback<ResponseBody> recoveryCallback = null;

        if (recoverer != null) {
            recoveryCallback = (RetryContext c) -> {
                recoverer.recover(request);
                return null;
            };
        }

        return retryTemplate.execute(retryCtx -> getResponseBodyInternal(request), recoveryCallback);
    }

    private ResponseBody getResponseBodyInternal(final Request request) {
        HttpEntity<Request> entity = new HttpEntity<>(request, headers);
        ResponseEntity<Response> responseEntity = restTemplateHelper
                .postForEntity(this.getClass().getSimpleName(), uri, entity, Response.class);
        ResponseBody responseBody = responseEntity.getBody().getBody();

        if (responseBody == null || responseBody.getErrorNode() == null) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Received an empty response");
            }
        } else {
            Integer errorCode = responseBody.getErrorNode().getErrorCode();
            if (errorCode != null && errorCode != 0) {
                String errorMessage = String
                        .format("%s received error code %s", this.getClass().getSimpleName(), errorCode);

                if (LOG.isDebugEnabled()) {
                    LOG.debug(String.format("%s %n  Message: %s %n  Severity: %s %n  Source: %s",
                            errorMessage,
                            responseBody.getErrorNode().getErrorMsg(),
                            responseBody.getErrorNode().getErrorSev(),
                            responseBody.getErrorNode().getErrorSource()));
                }


                /*
                *
                * Not Authorised (missing ACL), for example:
                *
                *   errorCode   502
                *   errorSource ESB
                *   errorMsg    PLR_COM_UNEXPECTED_ERROR   java.lang.Exception: net.sf.saxon.trans.DynamicError: CltviewService093 Service Not Authorised for rhdcpsvcvt3.mid.aib.pri
                *   errorSev    PolarLake Exception net.sf.saxon.trans.DynamicErrorCltviewService093 Service Not Authorised for rhdcpsvcvt3.mid.aib.pri
                *
                */

                String errorSev = responseBody.getErrorNode().getErrorSev();
                if ((errorCode == 502) && (errorSev != null) && (errorSev.contains("Not Authorised"))) {
                    throw new ForbiddenException(errorSev);
                }
            }
        }

        return responseBody;
    }

    /**
     * Send a request and extract from response body from the specified fields
     *
     * @param request The request to send
     * @param responseType The response type
     * @return An object of the specified response type
     * @throws BadRequestException if the request is invalid
     * @throws ForbiddenException if permission to access the resource is denied
     * @throws NotFoundException if the resource is not found
     * @throws ServiceUnavailableException if the service is unreachable
     */
    public <T> T getResponseFromFields(Request request, Class<T> responseType) {
        T response = null;
        ResponseBody esbResponseBody = getResponseBody(request);

        if (esbResponseBody instanceof ResponseBodyFieldCollection) {
            ResponseBodyFieldCollection responseBodyFieldCollection = (ResponseBodyFieldCollection) esbResponseBody;

            if (responseBodyFieldCollection.getFields() == null) {
                String message;
                if (request.getBody() instanceof CustNumRequest) {
                    CustNumRequest custNumRequest = (CustNumRequest) request.getBody();
                    message = String.format("Customer (%s) not found", custNumRequest.getCustNum());
                } else {
                    message = "Customer not found";
                }
                throw new NotFoundException(message);
            }

            try {
                response = serviceDataMapper.map(responseBodyFieldCollection, responseType);
            } catch (ParseException e) {
                LOG.warn("Could not map response to " + responseType, e);
            }
        }
        return response;
    }

    /**
     * Send a request and extract the response from a list
     *
     * @param request The request to send
     * @param responseType The response type
     * @return An object of the response type
     * @throws BadRequestException if the request is invalid
     * @throws ForbiddenException if permission to access the resource is denied
     * @throws NotFoundException if the resource is not found
     * @throws ServiceUnavailableException if the service is unreachable
     */
    public <T> List<T> getResponseFromLists(Request request, Class<T> responseType) {
        List<T> response = new ArrayList<>();
        ResponseBody esbResponseBody = getResponseBody(request);

        if (esbResponseBody instanceof CifListsResponseBody) {
            CifListsResponseBody cifListsResponseBody = (CifListsResponseBody) esbResponseBody;
            Lists lists = cifListsResponseBody.getLists();

            if (lists == null || lists.getListOfListItems() == null) {
                throw new NotFoundException(String.format("Customer (%s) not found", cifListsResponseBody.getCifKey()));
            }

            for (ListItems listItems : lists.getListOfListItems()) {
                for (ListItem listItem : listItems.getListItems()) {
                    try {
                        response.add(serviceDataMapper.map(listItem, responseType));
                    } catch (ParseException e) {
                        LOG.warn("Could not map response list item to " + responseType, e);
                    }
                }
            }
        }
        return response;
    }
}
