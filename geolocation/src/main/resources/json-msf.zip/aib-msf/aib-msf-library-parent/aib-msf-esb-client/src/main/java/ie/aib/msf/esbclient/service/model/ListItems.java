package ie.aib.msf.esbclient.service.model;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ListItems {

    @XmlAttribute(name = "name")
    private String name;

    //Ignore Sonar warning about field name matching class name. This is due to the bus. Can't do anything about it
    @SuppressWarnings("squid:S1700")
    @XmlElement(name = "ListItem")
    private List<ListItem> listItems;

    public List<ListItem> getListItems() {
        return listItems;
    }

    public void setListItems(List<ListItem> listItems) {
        this.listItems = listItems;
    }
}
