package ie.aib.msf.esbclient.service.model;

/**
 * Interface for mapping fields and values from response by xml field name and annotated XML field name in bean.
 * If you want to use aib.oneview.service.common.ServiceDataMapper the response from external system (BUS,DSL)
 * must implement this interface.
 */
public interface ResponseBodyFieldCollection {

    /**
     * Fields from response object of service.
     *
     * @return Fields
     */
    Fields getFields();

    /**
     * Is mandatory for any update.
     *
     * @return update key
     */
    String getUpdateKey();
}
