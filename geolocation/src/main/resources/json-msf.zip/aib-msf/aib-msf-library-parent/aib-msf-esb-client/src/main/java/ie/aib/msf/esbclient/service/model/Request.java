package ie.aib.msf.esbclient.service.model;

import ie.aib.msf.esbclient.service.model.cltviewinsertcustpersmessage.CltviewInsertCustPersMessageRequest;
import ie.aib.msf.esbclient.service.model.cltviewselectmessagereftext.CltviewSelectMessageRefTextRequest;
import ie.aib.msf.esbclient.service.model.cltviewservice007.CltviewService007Request;
import ie.aib.msf.esbclient.service.model.cltviewservice021.CltviewService021Request;
import ie.aib.msf.esbclient.service.model.cltviewservice093.CltviewService093Request;
import ie.aib.msf.esbclient.service.model.cltviewservice519.CltviewService519Request;
import ie.aib.msf.esbclient.service.model.cltviewservicecustomerrelmgmt.CltviewServiceCustomerRelMgmtRequest;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Request")
@XmlSeeAlso({
        CltviewService007Request.class, /* TODO - bjenkins-onewiew - new */
        CltviewService021Request.class, /* TODO - bjenkins-onewiew - new - not using PersonalDemographicsRequest */
        CltviewService093Request.class, /* TODO - bjenkins-onewiew - new */
        CltviewServiceCustomerRelMgmtRequest.class, /* TODO - bjenkins-onewiew - new */
        CltviewInsertCustPersMessageRequest.class,
        CltviewSelectMessageRefTextRequest.class,
        CltviewService519Request.class
})
public class Request {

    @XmlElement(name = "Log")
    private String log = "N";

    @XmlElement(name = "ID")
    protected Request.ID id;

    @XmlElement(name = "regionCode")
    private String regionCode;

    @XmlElement(name = "sourceNSC")
    private String sourceNSC;

    @XmlElement(name = "staffNumber")
    private String staffNumber;

    @XmlElement(name = "deviceId")
    private String deviceId;

    @XmlElement(name = "Transaction")
    private String transaction;

    @XmlElement(name = "TransactionVersion")
    private String transactionVersion = "1";

    @XmlElement(name = "MHChannel")
    private String mhChannel;

    @XmlElement(name = "MHApplication")
    private String mhApplication;

    @XmlElement(name = "MHProcess")
    private String mhProcess;

    @XmlElementRef
    private RequestBody body;

    public String getLog() {

        return log;
    }

    public void setLog(String log) {

        this.log = log;
    }

    public Request.ID getId() {

        return id;
    }

    public void setId(Request.ID id) {

        this.id = id;
    }

    public String getRegionCode() {

        return regionCode;
    }

    public void setRegionCode(String regionCode) {

        this.regionCode = regionCode;
    }

    public String getSourceNSC() {

        return sourceNSC;
    }

    public void setSourceNSC(String sourceNSC) {

        this.sourceNSC = sourceNSC;
    }

    public String getStaffNumber() {

        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {

        this.staffNumber = staffNumber;
    }

    public String getDeviceId() {

        return deviceId;
    }

    public void setDeviceId(String deviceId) {

        this.deviceId = deviceId;
    }

    public String getTransaction() {

        return transaction;
    }

    public void setTransaction(String transaction) {

        this.transaction = transaction;
    }

    public String getTransactionVersion() {

        return transactionVersion;
    }

    public void setTransactionVersion(String transactionVersion) {

        this.transactionVersion = transactionVersion;
    }

    public String getMhChannel() {

        return mhChannel;
    }

    public void setMhChannel(String mhChannel) {

        this.mhChannel = mhChannel;
    }

    public String getMhApplication() {

        return mhApplication;
    }

    public void setMhApplication(String mhApplication) {

        this.mhApplication = mhApplication;
    }

    public String getMhProcess() {

        return mhProcess;
    }

    public void setMhProcess(String mhProcess) {

        this.mhProcess = mhProcess;
    }

    public RequestBody getBody() {

        return body;
    }

    public void setBody(RequestBody body) {

        this.body = body;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ID {

        @XmlElement(name = "version")
        protected String version = "1.0";

        @XmlElement(name = "AppID")
        protected String appID;

        @XmlElement(name = "AppName")
        protected String appName;

        @XmlElement(name = "UsrID")
        protected String usrID;

        @XmlElement(name = "UnqID")
        protected String unqID = "5645645";

        public String getVersion() {

            return version;
        }

        public void setVersion(String version) {

            this.version = version;
        }

        public String getAppID() {

            return appID;
        }

        public void setAppID(String appID) {

            this.appID = appID;
        }

        public String getAppName() {

            return appName;
        }

        public void setAppName(String appName) {

            this.appName = appName;
        }

        public String getUsrID() {

            return usrID;
        }

        public void setUsrID(String usrID) {

            this.usrID = usrID;
        }

        public String getUnqID() {

            return unqID;
        }

        public void setUnqID(String unqID) {

            this.unqID = unqID;
        }
    }
}
