package ie.aib.msf.esbclient.service.model.cltviewservice007;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CltviewService007")
public class CltviewService007Request extends CustNumRequest {

}
