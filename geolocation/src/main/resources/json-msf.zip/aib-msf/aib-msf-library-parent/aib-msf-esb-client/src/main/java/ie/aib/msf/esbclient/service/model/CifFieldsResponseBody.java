package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlElement;

public class CifFieldsResponseBody extends CifResponseBody implements ResponseBodyFieldCollection {

    @XmlElement(name = "Fields")
    private Fields fields;

    @Override
    public Fields getFields() {
        return fields;
    }

    public void setFields(Fields fields) {
        this.fields = fields;
    }
}
