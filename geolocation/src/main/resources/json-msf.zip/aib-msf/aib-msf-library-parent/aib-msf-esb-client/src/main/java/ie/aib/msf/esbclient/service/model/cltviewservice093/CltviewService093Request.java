package ie.aib.msf.esbclient.service.model.cltviewservice093;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CltviewService093")
public class CltviewService093Request extends CustNumRequest { // TODO - bjenkins-onewiew - new

}
