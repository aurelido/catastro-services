package ie.aib.msf.esbclient.service.model.cltviewservice007;

import ie.aib.msf.esbclient.service.model.CifListsResponseBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Response object for getting customer details.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewService007")
public class CltviewService007Response extends CifListsResponseBody {

}
