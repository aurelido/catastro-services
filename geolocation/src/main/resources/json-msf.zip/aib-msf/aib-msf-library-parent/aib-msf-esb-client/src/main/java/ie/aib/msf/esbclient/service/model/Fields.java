package ie.aib.msf.esbclient.service.model;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Fields {

    @XmlElement(name = "Field")
    private List<Field> listOfFields;

    public List<Field> getListOfFields() {
        return listOfFields;
    }

    public void setListOfFields(List<Field> listOfFields) {
        this.listOfFields = listOfFields;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    public static class Field {

        @XmlElement(name = "Value")
        String value;
        @XmlElement(name = "Change")
        String change;
        @XmlAttribute(name = "name")
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getChange() {
            return change;
        }

        public void setChange(String change) {
            this.change = change;
        }
    }
}
