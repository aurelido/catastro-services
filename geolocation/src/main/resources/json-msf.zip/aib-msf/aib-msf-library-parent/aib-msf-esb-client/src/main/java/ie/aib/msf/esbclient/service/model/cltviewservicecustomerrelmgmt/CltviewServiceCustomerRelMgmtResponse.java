package ie.aib.msf.esbclient.service.model.cltviewservicecustomerrelmgmt;

import ie.aib.msf.esbclient.service.model.Fields;
import ie.aib.msf.esbclient.service.model.ResponseBody;
import ie.aib.msf.esbclient.service.model.ResponseBodyFieldCollection;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewCustomerRelMgmt")
public class CltviewServiceCustomerRelMgmtResponse extends ResponseBody implements
        ResponseBodyFieldCollection { // TODO - bjenkins-onewiew - new

    @XmlElement(name = "Fields")
    private Object rawFields;

    @Override
    public Fields getFields() {
        Fields fields = null;
        if ((rawFields != null) && (rawFields instanceof Element)) {
            Element element = (Element) rawFields;
            List<Fields.Field> fieldList = new ArrayList<>();
            Node child = element.getFirstChild();
            while (child != null) {
                Fields.Field field = new Fields.Field();
                field.setName(child.getNodeName());
                String value = child.getNodeValue();
                if (value == null && child.getFirstChild() instanceof Text) {
                    value = child.getFirstChild().getTextContent();
                }
                field.setValue(value);
                fieldList.add(field);
                child = child.getNextSibling();
            }
            if (!fieldList.isEmpty()) {
                fields = new Fields();
                fields.setListOfFields(fieldList);
            }
        }
        return fields;
    }

    @Override
    public String getUpdateKey() {
        return null;
    }
}
