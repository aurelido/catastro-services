package ie.aib.msf.esbclient.service.model.cltviewservice021;

import ie.aib.msf.esbclient.service.model.CifFieldsResponseBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Response object for getting customer details.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewService021")
public class CltviewService021Response extends CifFieldsResponseBody {

}
