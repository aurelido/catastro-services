package ie.aib.msf.esbclient.service.model.cltviewselectmessagereftext;

import ie.aib.msf.esbclient.service.model.RequestBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by 38188 on 03/05/2017.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewSelectMessageRefText")
public class CltviewSelectMessageRefTextRequest extends RequestBody {


    @XmlElement(name = "PROCESS")
    private String process;

    @XmlElement(name = "STATUS")
    private String status;

    @XmlElement(name = "CHAN_ID")
    private String channel;

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
