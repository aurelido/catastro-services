package ie.aib.msf.esbclient.service.model; // TODO - bjenkins-onewiew - this should be moved from the common package

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * Mapper for service response and set vaules of beans (POJO or DTO). Service should be use for
 * mapping bean and XML Fields for retrieve/update information from/to BUS/DSL. The elements of
 * service: aib.oneview.service.model.servicedatamapper.Fields ( unfortunately in module
 * servicemodels) aib.oneview.service.model.servicedatamapper.ResponseBodyFieldCollection (interface
 * for implmentation by response - request)
 * aib.oneview.service.model.servicedatamapper.ServiceResponseWrapper
 * <p/>
 * Created by Piotr Kalwasinski (37390) on 27/07/2016.
 */

@Service
public class ServiceDataMapper {

    private static final Log LOG = LogFactory.getLog(ServiceDataMapper.class);

    /**
     * Maps values from response body with values bean fields.
     *
     * @param responseBody - response body (XML) from DSL/BUS
     * @param clazz - class of bean to mapping
     * @param <T> - type of clazz
     * @return - mapped and filled object of clazz
     * @throws ParseException - exception if mapping fails.
     */
    public <T> T map(ResponseBodyFieldCollection responseBody, Class<T> clazz)
            throws ParseException {

        T object;

        try {
            final Constructor<T> cons = clazz.getConstructor();
            object = cons.newInstance();
        } catch (NoSuchMethodException | InvocationTargetException | InstantiationException
                | IllegalAccessException ex) {
            LOG.info(" Mapper problem:", ex);
            throw new ParseException("Can't create  target object.", 0);
        }

        final HashMap<String, Fields.Field> xmlFieldsMap = convertToHashMap(responseBody.getFields());
        final Field[] fields = object.getClass().getDeclaredFields();
        for (final Field objectField : fields) {
            final Annotation[] annotations = objectField.getDeclaredAnnotations();
            for (final Annotation beanAnnotation : annotations) {
                if (beanAnnotation instanceof XmlServiceField) {
                    final XmlServiceField beanFieldAnnotation = (XmlServiceField) beanAnnotation;
                    final Fields.Field cltField = xmlFieldsMap.get(beanFieldAnnotation.name());
                    if (cltField != null) {
                        final PropertyAccessor myAccessor = PropertyAccessorFactory.forDirectFieldAccess(object);
                        myAccessor.setPropertyValue(objectField.getName(), getValue(objectField, cltField));
                    }
                }
            }
        }
        return object;
    }

    private HashMap<String, Fields.Field> convertToHashMap(Fields listOfFields) {
        final HashMap<String, Fields.Field> fieldHashMap = new HashMap<>();
        if ((listOfFields == null) || (listOfFields.getListOfFields() == null)
                || (listOfFields.getListOfFields().isEmpty())) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Received null or empty listOfFields");
            }
        } else {
            for (final Fields.Field field : listOfFields.getListOfFields()) {
                fieldHashMap.put(field.getName(), field);
            }
        }

        return fieldHashMap;
    }

    private Object getValue(Field field, Fields.Field cltField) throws ParseException {

        switch (field.getType().getCanonicalName()) {

            case "java.lang.String":
                return cltField.getValue() == null ? null : cltField.getValue().trim();

            case "java.lang.Integer":
                return StringUtils.isEmpty(cltField.getValue()) ? null : Integer
                        .parseInt(cltField.getValue());

            case "java.math.BigInteger":
                return StringUtils.isEmpty(cltField.getValue()) ? null : new BigInteger(
                        cltField.getValue());

            case "java.util.Date":
                return StringUtils.isEmpty(cltField.getValue()) ? null : new SimpleDateFormat(
                        "dd.MM.yyyy").parse(cltField.getValue());
            /*
            case "org.joda.time.DateTime":
                return StringUtils.isEmpty(cltField.getValue()) ? null : DateTimeFormat
                        .forPattern("dd.MM.yyyy").parseLocalDate(cltField.getValue());
            */
            case "java.lang.Boolean":
                return "TRUE".equalsIgnoreCase(cltField.getValue());
            default:
                throw new ParseException(""
                        + "Service data mapper exception. The bean field type: "
                        + field.getType().getCanonicalName() + " is unsupported.", 0);
        }
    }
}
