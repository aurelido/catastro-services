package ie.aib.msf.esbclient.retry;

import ie.aib.msf.esbclient.service.model.Request;

/**
 * Created by 38188 on 24/04/2017.
 */
public interface EsbClientRecoverer {

    void recover(Request request);
}
