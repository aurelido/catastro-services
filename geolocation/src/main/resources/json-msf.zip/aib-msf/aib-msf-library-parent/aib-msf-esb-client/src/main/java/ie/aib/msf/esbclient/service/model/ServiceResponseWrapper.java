package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Data of response from service CltviewService021. TODO - bjenkins-onewiew - this does not only apply to
 * CltviewService021
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceResponseWrapper extends ResponseBody implements ResponseBodyFieldCollection {

    @XmlElement(name = "CUST_NUM")
    private String cifKey;

    @XmlElement(name = "UpdateKey")
    private String updateKey;

    @XmlElement(name = "Fields")
    private Fields fields;

    public String getCifKey() {
        return cifKey;
    }

    public void setCifKey(String cifKey) {
        this.cifKey = cifKey;
    }

    @Override
    public String getUpdateKey() {
        return updateKey;
    }

    public void setUpdateKey(String updateKey) {
        this.updateKey = updateKey;
    }

    @Override
    public Fields getFields() {
        return fields;
    }

    public void setFields(Fields fields) {
        this.fields = fields;
    }
}
