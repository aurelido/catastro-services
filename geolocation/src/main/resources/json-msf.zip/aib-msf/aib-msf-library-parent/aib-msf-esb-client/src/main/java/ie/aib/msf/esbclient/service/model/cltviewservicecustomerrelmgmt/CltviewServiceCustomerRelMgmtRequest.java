package ie.aib.msf.esbclient.service.model.cltviewservicecustomerrelmgmt;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CltviewCustomerRelMgmt")
public class CltviewServiceCustomerRelMgmtRequest extends CustNumRequest { // TODO - bjenkins-onewiew - new

}
