package ie.aib.msf.esbclient.service.model;

public abstract class ResponseBody {

    private ErrorNode errorNode;

    public ErrorNode getErrorNode() {
        return errorNode;
    }

    public void setErrorNode(ErrorNode errorNode) {
        this.errorNode = errorNode;
    }
}
