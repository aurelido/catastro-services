package ie.aib.msf.esbclient.service.model;

import javax.xml.bind.annotation.XmlElement;

public class CifListsResponseBody extends CifResponseBody {

    @XmlElement(name = "Fields")
    private Lists lists;

    public Lists getLists() {
        return lists;
    }

    public void setLists(Lists lists) {
        this.lists = lists;
    }
}
