package ie.aib.msf.esbclient.service.model.cltviewservicecustinsertpersonalmsg;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewCustInsertPersonalMsg")
public class CltviewServiceCustomerInsertPersonalMsgRequest extends CustNumRequest {

    @XmlElement(name = "CUST_SEG_CDE")
    private String customorSegmentCode;

    @XmlElement(name = "MSG_GRP_ID")
    private String messageGroupId;

    @XmlElement(name = "CHAN_ID")
    private String channelId;

    @XmlElement(name = "APPL")
    private String application;

    @XmlElement(name = "PROCESS")
    private String process;

    @XmlElement(name = "COA_RESULT")
    private String coaResult;

    public String getCustomorSegmentCode() {
        return customorSegmentCode;
    }

    public void setCustomorSegmentCode(String customorSegmentCode) {
        this.customorSegmentCode = customorSegmentCode;
    }

    public String getMessageGroupId() {
        return messageGroupId;
    }

    public void setMessageGroupId(String messageGroupId) {
        this.messageGroupId = messageGroupId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public String getCoaResult() {
        return coaResult;
    }

    public void setCoaResult(String coaResult) {
        this.coaResult = coaResult;
    }
}
