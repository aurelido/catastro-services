package ie.aib.msf.esbclient.service.model.cltviewservicecustinsertpersonalmsg;

import ie.aib.msf.esbclient.service.model.CifFieldsResponseBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewCustInsertPersonalMsg")
public class CltviewServiceCustomerInsertPersonalMsgResponse extends
        CifFieldsResponseBody { // TODO - bjenkins-onewiew - new

}
