package ie.aib.msf.esbclient.service.model.cltviewservice093;

import ie.aib.msf.esbclient.service.model.CifFieldsResponseBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewService093")
public class CltviewService093Response extends CifFieldsResponseBody { // TODO - bjenkins-onewiew - new

}
