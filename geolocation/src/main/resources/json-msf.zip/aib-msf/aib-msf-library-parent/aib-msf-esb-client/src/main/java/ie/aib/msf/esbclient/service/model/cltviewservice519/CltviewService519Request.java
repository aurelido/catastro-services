package ie.aib.msf.esbclient.service.model.cltviewservice519;

import ie.aib.msf.esbclient.service.model.CustNumRequest;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CltviewService519")
public class CltviewService519Request extends CustNumRequest {

    @XmlElement(name = "servType500")
    private String servType500;

    @XmlElement(name = "enqType500")
    private String enqType500;

    @XmlElement(name = "keyArea")
    private String keyArea;

    @XmlElement(name = "totalNumber500")
    private String totalNumber500;

    public String getServType500() {
        return servType500;
    }

    public void setServType500(String servType500) {
        this.servType500 = servType500;
    }

    public String getEnqType500() {
        return enqType500;
    }

    public void setEnqType500(String enqType500) {
        this.enqType500 = enqType500;
    }

    public String getKeyArea() {
        return keyArea;
    }

    public void setKeyArea(String keyArea) {
        this.keyArea = keyArea;
    }

    public String getTotalNumber500() {
        return totalNumber500;
    }

    public void setTotalNumber500(String totalNumber500) {
        this.totalNumber500 = totalNumber500;
    }

}
