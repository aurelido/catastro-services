package ie.aib.msf.esbclient.configuration;

import static java.util.Collections.singletonMap;

import java.util.Map;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

/**
 * Created by 38188 on 18/04/2017.
 */

@Configuration
public class EsbClientRetryAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(RetryTemplate.class)
    RetryTemplate retryTemplate(EsbClientRequestProperties properties) {

        EsbClientRequestProperties.RetryProperties retryProperties = properties.getRetry();

        Map<Class<? extends Throwable>, Boolean> retryableExceptions = singletonMap(
                retryProperties.getRetryForException(), true);

        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setMultiplier(retryProperties.getMultiplier());
        backOffPolicy.setInitialInterval(retryProperties.getInitialInterval());
        backOffPolicy.setMaxInterval(retryProperties.getMaxInterval());

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(retryProperties.getMaxCount(), retryableExceptions);
        RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(retryPolicy);
        template.setBackOffPolicy(backOffPolicy);

        return template;
    }

}
