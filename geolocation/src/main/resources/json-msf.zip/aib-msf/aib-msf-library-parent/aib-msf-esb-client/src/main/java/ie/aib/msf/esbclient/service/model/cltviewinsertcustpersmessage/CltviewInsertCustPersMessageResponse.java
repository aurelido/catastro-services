package ie.aib.msf.esbclient.service.model.cltviewinsertcustpersmessage;

import ie.aib.msf.esbclient.service.model.ResponseBody;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by 38188 on 03/05/2017.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewInsertCustPersMessage")
public class CltviewInsertCustPersMessageResponse extends ResponseBody {

}



