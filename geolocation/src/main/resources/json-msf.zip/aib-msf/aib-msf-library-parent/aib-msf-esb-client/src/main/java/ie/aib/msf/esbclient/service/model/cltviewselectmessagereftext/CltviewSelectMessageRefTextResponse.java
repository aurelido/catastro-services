package ie.aib.msf.esbclient.service.model.cltviewselectmessagereftext;

import ie.aib.msf.esbclient.service.model.Fields;
import ie.aib.msf.esbclient.service.model.ResponseBody;
import ie.aib.msf.esbclient.service.model.ResponseBodyFieldCollection;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by 38188 on 03/05/2017.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CltviewSelectMessageRefText")
public class CltviewSelectMessageRefTextResponse extends ResponseBody implements ResponseBodyFieldCollection {

    @XmlElement(name = "Fields")
    private Fields fields;

    @Override
    public Fields getFields() {
        return fields;
    }

    public void setFields(Fields fields) {
        this.fields = fields;
    }

    @Override
    public String getUpdateKey() {
        return null;
    }
}
