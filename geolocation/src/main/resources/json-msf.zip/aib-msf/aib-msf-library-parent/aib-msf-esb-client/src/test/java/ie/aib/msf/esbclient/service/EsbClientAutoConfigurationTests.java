package ie.aib.msf.esbclient.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ie.aib.msf.core.domain.exceptions.http.ServiceUnavailableException;
import ie.aib.msf.core.helper.RestTemplateHelper;
import ie.aib.msf.esbclient.configuration.EsbClientAutoConfiguration;
import ie.aib.msf.esbclient.configuration.EsbClientRequestProperties;
import ie.aib.msf.esbclient.configuration.EsbClientRetryAutoConfiguration;
import ie.aib.msf.esbclient.retry.EsbClientRecoverer;
import ie.aib.msf.esbclient.service.model.Request;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.util.EnvironmentTestUtils;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 38188 on 19/04/2017.
 */
public class EsbClientAutoConfigurationTests {

    private final Class<?>[] ESB_CLIENT_CTX = new Class[] {
            EsbClientAutoConfiguration.class,
            EsbClientRetryAutoConfiguration.class,
            RestTemplateHelperCtx.class};
    private final Class<?>[] BUBBLE_UP_EX_CTX = ESB_CLIENT_CTX;
    private final Class<?> EX_HANDLED_CTX = RecovererCtx.class;
    private AnnotationConfigApplicationContext context;

    @Before
    public void setUp() {

        this.context = new AnnotationConfigApplicationContext();
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.appId:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.appName:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.unqId:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.usrId:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.regionCode:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.sourceNsc:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.staffNumber:foo");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.uri:foo");


    }

    @Test(expected = ServiceUnavailableException.class)
    public void testThatRetryKicksOffOnlyForExceptionConfigured() {

        //given

        EnvironmentTestUtils.addEnvironment(this.context,
                "ie.aib.msf.esbclient.request.retry.retryForException:java.lang.RuntimeException");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:3");
        this.context.register(BUBBLE_UP_EX_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("should trigger retry!"));
        EsbClient esbClient = context.getBean(EsbClient.class);
        EsbClientRequestProperties properties = context.getBean(EsbClientRequestProperties.class);
        EsbClientRequestProperties.RetryProperties retryProperties = properties.getRetry();
        Class<? extends Throwable> retryForException = retryProperties.getRetryForException();

        Request request = new Request();

        try {

            //when
            esbClient.getResponseBody(request);

        } catch (Exception e) {

            //then
            assertThat(e).isNotNull();
            verify(restTemplateHelper, times(3)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());
            assertThat(retryForException.isInstance(e)).isTrue();
            throw e;
        }


    }

    @Test(expected = ServiceUnavailableException.class)
    public void testThatRetryWontKickOffWhenExceptionNotInClassHierarchy() {

        //given

        EnvironmentTestUtils.addEnvironment(this.context,
                "ie.aib.msf.esbclient.request.retry.retryForException:ie.aib.msf.core.domain.exceptions.http.BadRequestException");
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:3");

        this.context.register(BUBBLE_UP_EX_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);
        EsbClientRequestProperties properties = context.getBean(EsbClientRequestProperties.class);
        EsbClientRequestProperties.RetryProperties retryProperties = properties.getRetry();
        Class<? extends Throwable> retryForException = retryProperties.getRetryForException();

        Request request = new Request();

        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("should NOT trigger retry!"));

        try {

            //when

            esbClient.getResponseBody(request);

        } catch (Exception e) {

            //then
            assertThat(e).isNotNull();
            assertThat(retryForException.isInstance(e)).isNotEqualTo(true);
            verify(restTemplateHelper, times(1)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());

            throw e;
        }


    }

    @Test(expected = ServiceUnavailableException.class)
    public void testPostForEntityCallJustOnceWithDefaultConfig() {
        //given

        this.context.register(BUBBLE_UP_EX_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);

        Request request = new Request();

        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("should NOT trigger retry!"));

        try {

            //when

            esbClient.getResponseBody(request);

        } catch (Exception e) {

            //then

            assertThat(e).isNotNull();
            verify(restTemplateHelper, times(1)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());

            throw e;
        }

    }

    @Test(expected = ServiceUnavailableException.class)
    public void testExceptionBubbleUpToTheCallerWhenNoRecovererInContext() {

        //given

        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:6");

        this.context.register(BUBBLE_UP_EX_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);
        Request request = new Request();
        EsbClientRequestProperties properties = context.getBean(EsbClientRequestProperties.class);
        EsbClientRequestProperties.RetryProperties retryProperties = properties.getRetry();
        Class<? extends Throwable> retryForException = retryProperties.getRetryForException();
        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("boo"));

        try {

            //when

            esbClient.getResponseBody(request);
        } catch (Exception e) {

            // then

            assertThat(e).isNotNull();
            assertThat(retryForException).isInstanceOf(e.getClass());
            verify(restTemplateHelper, times(6)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());
            throw e;
        }

    }

    @Test
    public void testExceptionNotBubbleUpToTheCallerWhenRecovererInContext() {

        //given

        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:2");

        this.context.register(ESB_CLIENT_CTX);
        this.context.register(EX_HANDLED_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);
        RecovererCtx.CallLogger callLogger = context.getBean(RecovererCtx.CallLogger.class);

        Request request = mock(Request.class);
        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("boo"));

        //when
        esbClient.getResponseBody(request);

        //then
        verify(restTemplateHelper, times(2)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());
        verify(callLogger, times(1)).error(anyString());
    }

    @Test(expected = ServiceUnavailableException.class)
    public void testRetryExhaustedAfterMaxAttempsWithoutRecoverer() {

        //given
        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:5");

        this.context.register(BUBBLE_UP_EX_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);
        Request request = new Request();

        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("boo"));

        try {

            //when
            esbClient.getResponseBody(request);
        } catch (Exception e) {

            //then
            assertThat(e).isNotNull();
            verify(restTemplateHelper, times(5)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());
            throw e;
        }


    }

    @Test
    public void testRetryExhaustedAfterMaxAttempsWithRecoverer() {

        //given

        EnvironmentTestUtils.addEnvironment(this.context, "ie.aib.msf.esbclient.request.retry.maxCount:3");

        this.context.register(ESB_CLIENT_CTX);
        this.context.register(EX_HANDLED_CTX);
        this.context.refresh();

        RestTemplateHelper restTemplateHelper = context.getBean(RestTemplateHelper.class);
        EsbClient esbClient = context.getBean(EsbClient.class);
        RecovererCtx.CallLogger callLogger = context.getBean(RecovererCtx.CallLogger.class);

        Request request = mock(Request.class);

        given(restTemplateHelper.postForEntity(anyObject(), anyObject(), anyObject(), anyObject()))
                .willThrow(new ServiceUnavailableException("boo"));

        //when
        esbClient.getResponseBody(request);

        //then
        verify(restTemplateHelper, times(3)).postForEntity(anyObject(), anyObject(), anyObject(), anyObject());
        verify(callLogger, times(1)).error(anyString());
    }

    @After
    public void tearDown() {
        if (this.context != null) {
            this.context.close();
        }
    }

    @Configuration
    static class RestTemplateHelperCtx {

        @Bean
        RestTemplateHelper restTemplateHelper() {
            return mock(RestTemplateHelper.class);
        }

    }

    @Configuration
    static class RecovererCtx {

        @Bean
        public CallLogger callLogger() {
            return mock(CallLogger.class);
        }

        @Bean
        public EsbClientRecoverer recoverer() {
            return r -> callLogger().error(String.format("ESB error processing %s", r.toString()));
        }

        interface CallLogger {

            void error(String msg);
        }
    }


}