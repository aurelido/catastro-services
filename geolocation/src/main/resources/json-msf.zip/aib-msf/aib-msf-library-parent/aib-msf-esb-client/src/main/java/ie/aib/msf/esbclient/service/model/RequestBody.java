package ie.aib.msf.esbclient.service.model;

public abstract class RequestBody {

}
