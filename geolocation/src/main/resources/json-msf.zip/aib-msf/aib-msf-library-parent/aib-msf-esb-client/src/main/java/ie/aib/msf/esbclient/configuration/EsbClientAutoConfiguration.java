package ie.aib.msf.esbclient.configuration;

import ie.aib.msf.core.helper.RestTemplateHelper;
import ie.aib.msf.esbclient.service.EsbClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;


@Configuration
@EnableConfigurationProperties(EsbClientRequestProperties.class)
public class EsbClientAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(RestTemplateHelper.class)
    public RestTemplateHelper restTemplateHelper(@Autowired RestTemplate restTemplate) {
        return new RestTemplateHelper(restTemplate);
    }

    @Bean
    EsbClient esbClient() {
        return new EsbClient();
    }

}


