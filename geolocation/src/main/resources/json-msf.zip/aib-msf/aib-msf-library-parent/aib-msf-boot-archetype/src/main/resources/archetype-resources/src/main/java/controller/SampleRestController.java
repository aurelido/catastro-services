#set($symbol_pound='#')#set($symbol_dollar='$')#set($symbol_escape='\')package ${package}.controller;

        import org.apache.commons.logging.Log;
        import org.apache.commons.logging.LogFactory;
        import org.springframework.web.bind.annotation.RequestMapping;
        import org.springframework.web.bind.annotation.RestController;

/**
 * TODO RestController Implementation
 */
@RestController
public class SampleRestController {

    private static final Log logger = LogFactory.getLog(SampleRestController.class);

    @RequestMapping("/")
    public String sampleEndpoint() {

        logger.info("Received a request");

        return "Hello Microservices!";
    }

}
