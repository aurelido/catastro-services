#!/bin/sh

# Customize JAVA_OPTS if necessary
JAVA_OPTS="$JAVA_OPTS "


exec java $JAVA_OPTS -Djava.security.egd=file:/dev/./urandom -jar /app.jar
exec "$@"
