#!/bin/sh

# Export the active docker machine IP
DOCKER_HOST_IP=$(docker-machine ip $(docker-machine active))
# docker-machine doesn't exist in Linux, assign default ip
DOCKER_HOST_IP=${DOCKER_HOST_IP:-0.0.0.0}
export DOCKER_HOST_IP

docker-compose -f docker-compose-sonar.yml up -d

while [ -z ${SONAR_SERVICE_READY} ]; do
  echo "Waiting for sonar service..."
  if [ "$(curl -I $DOCKER_HOST_IP:9000 2>&1 | grep -q 'HTTP/1.1 200 OK'; echo $?)" = 0 ]; then
    SONAR_SERVICE_READY=true;
  fi
  sleep 2
done


(cd .. && mvn sonar:sonar -Dsonar.host.url=http://$DOCKER_HOST_IP:9000)

sleep 3
start chrome "http://"$DOCKER_HOST_IP":9000"