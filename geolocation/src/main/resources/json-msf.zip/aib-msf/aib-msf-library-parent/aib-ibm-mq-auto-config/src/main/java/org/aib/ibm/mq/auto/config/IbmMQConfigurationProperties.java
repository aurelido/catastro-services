package org.aib.ibm.mq.auto.config;

import java.util.Properties;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "ie.aib.ibmmq")
public class IbmMQConfigurationProperties {

    public static final String USE_IBM_CIPHER_MAPPINGS_PROPERTY = "com.ibm.mq.cfg.useIBMCipherMappings";
    public static final int CACHE_SESSION_MAX_SIZE = 10;

    private String host;
    private int port;
    private String queueManager;
    private String channel;
    private String username;
    private String password;
    private boolean isXa;
    private Properties properties;
    private boolean isCached;
    private int cacheSessionMaxSize = CACHE_SESSION_MAX_SIZE;
    private boolean useIBMCipherMappings;

    public String getQueueManager() {
        return queueManager;
    }

    public void setQueueManager(String queueManager) {
        this.queueManager = queueManager;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isXa() {
        return isXa;
    }

    public void setXa(boolean isXa) {
        this.isXa = isXa;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public boolean isCached() {
        return isCached;
    }

    public void setCached(boolean isCached) {
        this.isCached = isCached;
    }

    public boolean isUseIBMCipherMappings() {
        return useIBMCipherMappings;
    }

    public void setUseIBMCipherMappings(boolean useIBMCipherMappings) {
        this.useIBMCipherMappings = useIBMCipherMappings;
    }

    public int getCacheSessionMaxSize() {
        return cacheSessionMaxSize;
    }

    public void setCacheSessionMaxSize(int cacheSessionMaxSize) {
        this.cacheSessionMaxSize = cacheSessionMaxSize;
    }
    
}
