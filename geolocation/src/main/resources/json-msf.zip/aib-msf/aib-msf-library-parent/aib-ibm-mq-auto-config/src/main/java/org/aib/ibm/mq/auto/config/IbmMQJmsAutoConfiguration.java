package org.aib.ibm.mq.auto.config;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.mq.jms.MQXAConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jms.JmsAutoConfiguration;
import org.springframework.boot.autoconfigure.jms.JndiConnectionFactoryAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;

/**
 * Create an IBM MQ connection factory auto configured through Spring Boot.
 */
@Configuration
@AutoConfigureBefore(JmsAutoConfiguration.class)
@AutoConfigureAfter({JndiConnectionFactoryAutoConfiguration.class})
@ConditionalOnClass({ConnectionFactory.class})
@EnableConfigurationProperties({IbmMQConfigurationProperties.class})
public class IbmMQJmsAutoConfiguration {

    private static final Log logger = LogFactory.getLog(IbmMQJmsAutoConfiguration.class);

    @ConditionalOnMissingBean({ConnectionFactory.class})
    @ConditionalOnProperty("ie.aib.ibmmq.host")
    @Bean
    ConnectionFactory ibmMQConnectionFactory(IbmMQConfigurationProperties config) throws JMSException {

        MQConnectionFactory mqConnectionFactory =
                config.isXa() ? new MQXAConnectionFactory() : new MQConnectionFactory();

        injectDynamicProperties(mqConnectionFactory, config);

        /*
         * If cipher suite set in dynamic properties (TLS_RSA_WITH_AES_128_CBC_SHA),
         * then set useIBMCipherMappings system property.
         *
         * Should be false by default for non-IBM java runtime, 
         * See https://developer.ibm.com/answers/questions/178651/what-tls-ciphersuites-are-supported-when-connectin/
         */
        if (StringUtils.isNotEmpty(mqConnectionFactory.getSSLCipherSuite())) {
            System.setProperty(IbmMQConfigurationProperties.USE_IBM_CIPHER_MAPPINGS_PROPERTY,
                    Boolean.toString(config.isUseIBMCipherMappings()));
        }

        mqConnectionFactory.setHostName(config.getHost());
        mqConnectionFactory.setPort(config.getPort());
        mqConnectionFactory.setQueueManager(config.getQueueManager());
        mqConnectionFactory.setChannel(config.getChannel());
        mqConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);

        ConnectionFactory connectionFactory = mqConnectionFactory;

        if (StringUtils.isNotBlank(config.getUsername())) {

            UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter =
                    new UserCredentialsConnectionFactoryAdapter();
            userCredentialsConnectionFactoryAdapter.setUsername(config.getUsername());
            userCredentialsConnectionFactoryAdapter.setPassword(config.getPassword());
            userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(connectionFactory);

            connectionFactory = userCredentialsConnectionFactoryAdapter;
        }

        if (config.isCached()) {

            CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory(connectionFactory);
            cachingConnectionFactory.setCacheConsumers(true);
            cachingConnectionFactory.setReconnectOnException(true);
            cachingConnectionFactory.setSessionCacheSize(config.getCacheSessionMaxSize());

            connectionFactory = cachingConnectionFactory;
        }

        return connectionFactory;
    }

    private void injectDynamicProperties(MQConnectionFactory factory, IbmMQConfigurationProperties config) {
        Properties mqProperties = config.getProperties();
        if (mqProperties != null) {

            for (String name : mqProperties.stringPropertyNames()) {

                if (PropertyUtils.isWriteable(factory, name)) {
                    try {
                        BeanUtils.setProperty(factory, name, mqProperties.get(name));

                    } catch (IllegalAccessException | InvocationTargetException e) {
                        logger.error("Unable to set property " + name + " on mq connectionFactory", e);
                    }
                } else {
                    logger.warn("The property " + name + " is not writable in the mq connectionFactory object!");
                }
            }
        }
    }
}
