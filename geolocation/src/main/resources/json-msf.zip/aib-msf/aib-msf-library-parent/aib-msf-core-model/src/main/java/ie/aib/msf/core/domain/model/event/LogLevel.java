package ie.aib.msf.core.domain.model.event;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 * Log level
 */
public enum LogLevel {
    CRITICAL,
    ERROR,
    WARNING,
    INFO,
    DEBUG,
    TRACE;

    // Support lower case mapping to/from this enum
    private static Map<String, LogLevel> logLevelsMap = new HashMap<>();

    static {

        for (LogLevel type : values()) {
            logLevelsMap.put(type.name().toLowerCase(), type);
        }
    }

    /**
     * Get the log level enum from its String representation
     *
     * @param key The String representation
     * @return The LogLevel
     */
    @JsonCreator
    public static LogLevel fromString(String key) {

        if (StringUtils.isNotBlank(key) && logLevelsMap.containsKey(key.toLowerCase())) {

            return logLevelsMap.get(key.toLowerCase());
        }
        return null;
    }

    @JsonValue
    public String toValue() {

        return name().toLowerCase();
    }
}
