package ie.aib.msf.core.domain.model.event;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 * The log type
 */
public enum LogType {

    AUDIT,
    NOTIFICATION,
    BUSINESS,
    APPLICATION,
    PERFORMANCE;


    // Support lower case mapping to/from this enum
    private static Map<String, LogType> logTypesMap = new HashMap<>();

    static {

        for (LogType type : values()) {
            logTypesMap.put(type.name().toLowerCase(), type);
        }
    }

    /**
     * Get the LogType from its String representation.
     *
     * @param key The String represenatation
     * @return The LogType
     */
    @JsonCreator
    public static LogType fromString(String key) {

        if (StringUtils.isNotBlank(key) && logTypesMap.containsKey(key.toLowerCase())) {

            return logTypesMap.get(key.toLowerCase());
        }
        return null;
    }

    @JsonValue
    public String toValue() {

        return name().toLowerCase();
    }
}
