package ie.aib.msf.core.domain.model.event.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import ie.aib.msf.core.domain.model.event.LogType;

@JsonInclude(Include.NON_NULL)
public class BusinessLogEntry extends AbstractLogEntry {

    private BusinessLogEntry() {
    }

    public static BusinessLogEntryBuilder builder() {
        return new BusinessLogEntryBuilder();
    }

    public static class BusinessLogEntryBuilder extends
            AbstractLogEntryBuilder<BusinessLogEntry, BusinessLogEntryBuilder> {

        private BusinessLogEntryBuilder() {
        }

        @Override
        protected BusinessLogEntry buildLogEntry() {
            BusinessLogEntry logEntry = new BusinessLogEntry();
            type(LogType.BUSINESS);
            return logEntry;
        }
    }
}
