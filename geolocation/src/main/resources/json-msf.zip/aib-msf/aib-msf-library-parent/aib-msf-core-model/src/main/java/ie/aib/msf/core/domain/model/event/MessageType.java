package ie.aib.msf.core.domain.model.event;

/**
 * The message type
 */
public enum MessageType {
    REQUEST,
    RESPONSE,
    NOTIFY
}
