package ie.aib.msf.core.domain.model.event.entry;

import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import ie.aib.msf.core.domain.model.event.LogType;
import ie.aib.msf.core.domain.model.event.MessageType;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(Include.NON_NULL)
public class AuditLogEntry extends AbstractLogEntry {

    private Object content;

    private String contentType;

    @NotNull
    private MessageType messageType;

    private AuditLogEntry() {
    }

    public static AuditLogEntryBuilder builder() {
        return new AuditLogEntryBuilder();
    }

    public Object getContent() {
        return content;
    }

    public String getContentType() {
        return contentType;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (obj.getClass() != this.getClass()) {
            return false;
        }

        AuditLogEntry e = (AuditLogEntry) obj;
        return new EqualsBuilder().appendSuper(true).append(content, e.content).append(contentType, e.contentType)
                .append(messageType, e.messageType).isEquals();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), content, contentType, messageType);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, JSON_STYLE).appendSuper(super.toString()).append("content", content)
                .append("contentType", contentType).append("messageType", messageType).toString();
    }

    public static class AuditLogEntryBuilder extends AbstractLogEntryBuilder<AuditLogEntry, AuditLogEntryBuilder> {

        private Object content;
        private String contentType;
        private MessageType messageType;

        private AuditLogEntryBuilder() {
        }

        public AuditLogEntryBuilder content(Object content) {
            this.content = content;
            return this;
        }

        public AuditLogEntryBuilder contentType(String contentType) {
            this.contentType = contentType;
            return this;
        }

        public AuditLogEntryBuilder messageType(MessageType messageType) {
            this.messageType = messageType;
            return this;
        }

        @Override
        protected AuditLogEntry buildLogEntry() {
            AuditLogEntry logEntry = new AuditLogEntry();
            logEntry.content = content;
            logEntry.contentType = contentType;
            logEntry.messageType = messageType;
            type(LogType.AUDIT);
            return logEntry;
        }
    }
}
