package ie.aib.msf.core.domain.model.event.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import ie.aib.msf.core.domain.model.event.LogType;

@JsonInclude(Include.NON_NULL)
public class ApplicationLogEntry extends AbstractLogEntry {

    private ApplicationLogEntry() {
    }

    public static ApplicationLogEntryBuilder builder() {
        return new ApplicationLogEntryBuilder();
    }

    public static class ApplicationLogEntryBuilder extends
            AbstractLogEntryBuilder<ApplicationLogEntry, ApplicationLogEntryBuilder> {

        private ApplicationLogEntryBuilder() {
        }

        @Override
        protected ApplicationLogEntry buildLogEntry() {
            ApplicationLogEntry logEntry = new ApplicationLogEntry();
            type(LogType.APPLICATION);
            return logEntry;
        }
    }
}
