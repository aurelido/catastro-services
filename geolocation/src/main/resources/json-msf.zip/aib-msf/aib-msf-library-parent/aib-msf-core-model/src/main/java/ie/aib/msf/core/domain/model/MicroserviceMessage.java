package ie.aib.msf.core.domain.model;

import java.util.HashMap;
import java.util.Map;


/**
 * Microservice Message envelope.
 *
 * @deprecated Message envelopes generally deprecated in favour of REST
 */
@SuppressWarnings({"unused", "WeakerAccess"})
@Deprecated
public class MicroserviceMessage<T> {

    public static final String JWT_HEADER = "JWT";
    private Map<String, Object> headers = new HashMap<>();

    private T payload;

    private MicroserviceMessage() {

    }

    private MicroserviceMessage(T payload) {

        this.payload = payload;
    }

    public static <T> Builder<T> builder(T payload) {

        return new MicroserviceMessage.Builder<>(payload);
    }

    public String getJwt() {

        return (String) headers.get(JWT_HEADER);
    }

    public T getPayload() {
        return payload;
    }

    public void setPayload(T payload) {
        this.payload = payload;
    }

    public Map<String, Object> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, Object> headers) {
        this.headers = headers;
    }

    @SuppressWarnings("WeakerAccess")
    public static class Builder<T> {

        private MicroserviceMessage<T> microserviceMessage;

        public Builder(T payload) {

            microserviceMessage = new MicroserviceMessage<>(payload);
        }

        /**
         * Set the headers.
         *
         * @param headers The headers to set
         * @return The builder obejcts, with headers set.
         */
        public Builder<T> headers(Map<String, Object> headers) {

            microserviceMessage.headers = headers;

            return this;
        }

        /**
         * Add a header value.
         *
         * @param key The header name
         * @param value The header value
         * @return The builder, with the header added.
         */
        public Builder<T> header(String key, Object value) {

            microserviceMessage.headers.put(key, value);

            return this;
        }

        /**
         * Add the Json Web Token.
         *
         * @param jsonWebToken The Json Web Token
         * @return The builder, with the JWT set.
         */
        public Builder<T> jwt(String jsonWebToken) {

            microserviceMessage.headers.put(JWT_HEADER, jsonWebToken);

            return this;
        }

        public MicroserviceMessage<T> build() {

            return microserviceMessage;
        }
    }

}
