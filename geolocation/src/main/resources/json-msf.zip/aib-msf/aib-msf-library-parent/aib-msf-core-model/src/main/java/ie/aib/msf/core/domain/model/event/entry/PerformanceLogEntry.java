package ie.aib.msf.core.domain.model.event.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import ie.aib.msf.core.domain.model.event.LogType;

@JsonInclude(Include.NON_NULL)
public class PerformanceLogEntry extends AbstractLogEntry {

    private PerformanceLogEntry() {
    }

    public static PerformanceLogEntryBuilder builder() {
        return new PerformanceLogEntryBuilder();
    }

    public static class PerformanceLogEntryBuilder extends
            AbstractLogEntryBuilder<PerformanceLogEntry, PerformanceLogEntryBuilder> {

        private PerformanceLogEntryBuilder() {
        }

        @Override
        protected PerformanceLogEntry buildLogEntry() {
            PerformanceLogEntry logEntry = new PerformanceLogEntry();
            type(LogType.PERFORMANCE);
            return logEntry;
        }
    }
}
