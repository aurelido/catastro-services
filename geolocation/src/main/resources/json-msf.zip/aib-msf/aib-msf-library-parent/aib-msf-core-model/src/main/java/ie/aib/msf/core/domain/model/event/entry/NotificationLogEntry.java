package ie.aib.msf.core.domain.model.event.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import ie.aib.msf.core.domain.model.event.LogType;

@JsonInclude(Include.NON_NULL)
public class NotificationLogEntry extends AbstractLogEntry {

    private NotificationLogEntry() {
    }

    public static NotificationLogEntryBuilder builder() {
        return new NotificationLogEntryBuilder();
    }

    public static class NotificationLogEntryBuilder extends
            AbstractLogEntryBuilder<NotificationLogEntry, NotificationLogEntryBuilder> {

        private NotificationLogEntryBuilder() {
        }

        @Override
        protected NotificationLogEntry buildLogEntry() {
            NotificationLogEntry logEntry = new NotificationLogEntry();
            type(LogType.NOTIFICATION);
            return logEntry;
        }
    }
}
