package ie.aib.msf.core.domain.model;

public abstract class AbstractHttpStatusResponseDto extends AbstractDto {

    private static final long serialVersionUID = 1L;

    protected int statusCode;

    public AbstractHttpStatusResponseDto(int statusCode) {
        super();
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

}
