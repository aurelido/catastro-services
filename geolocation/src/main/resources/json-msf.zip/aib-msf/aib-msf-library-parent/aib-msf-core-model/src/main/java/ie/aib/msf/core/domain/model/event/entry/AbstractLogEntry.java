package ie.aib.msf.core.domain.model.event.entry;

import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.LogType;
import java.net.InetAddress;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@SuppressWarnings({"unused", "WeakerAccess", "deprecation", "DeprecatedIsStillUsed"})
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "type",
        visible = true)
@JsonSubTypes({
        @Type(value = ApplicationLogEntry.class, name = "APPLICATION"),
        @Type(value = ApplicationLogEntry.class, name = "application"),
        @Type(value = AuditLogEntry.class, name = "AUDIT"),
        @Type(value = AuditLogEntry.class, name = "audit"),
        @Type(value = BusinessLogEntry.class, name = "BUSINESS"),
        @Type(value = BusinessLogEntry.class, name = "business"),
        @Type(value = NotificationLogEntry.class, name = "NOTIFICATION"),
        @Type(value = NotificationLogEntry.class, name = "notification"),
        @Type(value = PerformanceLogEntry.class, name = "PERFORMANCE"),
        @Type(value = PerformanceLogEntry.class, name = "performance")
})
@JsonInclude(Include.NON_NULL)
public abstract class AbstractLogEntry {

    public static final String CURRENT_VERSION = "1.0";

    @NotNull
    private LogType type;

    @NotNull
    private LogLevel severity;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone = "UTC")
    private Date timestamp;

    @NotNull
    private String host;

    @NotNull
    private String ip;

    @NotNull
    private String eventType;

    @NotNull
    private String application;

    @NotNull
    private String appVersion;

    private String message;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone = "UTC")
    private Date eventTime;

    private String requestId;
    private String parentRequestId;
    private String operationId;
    private String externalRequestId;
    private String sessionId;


    /**
     * User ID.
     * @deprecated Deprecated in favour of userIds.
     */
    @Deprecated
    private String userId;
    private List<Object> userIds;
    private Object payload;
    private String version = CURRENT_VERSION;

    public LogType getType() {
        return type;
    }

    public LogLevel getSeverity() {
        return severity;
    }

    /**
     * Get the log entry timestamp.
     *
     * @return The log entry timestamp
     */
    public Date getTimestamp() {
        Date date = null;
        if (timestamp != null) {
            date = new Date(timestamp.getTime());
        }
        return date;
    }

    public String getHost() {
        return host;
    }

    public String getIp() {
        return ip;
    }

    public String getEventType() {
        return eventType;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getMessage() {
        return message;
    }

    /**
     * Get the event time.
     *
     * @return The event time
     */
    public Date getEventTime() {
        Date date = null;
        if (eventTime != null) {
            date = new Date(eventTime.getTime());
        }
        return date;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getParentRequestId() {
        return parentRequestId;
    }

    public String getOperationId() {
        return operationId;
    }

    public String getExternalRequestId() {
        return externalRequestId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getUserId() {
        return userId;
    }

    public List<Object> getUserIds() {
        return userIds;
    }

    public Object getPayload() {
        return payload;
    }

    public String getVersion() {
        return version;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (obj.getClass() != this.getClass()) {
            return false;
        }

        AbstractLogEntry e = (AbstractLogEntry) obj;
        return new EqualsBuilder().append(e.type, type).append(e.severity, severity).append(e.timestamp, timestamp)
                .append(e.host, host).append(e.ip, ip).append(e.eventType, eventType).append(e.application, application)
                .append(e.appVersion, appVersion).append(e.message, message).append(e.eventTime, eventTime)
                .append(e.parentRequestId, parentRequestId).append(e.operationId, operationId)
                .append(e.externalRequestId, externalRequestId).append(e.sessionId, sessionId)
                .append(e.userId, userId)
                .append(e.userIds, userIds)
                .append(e.version, version)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, severity, timestamp, host, ip, eventType, application, appVersion, message,
                eventTime, requestId, parentRequestId, operationId, externalRequestId, sessionId,
                userId, userIds, version);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, JSON_STYLE).append("type", type).append("severity", severity)
                .append("timestamp", timestamp).append("host", host).append("ip", ip).append("eventType", eventType)
                .append("application", application).append("appVersion", appVersion).append("message", message)
                .append("eventTime", eventTime)
                .append("parentRequestId", parentRequestId).append("operationId", operationId)
                .append("externalRequestId", externalRequestId).append("sessionId", sessionId)
                .append("userId", userId)
                .append("userIds", userIds)
                .append("version", version)
                .toString();
    }

    @SuppressWarnings({"rawtypes", "unchecked", "unused", "UnusedReturnValue"})
    public abstract static class AbstractLogEntryBuilder<T extends AbstractLogEntry, U extends AbstractLogEntryBuilder> {

        private static final Log LOGGER = LogFactory.getLog(AbstractLogEntryBuilder.class);

        private LogType type;
        private LogLevel severity;
        private Date timestamp;
        private String host;
        private String ip;
        private String eventType;
        private String application;
        private String appVersion;
        private String message;
        private Date eventTime;
        private String requestId;
        private String parentRequestId;
        private String operationId;
        private String externalRequestId;
        private String sessionId;
        private String userId;
        private List<Object> userIds;
        private Object payload;
        private String version = CURRENT_VERSION;

        public U type(LogType type) {
            this.type = type;
            return (U) this;
        }

        public U severity(LogLevel severity) {
            this.severity = severity;
            return (U) this;
        }

        public U timestamp(Date timestamp) {
            this.timestamp = new Date(timestamp.getTime());
            return (U) this;
        }

        public U host(String host) {
            this.host = host;
            return (U) this;
        }

        public U ip(String ip) {
            this.ip = ip;
            return (U) this;
        }

        public U eventType(String eventId) {
            this.eventType = eventId;
            return (U) this;
        }

        public U application(String application) {
            this.application = application;
            return (U) this;
        }

        public U appVersion(String appVersion) {
            this.appVersion = appVersion;
            return (U) this;
        }

        public U message(String message) {
            this.message = message;
            return (U) this;
        }

        public U eventTime(Date eventTime) {
            this.eventTime = new Date(eventTime.getTime());
            return (U) this;
        }

        public U requestId(String requestId) {
            this.requestId = requestId;
            return (U) this;
        }

        public U parentRequestId(String parentRequestId) {
            this.parentRequestId = parentRequestId;
            return (U) this;
        }

        public U operationId(String operationId) {
            this.operationId = operationId;
            return (U) this;
        }

        public U externalRequestId(String externalRequestId) {
            this.externalRequestId = externalRequestId;
            return (U) this;
        }

        public U sessionId(String sessionId) {
            this.sessionId = sessionId;
            return (U) this;
        }

        public U userId(String userId) {
            this.userId = userId;
            return (U) this;
        }

        public U userIds(List<Object> userIds) {
            this.userIds = userIds;
            return (U) this;
        }

        public U payload(Object payload) {
            this.payload = payload;
            return (U) this;
        }

        public U version(String version) {
            this.version = version;
            return (U) this;
        }

        /**
         * Build the log entry object.
         *
         * @return The log entry object
         */
        public T build() {
            T logEntry = buildLogEntry();
            setDefaults(logEntry);
            setProperties(logEntry);
            return logEntry;
        }

        protected abstract T buildLogEntry();

        private void setDefaults(AbstractLogEntry logEntry) {
            if (this.timestamp == null) {
                this.timestamp = new Date();
            }

            setDefaultHostInfo(logEntry);
        }

        private void setProperties(AbstractLogEntry logEntry) {
            logEntry.type = this.type;
            logEntry.severity = this.severity;
            logEntry.timestamp = this.timestamp;
            logEntry.host = this.host;
            logEntry.ip = this.ip;
            logEntry.eventType = this.eventType;
            logEntry.application = this.application;
            logEntry.appVersion = this.appVersion;
            logEntry.message = this.message;
            logEntry.eventTime = this.eventTime;
            logEntry.requestId = this.requestId;
            logEntry.parentRequestId = this.parentRequestId;
            logEntry.operationId = this.operationId;
            logEntry.externalRequestId = this.externalRequestId;
            logEntry.sessionId = this.sessionId;
            logEntry.userId = this.userId;
            logEntry.userIds = this.userIds;
            logEntry.payload = this.payload;
            logEntry.version = this.version;
        }

        private void setDefaultHostInfo(AbstractLogEntry logEntry) {
            if (StringUtils.isEmpty(this.host) || StringUtils.isEmpty(this.ip)) {
                try {
                    InetAddress localhost = InetAddress.getLocalHost();
                    this.host = localhost.getCanonicalHostName();
                    this.ip = localhost.getHostAddress();

                    if (StringUtils.isEmpty(this.host)) {
                        logEntry.host = this.host;
                    }
                    if (StringUtils.isEmpty(this.ip)) {
                        logEntry.ip = this.ip;
                    }

                } catch (Exception e) {
                    LOGGER.debug("Could not resolve hostname", e);
                }
            }
        }
    }
}
