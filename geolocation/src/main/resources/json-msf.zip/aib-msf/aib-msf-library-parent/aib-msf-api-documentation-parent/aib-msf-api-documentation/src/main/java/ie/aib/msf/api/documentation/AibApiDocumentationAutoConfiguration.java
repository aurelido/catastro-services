package ie.aib.msf.api.documentation;

import com.fasterxml.classmate.TypeResolver;
import io.swagger.annotations.ApiModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import springfox.documentation.schema.ModelProvider;
import springfox.documentation.spring.web.plugins.DocumentationPluginsManager;

@Configuration
@ComponentScan(basePackageClasses = DocumentationController.class)
public class AibApiDocumentationAutoConfiguration {

    @Value("#{'${ie.aib.documentation.packages}'.split(',')}")
    private String[] scanPackages;

    @Bean
    AibOperationModelsProviderPlugin aibOperationModelsProviderPlugin() {

        return new AibOperationModelsProviderPlugin(createComponentScanner(), scanPackages);
    }

    @Bean
    AibApiModelReader aibApiModelReader(
            @Qualifier("cachedModels") ModelProvider modelProvider,
            TypeResolver typeResolver,
            DocumentationPluginsManager pluginsManager) {

        return new AibApiModelReader(modelProvider, typeResolver, pluginsManager);
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    ClassPathScanningCandidateComponentProvider createComponentScanner() {

        ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(false);
        provider.addIncludeFilter(new AnnotationTypeFilter(ApiModel.class));

        return provider;
    }
}
