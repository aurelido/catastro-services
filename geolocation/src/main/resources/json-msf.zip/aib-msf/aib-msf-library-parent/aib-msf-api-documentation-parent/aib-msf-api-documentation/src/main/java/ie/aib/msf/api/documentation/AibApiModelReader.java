package ie.aib.msf.api.documentation;

import static com.google.common.collect.Maps.newHashMap;
import static com.google.common.collect.Sets.newHashSet;

import com.fasterxml.classmate.TypeResolver;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import springfox.documentation.builders.ModelBuilder;
import springfox.documentation.schema.Model;
import springfox.documentation.schema.ModelProperty;
import springfox.documentation.schema.ModelProvider;
import springfox.documentation.spi.schema.contexts.ModelContext;
import springfox.documentation.spi.service.contexts.RequestMappingContext;
import springfox.documentation.spring.web.plugins.DocumentationPluginsManager;

// @Component
public class AibApiModelReader {

    private static final Logger LOG = LoggerFactory.getLogger(AibApiModelReader.class);

    private final ModelProvider modelProvider;
    private final TypeResolver typeResolver;
    private final DocumentationPluginsManager pluginsManager;

    @Autowired
    AibApiModelReader(@Qualifier("cachedModels") ModelProvider modelProvider, TypeResolver typeResolver,
            DocumentationPluginsManager pluginsManager) {
        this.modelProvider = modelProvider;
        this.typeResolver = typeResolver;
        this.pluginsManager = pluginsManager;
    }

    /**
     * Read the model map from the context
     *
     * @param context The request mapping context
     * @return The model map
     */
    public Map<String, Model> read(RequestMappingContext context) {

        Set<Class<?>> ignorableTypes = ImmutableSet.of();
        Set<ModelContext> modelContexts = pluginsManager.modelContexts(context);
        Map<String, Model> modelMap = newHashMap(context.getModelMap());
        for (ModelContext each : modelContexts) {
            markIgnorablesAsHasSeen(typeResolver, ignorableTypes, each);
            Optional<Model> providedModel = modelProvider.modelFor(each);
            if (providedModel.isPresent()) {
                LOG.debug("Generated parameter model id: {}, name: {}, schema: {} models", providedModel.get().getId(),
                        providedModel.get().getName());
                mergeModelMap(modelMap, providedModel.get());
            } else {
                LOG.debug("Did not find any parameter models for {}", each.getType());
            }
            populateDependencies(each, modelMap);
        }
        return modelMap;
    }

    private void mergeModelMap(Map<String, Model> target, Model source) {
        String sourceModelKey = source.getId();

        if (!target.containsKey(sourceModelKey)) {
            // if we encounter completely unknown model, just add it
            LOG.debug("Adding a new model with key {}", sourceModelKey);
            target.put(sourceModelKey, source);
        } else {
            // we can encounter a known model with an unknown property
            // if (de)serialization is not symmetrical (@JsonIgnore on setter,
            // @JsonProperty on getter).
            // In these cases, don't overwrite the entire model entry for that
            // type, just add the unknown property.
            Model targetModelValue = target.get(sourceModelKey);

            Map<String, ModelProperty> targetProperties = targetModelValue.getProperties();
            Map<String, ModelProperty> sourceProperties = source.getProperties();

            Set<String> newSourcePropKeys = newHashSet(sourceProperties.keySet());
            newSourcePropKeys.removeAll(targetProperties.keySet());
            Map<String, ModelProperty> mergedTargetProperties = Maps.newHashMap(targetProperties);
            for (String newProperty : newSourcePropKeys) {
                LOG.debug("Adding a missing property {} to model {}", newProperty, sourceModelKey);
                mergedTargetProperties.put(newProperty, sourceProperties.get(newProperty));
            }

            Model mergedModel = new ModelBuilder().id(targetModelValue.getId()).name(targetModelValue.getName())
                    .type(targetModelValue.getType()).qualifiedType(targetModelValue.getQualifiedType())
                    .properties(mergedTargetProperties).description(targetModelValue.getDescription())
                    .baseModel(targetModelValue.getBaseModel()).discriminator(targetModelValue.getDiscriminator())
                    .subTypes(targetModelValue.getSubTypes()).example(targetModelValue.getExample()).build();

            target.put(sourceModelKey, mergedModel);
        }
    }

    private void markIgnorablesAsHasSeen(TypeResolver typeResolver, Set<Class<?>> ignorableParameterTypes,
            ModelContext modelContext) {

        for (Class<?> ignorableParameterType : ignorableParameterTypes) {
            modelContext.seen(typeResolver.resolve(ignorableParameterType));
        }
    }

    private void populateDependencies(ModelContext modelContext, Map<String, Model> modelMap) {
        Map<String, Model> dependencies = modelProvider.dependencies(modelContext);
        for (Model each : dependencies.values()) {
            mergeModelMap(modelMap, each);
        }
    }

}
