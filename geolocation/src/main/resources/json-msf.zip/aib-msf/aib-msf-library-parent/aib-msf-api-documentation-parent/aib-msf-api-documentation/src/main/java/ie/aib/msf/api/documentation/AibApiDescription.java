package ie.aib.msf.api.documentation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a class as an API for documentation purposes.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface AibApiDescription {

    /**
     * Logical path name, ideally is indicative of type of input, i.e. jms-queue-blah-blah
     *
     * @return path
     */
    String path();

    /**
     * Get the description.
     *
     * @return The description
     */
    String description();

    /**
     * Get the transport type.
     *
     * @return The transport type
     */
    TransportType transportType() default TransportType.JMS;
}
