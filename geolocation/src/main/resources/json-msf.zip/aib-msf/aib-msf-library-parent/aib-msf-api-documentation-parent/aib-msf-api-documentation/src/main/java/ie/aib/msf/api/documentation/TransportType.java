package ie.aib.msf.api.documentation;

public enum TransportType {

    JMS,
    KAFKA
}
