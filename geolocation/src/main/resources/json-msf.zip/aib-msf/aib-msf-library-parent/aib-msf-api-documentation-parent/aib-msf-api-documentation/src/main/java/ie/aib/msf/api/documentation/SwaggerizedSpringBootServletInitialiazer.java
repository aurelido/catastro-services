package ie.aib.msf.api.documentation;

import static com.google.common.base.Strings.emptyToNull;
import static com.google.common.collect.Lists.newArrayList;

import com.fasterxml.classmate.ResolvedType;
import com.fasterxml.classmate.TypeResolver;
import com.fasterxml.classmate.types.ResolvedPrimitiveType;
import com.google.common.base.Predicate;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.plugin.core.PluginRegistry;
import org.springframework.plugin.core.SimplePluginRegistry;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.OperationBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.AlternateTypeRules;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiDescription;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Operation;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.AlternateTypeProvider;
import springfox.documentation.spi.schema.GenericTypeNamingStrategy;
import springfox.documentation.spi.service.ApiListingScannerPlugin;
import springfox.documentation.spi.service.contexts.DocumentationContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.spring.web.readers.operation.CachingOperationNameGenerator;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
public abstract class SwaggerizedSpringBootServletInitialiazer extends SpringBootServletInitializer {

    @Autowired
    private TypeResolver typeResolver;

    @Autowired
    private CachingOperationNameGenerator cachingOperationNameGenerator;

    @Autowired
    private ListableBeanFactory listableBeanFactory;

    @Bean
    Docket openAccountType() {
        return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
                .paths(buildPathSelectorsRegex())
                .build()
                .pathMapping("/")
                .apiInfo(apiInfo())
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(AlternateTypeRules.newRule(
                        typeResolver.resolve(DeferredResult.class,
                                typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
                        typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(false)
                // TODO this generates braces in paths, to help identify different endpoints by the params
                // but doesn't work with curl or swagger-ui paths, so ideally will disable
                .enableUrlTemplating(false);
    }

    private Predicate<String> buildPathSelectorsRegex() {

        StringJoiner pathSelectorJoiner = new StringJoiner("|");

        String[] pathsToSwaggerize = getPathsToSwaggerize();
        if (pathsToSwaggerize != null && pathsToSwaggerize.length > 0) {

            for (String pathSelectorRegex : pathsToSwaggerize) {

                pathSelectorJoiner.add(pathSelectorRegex);
            }

        } else {
            // Default path, as won't generate if there is no default
            pathSelectorJoiner.add("/apiDocumentationDummy");
        }

        return PathSelectors.regex(pathSelectorJoiner.toString());
    }

    /**
     * Return a string array of regex paths that should be scanned for Swagger annotations, e.g. /audit etc...
     *
     * @return pathsToSwaggerize - Can be a regex
     */
    public abstract String[] getPathsToSwaggerize();

    public abstract String apiInfoTitle();

    protected ApiInfo apiInfo() {
        return new ApiInfoBuilder().title(apiInfoTitle())
                .description("Spring REST Sample with Swagger").termsOfServiceUrl("http://terms-of-service.aib.pri")
                .license("AIB license??").licenseUrl("https://www.aib.com/api/license?TBD").version("1.0").build();
    }

    @Bean(name = "apiListingScannerPluginRegistry")
    PluginRegistry<ApiListingScannerPlugin, DocumentationType> apiListingScannerPluginRegistry() {

        ArrayList<ApiListingScannerPlugin> plugins = new ArrayList<>();

        plugins.add(apiListingScannerPlugin());

        return SimplePluginRegistry.create(plugins);
    }

    @Bean
    ApiListingScannerPlugin apiListingScannerPlugin() {
        return new ApiListingScannerPlugin() {

            @Override
            public boolean supports(DocumentationType delimiter) {

                return true;
            }

            @Override
            public List<ApiDescription> apply(DocumentationContext context) {

                ArrayList<ApiDescription> apiDescriptions = new ArrayList<>();

                findAndAddApiDescriptions(apiDescriptions, context.getDocumentationType(),
                        context.getAlternateTypeProvider(), context.getGenericsNamingStrategy(), context);

                return apiDescriptions;
            }
        };
    }

    @SuppressWarnings("unused")
    protected void findAndAddApiDescriptions(ArrayList<ApiDescription> apiDescriptions,
            DocumentationType documentationType, AlternateTypeProvider alternateTypeProvider,
            GenericTypeNamingStrategy genericTypeNamingStrategy, DocumentationContext context) {

        List<ResolvedPrimitiveType> primitiveTypes = ResolvedPrimitiveType.all();

        for (Object beanWithAibApiDescription : listableBeanFactory.getBeansWithAnnotation(AibApiDescription.class)
                .values()) {

            Class<?> beanWithAibApiDescriptionClass = beanWithAibApiDescription.getClass();
            AibApiDescription aibApiDescription = beanWithAibApiDescriptionClass.getAnnotation(AibApiDescription.class);

            // Operations
            List<Operation> operations = buildOperations(primitiveTypes, beanWithAibApiDescriptionClass,
                    aibApiDescription);

            // api description
            ApiDescription apiDescription = new ApiDescription(aibApiDescription.path(),
                    aibApiDescription.description(), operations, false);

            apiDescriptions.add(apiDescription);
        }

    }

    private List<Operation> buildOperations(List<ResolvedPrimitiveType> primitiveTypes,
            Class<?> beanWithAibApiDescriptionClass, AibApiDescription aibApiDescription) {

        ArrayList<Operation> operations = new ArrayList<>();

        for (Method method : beanWithAibApiDescriptionClass.getMethods()) {

            if (method.isAnnotationPresent(ApiOperation.class)) {
                ApiOperation apiOperation = method.getAnnotation(ApiOperation.class);

                List<Parameter> parameters = buildParametersForOperation(primitiveTypes, method);

                Operation operation = new OperationBuilder(cachingOperationNameGenerator)
                        .method(HttpMethod.PUT)
                        .uniqueId(aibApiDescription.transportType() + "-" + method.getName() + "-" + apiOperation
                                .value()) // Add the method name
                        .parameters(parameters)
                        .build();
                operations.add(operation);
            }
        }

        return operations;
    }

    private List<Parameter> buildParametersForOperation(List<ResolvedPrimitiveType> primitiveTypes, Method method) {

        Annotation[][] annotationsForAllParameters = method.getParameterAnnotations();
        Class<?>[] parameterTypes = method.getParameterTypes();
        ArrayList<Parameter> parameters = newArrayList();

        for (int i = 0; i < parameterTypes.length; i++) {

            Class<?> parameterType = parameterTypes[i];
            Annotation[] annotationForParameter = annotationsForAllParameters[i];

            for (Annotation annotation : annotationForParameter) {
                if (annotation.annotationType() == ApiParam.class) {

                    ParameterBuilder parameterBuilder = new ParameterBuilder();

                    String modelRefType = determineModelRefType(primitiveTypes, parameterType);
                    parameterBuilder.modelRef(new ModelRef(modelRefType));

                    // TODO may want to see if the parameter is also annotated with a header annotation, 
                    // in which case should set the parameterType to header
                    parameterBuilder.parameterType("request");

                    ApiParam apiParam = (ApiParam) annotation;
                    parameterBuilder.name(emptyToNull(apiParam.name()));
                    parameterBuilder.description(emptyToNull(apiParam.value()));
                    parameterBuilder.parameterAccess(emptyToNull(apiParam.access()));
                    parameterBuilder.defaultValue(emptyToNull(apiParam.defaultValue()));
                    parameterBuilder.allowMultiple(apiParam.allowMultiple());
                    parameterBuilder.required(apiParam.required());

                    parameters.add(parameterBuilder.build());
                }
            }
        }

        return parameters;
    }

    private String determineModelRefType(List<ResolvedPrimitiveType> primitiveTypes, Class<?> parameterType) {

        String typeName = parameterType.getTypeName();
        String modelRefType = null;

        // 1. Determine if it's a primitive type
        for (ResolvedType resolvedType : primitiveTypes) {

            if (resolvedType.getTypeName().equals(typeName)) {
                // Can ignore it
                modelRefType = resolvedType.getFullDescription();
            }
        }

        // 2. Determine if it's a String type
        if (modelRefType == null && typeName.equals(String.class.getTypeName())) {

            modelRefType = "string";

        } else {

            int typeOffsetIndex = 0;

            if (typeName.contains(".")) {
                typeOffsetIndex = typeName.lastIndexOf('.') + 1;
            }

            modelRefType = typeName.substring(typeOffsetIndex);
        }

        return modelRefType;
    }
}
