package ie.aib.msf.api.documentation;

import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.OperationModelsProviderPlugin;
import springfox.documentation.spi.service.contexts.OperationModelContextsBuilder;
import springfox.documentation.spi.service.contexts.RequestMappingContext;

/**
 * Finds all classes annotated with @ApiModel in the package specified with the Spring property
 * ie.aib.documentation.packages.
 *
 * @author 96442
 */
public class AibOperationModelsProviderPlugin implements OperationModelsProviderPlugin {

    private static final Logger LOG = LoggerFactory.getLogger(AibOperationModelsProviderPlugin.class);

    private String[] scanPackages;

    @Autowired
    private ClassPathScanningCandidateComponentProvider apiModelClassPathScanningCandidateComponentProvider;

    /**
     * Create a new instance of AibOperationModelsProviderPlugin.
     *
     * @param apiModelClassPathScanningCandidateComponentProvider the component provider
     * @param scanPackages The packages to scan
     */
    public AibOperationModelsProviderPlugin(
            ClassPathScanningCandidateComponentProvider apiModelClassPathScanningCandidateComponentProvider,
            String[] scanPackages) {

        this.apiModelClassPathScanningCandidateComponentProvider = apiModelClassPathScanningCandidateComponentProvider;
        this.scanPackages = scanPackages;
    }

    @Override
    public void apply(RequestMappingContext context) {

        OperationModelContextsBuilder operationModelsBuilder = context.operationModelsBuilder();
        ClassPathScanningCandidateComponentProvider provider = apiModelClassPathScanningCandidateComponentProvider;

        if (scanPackages != null && scanPackages.length > 0) {

            for (String scanPackage : scanPackages) {

                for (BeanDefinition beanDef : provider.findCandidateComponents(scanPackage)) {

                    Optional<Class<?>> clazz = getApiModel(beanDef);
                    clazz.ifPresent(aClass -> {
                        Class<?> apiModelType = aClass;
                        operationModelsBuilder.addInputParam(apiModelType);
                        operationModelsBuilder.addReturn(apiModelType);
                    });
                }
            }
        }

    }


    private Optional<Class<?>> getApiModel(BeanDefinition beanDef) {

        try {
            Class<?> cl = Class.forName(beanDef.getBeanClassName());

            return Optional.of(cl);

        } catch (Exception e) {
            LOG.error("Got exception: " + e.getMessage());
        }

        return Optional.empty();
    }

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

}