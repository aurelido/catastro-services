package ie.aib.msf.api.documentation;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import io.github.robwin.markup.builder.MarkupLanguage;
import java.nio.file.Paths;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import springfox.documentation.staticdocs.Swagger2MarkupResultHandler;

public abstract class AbstractAsciiDocumentGeneratorTest {

    private static final String V2_API_DOCS = "/v2/api-docs";
    private static final String INDEX_DOCUMENT =
            "include::generated/overview.adoc[]\r\n"
                    + "include::generated/paths.adoc[]\r\n"
                    + "include::generated/definitions.adoc[]";
    @Autowired
    private WebApplicationContext context;
    private MockMvc mockMvc;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).build();
    }

    @Test
    public void convertSwaggerToAsciiDoc() throws Exception {

        this.mockMvc.perform(get(V2_API_DOCS)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(Swagger2MarkupResultHandler.outputDirectory("src/main/asciidoc/generated").build())
                .andExpect(status().isOk());

        Files.write(INDEX_DOCUMENT, Paths.get("src/main/asciidoc/index.adoc").toFile(), Charsets.UTF_8);
    }

    @Test
    public void convertSwaggerToMarkdown() throws Exception {
        this.mockMvc.perform(get(V2_API_DOCS)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(Swagger2MarkupResultHandler.outputDirectory("src/main/markdown/generated")
                        .withMarkupLanguage(MarkupLanguage.MARKDOWN).build())
                .andExpect(status().isOk());
    }
}
