package ie.aib.msf.api.documentation;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DocumentationController {

    @GetMapping(path = "/apiDocumentationDummy")
    public ResponseEntity getDocumentation() {

        return ResponseEntity.ok().build();
    }
}
