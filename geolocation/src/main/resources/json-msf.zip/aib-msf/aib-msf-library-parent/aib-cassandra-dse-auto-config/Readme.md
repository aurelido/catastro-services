## aib-cassandra-dse-auto-config

Will automatically configure the following beans (if not explicitly provided) when `com.datastax.driver.core.Cluster` is found on the classpath:


* `com.datastax.driver.core.Cluster`
* `com.datastax.driver.core.Session`
* `com.datastax.driver.mapping.MappingManager`


### Configurable Properties

Property | Default Value
--- | ---
`ie.aib.cassandra.dse.contactPoints` | localhost
`ie.aib.cassandra.dse.port` | 9042
`ie.aib.cassandra.dse.username` | (no default value, **required property**)
`ie.aib.cassandra.dse.password` | (no default value, **required property**)
`ie.aib.cassandra.dse.ssl` | false
`ie.aib.cassandra.dse.keyspace` | (no default value)
`ie.aib.cassandra.dse.usingDateTimeCodecs` | true (when true will register: InstantCodec.instance, SimpleTimestampCodec, SimpleDateCodec)
`ie.aib.cassandra.dse.localDc` | (no default value)
`ie.aib.cassandra.dse.usedHostsPerRemoteDc` | 1
`ie.aib.cassandra.dse.consistencyLevel` | ConsistencyLevel.LOCAL_QUORUM
`ie.aib.cassandra.dse.fetchSize` | QueryOptions.DEFAULT_FETCH_SIZE (5000)
`ie.aib.cassandra.dse.constantReconnectionMillis` | (no default value)
`ie.aib.cassandra.dse.connectTimeoutMillis` | SocketOptions.DEFAULT_CONNECT_TIMEOUT_MILLIS (5000 milliseconds)
`ie.aib.cassandra.dse.readTimeoutMillis` | SocketOptions.DEFAULT_READ_TIMEOUT_MILLIS (12000 milliseconds)
