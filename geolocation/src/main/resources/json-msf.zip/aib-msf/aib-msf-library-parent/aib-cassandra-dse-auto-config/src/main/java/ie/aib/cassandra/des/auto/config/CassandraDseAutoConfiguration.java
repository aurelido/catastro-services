package ie.aib.cassandra.des.auto.config;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SocketOptions;
import com.datastax.driver.core.policies.ConstantReconnectionPolicy;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;
import com.datastax.driver.core.policies.LoadBalancingPolicy;
import com.datastax.driver.core.policies.ReconnectionPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import com.datastax.driver.core.policies.TokenAwarePolicy;
import com.datastax.driver.extras.codecs.date.SimpleDateCodec;
import com.datastax.driver.extras.codecs.date.SimpleTimestampCodec;
import com.datastax.driver.extras.codecs.jdk8.InstantCodec;
import com.datastax.driver.mapping.MappingManager;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanInstantiationException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

/**
 * @deprecated As of 1.2.11, use {@link ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfiguration}
 */
@Deprecated
@SuppressWarnings("DeprecatedIsStillUsed")
@Configuration
@ConditionalOnClass({Cluster.class})
@EnableConfigurationProperties(CassandraDseAutoConfigurationProperties.class)
public class CassandraDseAutoConfiguration {

    private static final Log LOG = LogFactory.getLog(CassandraDseAutoConfiguration.class);

    private final CassandraDseAutoConfigurationProperties properties;
    private final List<ClusterBuilderCustomizer> builderCustomizers;

    @Autowired
    public CassandraDseAutoConfiguration(CassandraDseAutoConfigurationProperties properties,
            ObjectProvider<List<ClusterBuilderCustomizer>> builderCustomizers) {
        this.properties = properties;
        this.builderCustomizers = builderCustomizers.getIfAvailable();

        LOG.warn("CassandraDseAutoConfiguration has been deprecated and will be REMOVED from a future release.  Please move to SupplementalCassandraAutoConfiguration (aib-msf-cassandra-auto-config)");
    }

    /**
     * @return Cluster
     */
    @Bean
    @ConditionalOnMissingBean
    public Cluster cluster() {
        Cluster.Builder clusterBuilder = Cluster.builder()
                .addContactPoints(StringUtils.commaDelimitedListToStringArray(properties.getContactPoints()))
                .withPort(properties.getPort());

        if (!StringUtils.isEmpty(properties.getUsername())) {
            clusterBuilder.withCredentials(properties.getUsername(), properties.getPassword());
        }

        if (properties.isSsl()) {
            clusterBuilder.withSSL();
        }

        if (properties.isUsingDateTimeCodecs()) {
            clusterBuilder.getConfiguration().getCodecRegistry()
                    .register(InstantCodec.instance, new SimpleTimestampCodec(), new SimpleDateCodec());
        }

        withLoadBalancingPolicy(clusterBuilder);
        withQueryOptions(clusterBuilder);
        withReconnectionPolicy(clusterBuilder);
        withRetryPolicy(clusterBuilder);
        withSocketOptions(clusterBuilder);
        customize(clusterBuilder);

        return clusterBuilder.build();
    }

    /**
     * localDc
     *
     * @param clusterBuilder cluster builder
     * @see CassandraDseAutoConfigurationProperties
     * @see <a href="https://gitstash.aib.pri/projects/MSF/repos/aib-msf/browse/aib-msf-library-parent/aib-cassandra-dse-auto-config">aib-cassandra-dse-auto-config</a>
     */
    private void withLoadBalancingPolicy(Cluster.Builder clusterBuilder) {
        if (StringUtils.isEmpty(properties.getLocalDc())) {
            LOG.warn("No localDc has been configured");
        } else {
            LoadBalancingPolicy childPolicy = DCAwareRoundRobinPolicy.builder()
                    .withLocalDc(properties.getLocalDc())
                    .allowRemoteDCsForLocalConsistencyLevel()
                    .withUsedHostsPerRemoteDc(properties.getUsedHostsPerRemoteDc())
                    .build();
            LoadBalancingPolicy parentPolicy = new TokenAwarePolicy(childPolicy, true);
            clusterBuilder.withLoadBalancingPolicy(parentPolicy);
        }
    }

    private void withQueryOptions(Cluster.Builder clusterBuilder) {
        QueryOptions queryOptions = new QueryOptions();
        queryOptions.setConsistencyLevel(properties.getConsistencyLevel());
        queryOptions.setFetchSize(properties.getFetchSize());
        clusterBuilder.withQueryOptions(queryOptions);
    }

    private void withReconnectionPolicy(Cluster.Builder clusterBuilder) {
        if (properties.getConstantReconnectionMillis() != null) {
            ReconnectionPolicy policy = new ConstantReconnectionPolicy(properties.getConstantReconnectionMillis());
            clusterBuilder.withReconnectionPolicy(policy);
        }
    }

    private void withRetryPolicy(Cluster.Builder clusterBuilder) {
        clusterBuilder.withRetryPolicy(instantiate(properties.getRetryPolicy()));
    }

    private void withSocketOptions(Cluster.Builder clusterBuilder) {
        SocketOptions socketOptions = new SocketOptions();
        socketOptions.setConnectTimeoutMillis(properties.getConnectTimeoutMillis());
        socketOptions.setReadTimeoutMillis(properties.getReadTimeoutMillis());
        clusterBuilder.withSocketOptions(socketOptions);
    }

    /**
     * @param cluster the cluster to connect to
     * @return Session
     */
    @Bean
    @ConditionalOnMissingBean
    public Session session(Cluster cluster) {
        Session session;

        if (!StringUtils.isEmpty(properties.getKeyspace())) {
            session = cluster.connect(properties.getKeyspace());
        } else {
            session = cluster.connect();
        }

        return session;
    }

    /**
     * @param session the session the mapping manager will be associated with
     * @return MappingManager
     */
    @Bean
    @ConditionalOnMissingBean
    public MappingManager mappingManager(Session session) {
        return new MappingManager(session);
    }

    private static <T extends RetryPolicy> RetryPolicy instantiate(Class<T> type) {
        try {
            return (RetryPolicy) type.getDeclaredField("INSTANCE").get(null);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            LOG.error(String.format("Could not instantiate %s with INSTANCE field, "
                            + "you can create a ClusterBuilderCustomizer if you need more control over the retry policy",
                    type.getName()));
            throw new BeanInstantiationException(type, "failed to set RetryPolicy");
        }
    }

    private void customize(Cluster.Builder builder) {
        if (this.builderCustomizers != null) {
            for (ClusterBuilderCustomizer customizer : this.builderCustomizers) {
                customizer.customize(builder);
            }
        }
    }
}
