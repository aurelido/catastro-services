package ie.aib.cassandra.des.auto.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.policies.FallthroughRetryPolicy;
import ie.aib.cassandra.des.auto.config.DseCassandraAutoConfigurationIT.TestApplication;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionIntegrationTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class, properties = {"ie.aib.cassandra.dse.port:9142",
        "ie.aib.cassandra.dse.retry-policy:com.datastax.driver.core.policies.FallthroughRetryPolicy"})
@TestExecutionListeners(listeners = {CassandraUnitDependencyInjectionIntegrationTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class})
@EmbeddedCassandra(timeout = 90000L)
public class DseCassandraAutoConfigurationIT {

    @Autowired
    Cluster cluster;

    @Test
    public void testClusterCreated() {
        assertThat(cluster.connect()).isNotNull();
        assertThat(cluster.getMetadata().getAllHosts()).hasSize(1);
        assertThat(cluster.getConfiguration().getPolicies().getRetryPolicy())
                .isInstanceOf(FallthroughRetryPolicy.class);

        assertThat(cluster.getConfiguration().getPoolingOptions().getMaxRequestsPerConnection(HostDistance.LOCAL))
                .isEqualTo(10);
        assertThat(cluster.getConfiguration().getPoolingOptions().getMaxRequestsPerConnection(HostDistance.REMOTE))
                .isEqualTo(20);
    }

    @SpringBootApplication
    static class TestApplication {

        public static void main(String[] args) {
            SpringApplication.run(TestApplication.class, args);
        }

        @Bean
        public ClusterBuilderCustomizer clusterBuilderCustomizer() {
            return clusterBuilder -> {
                PoolingOptions poolingOptions = clusterBuilder.getConfiguration().getPoolingOptions();
                poolingOptions.setMaxRequestsPerConnection(HostDistance.LOCAL, 10);
                poolingOptions.setMaxRequestsPerConnection(HostDistance.REMOTE, 20);
                clusterBuilder.withPoolingOptions(poolingOptions);
            };
        }
    }
}