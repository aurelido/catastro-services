package ie.aib.cassandra.des.auto.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.datastax.driver.core.policies.DowngradingConsistencyRetryPolicy;
import com.datastax.driver.core.policies.FallthroughRetryPolicy;
import com.datastax.driver.core.policies.LoggingRetryPolicy;
import org.junit.Test;
import org.springframework.beans.BeanInstantiationException;
import org.springframework.beans.factory.ObjectProvider;

public class CassandraDseAutoConfigurationTest {

    @SuppressWarnings("unchecked")
    @Test
    public void testDefaultRetryPolicy() {
        CassandraDseAutoConfiguration cassandraDseAutoConfiguration = new CassandraDseAutoConfiguration(
                new CassandraDseAutoConfigurationProperties(), mock(ObjectProvider.class));

        assertThat(cassandraDseAutoConfiguration.cluster().getConfiguration().getPolicies().getRetryPolicy())
                .isInstanceOf(DowngradingConsistencyRetryPolicy.class);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testSetRetryPolicy() {
        CassandraDseAutoConfigurationProperties configurationProperties = new CassandraDseAutoConfigurationProperties();
        configurationProperties.setRetryPolicy(FallthroughRetryPolicy.class);
        CassandraDseAutoConfiguration cassandraDseAutoConfiguration = new CassandraDseAutoConfiguration(
                configurationProperties, mock(ObjectProvider.class));

        assertThat(cassandraDseAutoConfiguration.cluster().getConfiguration().getPolicies().getRetryPolicy())
                .isInstanceOf(FallthroughRetryPolicy.class);
    }

    @SuppressWarnings("unchecked")
    @Test(expected = BeanInstantiationException.class)
    public void testSetRetryPolicyWithoutInstanceField() {
        CassandraDseAutoConfigurationProperties configurationProperties = new CassandraDseAutoConfigurationProperties();
        configurationProperties.setRetryPolicy(LoggingRetryPolicy.class);
        CassandraDseAutoConfiguration cassandraDseAutoConfiguration = new CassandraDseAutoConfiguration(
                configurationProperties, mock(ObjectProvider.class));

        cassandraDseAutoConfiguration.cluster().getConfiguration().getPolicies().getRetryPolicy();
    }
}