package ie.aib.cassandra.des.auto.config;

import com.datastax.driver.core.Cluster.Builder;

/**
 * @deprecated As of 1.2.11, use {@link ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfiguration}
 * <p>
 * Callback interface that can be implemented by beans wishing to customize the
 * {@link com.datastax.driver.core.Cluster} via a {@link Builder Cluster.Builder} whilst retaining default
 * auto-configuration.
 *
 * This class is a copy of the mechanism used by Spring Data Cassandra
 */
@Deprecated
@SuppressWarnings("DeprecatedIsStillUsed")
public interface ClusterBuilderCustomizer {

    /**
     * Customize the {@link Builder}.
     *
     * @param clusterBuilder the builder to customize
     */
    void customize(Builder clusterBuilder);
}