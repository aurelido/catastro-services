package ie.aib.cassandra.des.auto.config;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.SocketOptions;
import com.datastax.driver.core.policies.DowngradingConsistencyRetryPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

/**
 * @deprecated As of 1.2.11, use {@link ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfiguration}
 */
@Deprecated
@SuppressWarnings("DeprecatedIsStillUsed")
@Validated
@ConfigurationProperties(prefix = "ie.aib.cassandra.dse")
public class CassandraDseAutoConfigurationProperties {

    @NotNull @Size(min = 1) private String contactPoints = "localhost";
    private int port = 9042;
    private String username;
    private String password;
    private boolean ssl;
    private boolean usingDateTimeCodecs = true;

    private String localDc;
    private int usedHostsPerRemoteDc = 1;

    @NotNull private ConsistencyLevel consistencyLevel = ConsistencyLevel.LOCAL_QUORUM;
    private int fetchSize = QueryOptions.DEFAULT_FETCH_SIZE;
    private Integer constantReconnectionMillis;
    private int connectTimeoutMillis = SocketOptions.DEFAULT_CONNECT_TIMEOUT_MILLIS;
    private int readTimeoutMillis = SocketOptions.DEFAULT_READ_TIMEOUT_MILLIS;
    private Class<? extends RetryPolicy> retryPolicy = DowngradingConsistencyRetryPolicy.class;

    private String keyspace;

    public String getContactPoints() {
        return contactPoints;
    }

    public void setContactPoints(String contactPoints) {
        this.contactPoints = contactPoints;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isSsl() {
        return ssl;
    }

    public void setSsl(boolean ssl) {
        this.ssl = ssl;
    }

    public boolean isUsingDateTimeCodecs() {
        return usingDateTimeCodecs;
    }

    public void setUsingDateTimeCodecs(boolean usingDateTimeCodecs) {
        this.usingDateTimeCodecs = usingDateTimeCodecs;
    }

    public String getLocalDc() {
        return localDc;
    }

    public void setLocalDc(String localDc) {
        this.localDc = localDc;
    }

    public int getUsedHostsPerRemoteDc() {
        return usedHostsPerRemoteDc;
    }

    public void setUsedHostsPerRemoteDc(int usedHostsPerRemoteDc) {
        this.usedHostsPerRemoteDc = usedHostsPerRemoteDc;
    }

    public ConsistencyLevel getConsistencyLevel() {
        return consistencyLevel;
    }

    public void setConsistencyLevel(ConsistencyLevel consistencyLevel) {
        this.consistencyLevel = consistencyLevel;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public Integer getConstantReconnectionMillis() {
        return constantReconnectionMillis;
    }

    public void setConstantReconnectionMillis(Integer constantReconnectionMillis) {
        this.constantReconnectionMillis = constantReconnectionMillis;
    }

    public int getConnectTimeoutMillis() {
        return connectTimeoutMillis;
    }

    public void setConnectTimeoutMillis(int connectTimeoutMillis) {
        this.connectTimeoutMillis = connectTimeoutMillis;
    }

    public int getReadTimeoutMillis() {
        return readTimeoutMillis;
    }

    public void setReadTimeoutMillis(int readTimeoutMillis) {
        this.readTimeoutMillis = readTimeoutMillis;
    }

    public String getKeyspace() {
        return keyspace;
    }

    public void setKeyspace(String keyspace) {
        this.keyspace = keyspace;
    }

    public Class<? extends RetryPolicy> getRetryPolicy() {
        return retryPolicy;
    }

    public void setRetryPolicy(Class<? extends RetryPolicy> retryPolicy) {
        this.retryPolicy = retryPolicy;
    }
}
