package ie.aib.msf.cassandra.auto.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.util.ReflectionTestUtils.getField;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.policies.DefaultRetryPolicy;
import com.datastax.driver.core.policies.LoggingRetryPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import com.datastax.driver.mapping.MappingManager;
import ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfigurationIT.TestApplication;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionIntegrationTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

@EmbeddedCassandra(timeout = 90000L)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class, properties = {
        "spring.data.cassandra.customizer.dc-aware-round-robin-policy.local-dc:TEST_LOCAL_DC",
        "spring.data.cassandra.customizer.specific-consistency-retry-policy.retry-consistency-level:ONE",
})
@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
@TestExecutionListeners(listeners = {CassandraUnitDependencyInjectionIntegrationTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class})
public class SupplementalCassandraAutoConfigurationIT {

    @Autowired
    Cluster cluster;

    @Autowired
    Session session;

    @Autowired
    MappingManager mappingManager;

    @Test
    public void testClusterCreatedWithDefaultConfiguration() {
        assertThat(cluster).isNotNull();
        assertThat(session).isNotNull();
        assertThat(mappingManager).isNotNull();

        assertThat(cluster.connect()).isNotNull();
        assertThat(cluster.getMetadata().getAllHosts()).hasSize(1);
        assertThat(cluster.getConfiguration().getPolicies().getRetryPolicy())
                .isInstanceOf(LoggingRetryPolicy.class);

        LoggingRetryPolicy loggingRetryPolicy =
                (LoggingRetryPolicy) cluster.getConfiguration().getPolicies().getRetryPolicy();

        assertThat((RetryPolicy) getField(loggingRetryPolicy, "policy"))
                .isInstanceOf(DefaultRetryPolicy.class);
    }

    @SpringBootApplication
    static class TestApplication {

        public static void main(String[] args) {
            SpringApplication.run(TestApplication.class, args);
        }
    }
}
