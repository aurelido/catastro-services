package ie.aib.msf.cassandra.auto.config;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.MappingManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
import org.springframework.boot.autoconfigure.cassandra.CassandraProperties;
import org.springframework.boot.autoconfigure.cassandra.ClusterBuilderCustomizer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

/**
 * This class builds upon the {@link CassandraAutoConfiguration} for Cassandra.
 * <p>
 * {@link CassandraAutoConfiguration} only exposes a {@link CassandraProperties subset} of {@link Cluster} properties so
 * {@link CassandraCustomizer} is registered as a {@link ClusterBuilderCustomizer} to permit advanced configuration of
 * connection pooling, load balancing, retry policy options, etc.
 *
 * @see CassandraCustomizer
 * @see ClusterBuilderCustomizer
 */
@Configuration
@ConditionalOnClass(Cluster.class)
@EnableConfigurationProperties({CassandraProperties.class, CassandraCustomizerProperties.class})
@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
public class SupplementalCassandraAutoConfiguration {

    private final CassandraProperties cassandraProperties;
    private final CassandraCustomizerProperties cassandraCustomizerProperties;

    @Autowired
    public SupplementalCassandraAutoConfiguration(
            CassandraProperties cassandraProperties,
            CassandraCustomizerProperties cassandraCustomizerProperties) {
        this.cassandraProperties = cassandraProperties;
        this.cassandraCustomizerProperties = cassandraCustomizerProperties;
    }

    /**
     * @param cluster the cluster to connect to
     * @return Session
     */
    @Bean
    @ConditionalOnMissingBean
    public Session session(Cluster cluster) {
        if (StringUtils.isEmpty(cassandraProperties.getKeyspaceName())) {
            return cluster.connect();
        } else {
            return cluster.connect(cassandraProperties.getKeyspaceName());
        }
    }

    /**
     * @param session the session the mapping manager will be associated with
     *
     * @return MappingManager
     */
    @Bean
    @ConditionalOnMissingBean
    public MappingManager mappingManager(Session session) {
        return new MappingManager(session);
    }

    /**
     * Customize the Cassandra {@link Cluster} based on {@link CassandraCustomizerProperties}
     *
     * @return ClusterBuilderCustomizer
     *
     * @see ClusterBuilderCustomizer
     */
    @Bean
    public ClusterBuilderCustomizer cassandraCustomizer() {
        return new CassandraCustomizer(cassandraCustomizerProperties);
    }
}
