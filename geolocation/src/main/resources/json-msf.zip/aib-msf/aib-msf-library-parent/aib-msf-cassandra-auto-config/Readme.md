## aib-msf-cassandra-auto-config



Will automatically configure the following beans (if not explicitly provided) when `com.datastax.driver.core.Cluster` is found on the classpath:


* `com.datastax.driver.core.Cluster`
* `com.datastax.driver.core.Session`
* `com.datastax.driver.mapping.MappingManager`

***

### Standard Spring Data Cassandra Properties

Property | Default Value
--- | ---
`spring.data.cassandra.keyspaceName` | (no default value)
`spring.data.cassandra.contactPoints` | localhost
`spring.data.cassandra.port` | 9042
`spring.data.cassandra.username` | (no default value, **required property**)
`spring.data.cassandra.password` | (no default value, **required property**)
`spring.data.cassandra.ssl` | false
`spring.data.cassandra.consistencyLevel` | ConsistencyLevel.LOCAL_QUORUM
`spring.data.cassandra.fetchSize` | QueryOptions.DEFAULT_FETCH_SIZE (5000)
`spring.data.cassandra.connectTimeoutMillis` | SocketOptions.DEFAULT_CONNECT_TIMEOUT_MILLIS (5000 milliseconds)
`spring.data.cassandra.readTimeoutMillis` | SocketOptions.DEFAULT_READ_TIMEOUT_MILLIS (12000 milliseconds)

***

### Additional Spring Data Cassandra Customizer Properties

1. **Register Date And Time Codecs** (enabled by default)
2. **DC Aware Round Robin Policy** (enabled by default, `localDc` is required when enabled)
3. **Exponential Reconnection Policy** (enabled by default)
4. **Pooling Options** (enabled by default)
5. **Specific Consistency Retry Policy** (**not enabled** by default, `retryConsistencyLevel` is required when enabled)

>
>
> **Note:** When **Specific Consistency Retry Policy** is enabled, `retryConsistencyLevel` must be specified and will be applied to both **READS AND WRITES**.
>
> For both `onUnavailable` and `onRequestError` there is no indication that the failing `Statement` is a READ or WRITE operation.
>
>


Property | Default Value
-------------------------------------------------- | --------------------------------------------------
**Register Date And Time Codecs** |
`spring.data.cassandra.customizer.registerDateAndTimeCodecs` | true (when true will register: InstantCodec.instance, SimpleTimestampCodec, SimpleDateCodec)
**DC Aware Round Robin Policy** |
`spring.data.cassandra.customizer.dcAwareRoundRobinPolicy.enabled` | true
`spring.data.cassandra.customizer.dcAwareRoundRobinPolicy.allowRemoteDcForLocalConsistencyLevel` | true
`spring.data.cassandra.customizer.dcAwareRoundRobinPolicy.localDc` | (no default value, **required property** when enabled)
`spring.data.cassandra.customizer.dcAwareRoundRobinPolicy.usedHostsPerRemoteDc` | 1
**Exponential Reconnection Policy** |
`spring.data.cassandra.customizer.exponentialReconnectionPolicy.enabled` | true
`spring.data.cassandra.customizer.exponentialReconnectionPolicy.baseDelayMs` | DEFAULT_BASE_DELAY_MS (1000)
`spring.data.cassandra.customizer.exponentialReconnectionPolicy.maxDelayMs` | DEFAULT_MAX_DELAY_MS (600000)
**Pooling Options** |
`spring.data.cassandra.customizer.poolingOptions.enabled` | true
`spring.data.cassandra.customizer.poolingOptions.heartbeatIntervalSeconds` | PoolingOptions.DEFAULT_HEARTBEAT_INTERVAL_SECONDS (30)
`spring.data.cassandra.customizer.poolingOptions.idleTimeoutSeconds` | PoolingOptions.DEFAULT_IDLE_TIMEOUT_SECONDS (120)
`spring.data.cassandra.customizer.poolingOptions.local.coreConnectionsPerHost` | DEFAULT_CORE_CONNECTIONS_PER_HOST (2)
`spring.data.cassandra.customizer.poolingOptions.local.maxConnectionsPerHost` | DEFAULT_MAX_CONNECTIONS_PER_HOST (14)
`spring.data.cassandra.customizer.poolingOptions.remote.coreConnectionsPerHost` | DEFAULT_CORE_CONNECTIONS_PER_HOST (2)
`spring.data.cassandra.customizer.poolingOptions.remote.maxConnectionsPerHost` | DEFAULT_MAX_CONNECTIONS_PER_HOST (14)
**Specific Consistency Retry Policy** (enabled by default: **false**)|
`spring.data.cassandra.customizer.specificConsistencyRetryPolicy.enabled` | false
`spring.data.cassandra.customizer.specificConsistencyRetryPolicy.maxRetryAttempts` | SpecificConsistencyRetryPolicy.DEFAULT_MAX_RETRIES (3)
`spring.data.cassandra.customizer.specificConsistencyRetryPolicy.retryConsistencyLevel` | (no default value, **required property** when enabled)

