package ie.aib.msf.cassandra.auto.config;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;
import com.datastax.driver.core.policies.ExponentialReconnectionPolicy;
import com.datastax.driver.core.policies.LoadBalancingPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import com.datastax.driver.core.policies.TokenAwarePolicy;
import com.datastax.driver.extras.codecs.date.SimpleDateCodec;
import com.datastax.driver.extras.codecs.date.SimpleTimestampCodec;
import com.datastax.driver.extras.codecs.jdk8.InstantCodec;
import ie.aib.msf.cassandra.auto.config.CassandraCustomizerProperties.PoolingOptionsProperties.Local;
import ie.aib.msf.cassandra.auto.config.CassandraCustomizerProperties.PoolingOptionsProperties.Remote;
import ie.aib.msf.cassandra.auto.config.policies.LoggingRetryPolicyAsWarning;
import ie.aib.msf.cassandra.auto.config.policies.SpecificConsistencyRetryPolicy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.autoconfigure.cassandra.ClusterBuilderCustomizer;
import org.springframework.util.StringUtils;

/**
 * Customize the Cassandra {@link Cluster} based on {@link CassandraCustomizerProperties}
 *
 * @see ClusterBuilderCustomizer
 */
public class CassandraCustomizer implements ClusterBuilderCustomizer {

    private static final Log LOG = LogFactory.getLog(CassandraCustomizer.class);

    private final CassandraCustomizerProperties properties;

    CassandraCustomizer(CassandraCustomizerProperties properties) {
        this.properties = properties;
    }

    @Override
    public void customize(Builder clusterBuilder) {
        registerCodecs(clusterBuilder);
        withLoadBalancingPolicy(clusterBuilder);
        withPoolingOptions(clusterBuilder);
        withReconnectionPolicy(clusterBuilder);
        withRetryPolicy(clusterBuilder);
    }

    private void registerCodecs(Builder clusterBuilder) {
        if (properties.isRegisterDateAndTimeCodecs()) {
            clusterBuilder.getConfiguration().getCodecRegistry()
                    .register(InstantCodec.instance, new SimpleTimestampCodec(), new SimpleDateCodec());
        }

        LOG.debug("registerCodecs");
    }

    private void withLoadBalancingPolicy(Builder clusterBuilder) {
        if (properties.getDcAwareRoundRobinPolicy().isEnabled()) {
            String localDc = properties.getDcAwareRoundRobinPolicy().getLocalDc();

            if (StringUtils.isEmpty(localDc)) {
                throw new IllegalArgumentException("invalid property - "
                        + "localDc can't be null or empty "
                        + "when customizer.getDcAwareRoundRobinPolicy is enabled");
            }

            DCAwareRoundRobinPolicy.Builder builder = DCAwareRoundRobinPolicy.builder();
            if (properties.getDcAwareRoundRobinPolicy().isAllowRemoteDcForLocalConsistencyLevel()) {
                builder.allowRemoteDCsForLocalConsistencyLevel();
            }

            LoadBalancingPolicy childPolicy = builder
                    .withLocalDc(localDc)
                    .withUsedHostsPerRemoteDc(properties.getDcAwareRoundRobinPolicy().getUsedHostsPerRemoteDc())
                    .build();
            LoadBalancingPolicy parentPolicy = new TokenAwarePolicy(childPolicy, true);

            clusterBuilder.withLoadBalancingPolicy(parentPolicy);

            LOG.debug(String.format("withLoadBalancingPolicy %s", parentPolicy.toString()));
        }
    }

    private void withPoolingOptions(Builder clusterBuilder) {
        if (properties.getPoolingOptions().isEnabled()) {
            PoolingOptions poolingOptions = new PoolingOptions();

            poolingOptions.setHeartbeatIntervalSeconds(properties.getPoolingOptions().getHeartbeatIntervalSeconds());
            poolingOptions.setIdleTimeoutSeconds(properties.getPoolingOptions().getIdleTimeoutSeconds());

            Local localProperties = properties.getPoolingOptions().getLocal();
            poolingOptions.setCoreConnectionsPerHost(HostDistance.LOCAL, localProperties.getCoreConnectionsPerHost());
            poolingOptions.setMaxConnectionsPerHost(HostDistance.LOCAL, localProperties.getMaxConnectionsPerHost());

            Remote remoteProperties = properties.getPoolingOptions().getRemote();
            poolingOptions.setCoreConnectionsPerHost(HostDistance.REMOTE, remoteProperties.getCoreConnectionsPerHost());
            poolingOptions.setMaxConnectionsPerHost(HostDistance.REMOTE, remoteProperties.getMaxConnectionsPerHost());

            clusterBuilder.withPoolingOptions(poolingOptions);

            LOG.debug(String.format("withPoolingOptions %s", poolingOptions.toString()));
        }
    }

    private void withReconnectionPolicy(Builder clusterBuilder) {
        if (properties.getExponentialReconnectionPolicy().isEnabled()) {
            ExponentialReconnectionPolicy reconnectionPolicy = new ExponentialReconnectionPolicy(
                    properties.getExponentialReconnectionPolicy().getBaseDelayMs(),
                    properties.getExponentialReconnectionPolicy().getMaxDelayMs());

            clusterBuilder.withReconnectionPolicy(reconnectionPolicy);

            LOG.debug(String.format("withReconnectionPolicy %s", reconnectionPolicy.toString()));
        }
    }

    private void withRetryPolicy(Builder clusterBuilder) {
        if (properties.getSpecificConsistencyRetryPolicy().isEnabled()) {
            ConsistencyLevel retryConsistencyLevel =
                    properties.getSpecificConsistencyRetryPolicy().getRetryConsistencyLevel();

            if (retryConsistencyLevel == null) {
                throw new IllegalArgumentException("invalid property - "
                        + "retryConsistencyLevel can't be null "
                        + "when customizer.getSpecificConsistencyRetryPolicy is enabled");
            }

            SpecificConsistencyRetryPolicy retryPolicy = new SpecificConsistencyRetryPolicy(
                    properties.getSpecificConsistencyRetryPolicy().getRetryConsistencyLevel(),
                    properties.getSpecificConsistencyRetryPolicy().getMaxRetryAttempts());
            clusterBuilder.withRetryPolicy(retryPolicy);

            LOG.warn("SpecificConsistencyRetryPolicy has been configured for " + retryConsistencyLevel
                    + " which will be applied to retries for both READS AND WRITES");

            LOG.debug(String.format("withRetryPolicy %s", retryPolicy.toString()));
        }

        // ensure the RetryPolicy is wrapped in a LoggingRetryPolicyAsWarning

        RetryPolicy retryPolicy = clusterBuilder.getConfiguration().getPolicies().getRetryPolicy();
        if (retryPolicy != null && !(retryPolicy instanceof LoggingRetryPolicyAsWarning)) {
            LoggingRetryPolicyAsWarning loggingRetryPolicyAsWarning = new LoggingRetryPolicyAsWarning(retryPolicy);

            clusterBuilder.withRetryPolicy(loggingRetryPolicyAsWarning);

            LOG.debug(String.format("withLoggingRetryPolicy %s", loggingRetryPolicyAsWarning.toString()));
        }
    }
}
