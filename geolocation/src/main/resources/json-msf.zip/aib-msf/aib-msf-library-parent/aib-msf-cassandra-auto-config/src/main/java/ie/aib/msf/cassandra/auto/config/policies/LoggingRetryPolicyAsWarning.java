package ie.aib.msf.cassandra.auto.config.policies;

import com.datastax.driver.core.policies.LoggingRetryPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingRetryPolicyAsWarning extends LoggingRetryPolicy {

    private static final Logger logger = LoggerFactory.getLogger(LoggingRetryPolicyAsWarning.class);

    public LoggingRetryPolicyAsWarning(RetryPolicy policy) {
        super(policy);
    }

    @Override
    protected void logDecision(String template, Object... parameters) {
        logger.warn(template, parameters);
    }
}
