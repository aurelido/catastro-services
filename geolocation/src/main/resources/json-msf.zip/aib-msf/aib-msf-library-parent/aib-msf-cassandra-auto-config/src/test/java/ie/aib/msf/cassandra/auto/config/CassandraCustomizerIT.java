package ie.aib.msf.cassandra.auto.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.util.ReflectionTestUtils.getField;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;
import com.datastax.driver.core.policies.ExponentialReconnectionPolicy;
import com.datastax.driver.core.policies.LoggingRetryPolicy;
import com.datastax.driver.core.policies.RetryPolicy;
import com.datastax.driver.core.policies.TokenAwarePolicy;
import ie.aib.msf.cassandra.auto.config.CassandraCustomizerIT.TestApplication;
import ie.aib.msf.cassandra.auto.config.policies.SpecificConsistencyRetryPolicy;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionIntegrationTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

@EmbeddedCassandra(timeout = 90000L)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class, properties = {
        "spring.data.cassandra.customizer.dc-aware-round-robin-policy.allow-remote-dc-for-local-consistency-level:true",
        "spring.data.cassandra.customizer.dc-aware-round-robin-policy.local-dc:TEST_LOCAL_DC",
        "spring.data.cassandra.customizer.dc-aware-round-robin-policy.used-hosts-per-remote-dc:2",
        "spring.data.cassandra.customizer.exponential-reconnection-policy.base-delay-ms:100",
        "spring.data.cassandra.customizer.exponential-reconnection-policy.max-delay-ms:200",
        "spring.data.cassandra.customizer.pooling-options.heartbeat-interval-seconds:100",
        "spring.data.cassandra.customizer.pooling-options.idle-timeout-seconds:200",
        "spring.data.cassandra.customizer.specific-consistency-retry-policy.enabled:true",
        "spring.data.cassandra.customizer.specific-consistency-retry-policy.retry-consistency-level:TWO",
        "spring.data.cassandra.customizer.specific-consistency-retry-policy.max-retry-attempts:2",
})
@SuppressWarnings({"SpringJavaInjectionPointsAutowiringInspection"})
@TestExecutionListeners(listeners = {CassandraUnitDependencyInjectionIntegrationTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class})
public class CassandraCustomizerIT {

    @Autowired
    Cluster cluster;

    @Autowired
    CassandraCustomizerProperties properties;

    @Test
    public void testClusterCreatedWithDefaultConfiguration() {
        assertThat(cluster).isNotNull();

        // dc-aware-round-robin-policy

        assertThat(cluster.getConfiguration().getPolicies().getLoadBalancingPolicy())
                .isInstanceOf(TokenAwarePolicy.class);
        TokenAwarePolicy tokenAwarePolicy =
                (TokenAwarePolicy) cluster.getConfiguration().getPolicies().getLoadBalancingPolicy();
        assertThat(tokenAwarePolicy.getChildPolicy())
                .isInstanceOf(DCAwareRoundRobinPolicy.class);
        DCAwareRoundRobinPolicy dcAwareRoundRobinPolicy = (DCAwareRoundRobinPolicy) tokenAwarePolicy.getChildPolicy();

        boolean allowRemoteDcForLocalConsistencyLevel = /* the reverse of dontHopForLocalCL */
                !(boolean) getField(dcAwareRoundRobinPolicy, "dontHopForLocalCL");

        assertThat(properties.getDcAwareRoundRobinPolicy().isAllowRemoteDcForLocalConsistencyLevel())
                .isEqualTo(allowRemoteDcForLocalConsistencyLevel);
        assertThat(properties.getDcAwareRoundRobinPolicy().getLocalDc())
                .isEqualTo((String) getField(dcAwareRoundRobinPolicy, "localDc"));
        assertThat(properties.getDcAwareRoundRobinPolicy().getUsedHostsPerRemoteDc())
                .isEqualTo((int) getField(dcAwareRoundRobinPolicy, "usedHostsPerRemoteDc"));

        // exponential-reconnection-policy

        assertThat(cluster.getConfiguration().getPolicies().getReconnectionPolicy())
                .isInstanceOf(ExponentialReconnectionPolicy.class);
        ExponentialReconnectionPolicy exponentialReconnectionPolicy
                = (ExponentialReconnectionPolicy) cluster.getConfiguration().getPolicies().getReconnectionPolicy();
        assertThat(exponentialReconnectionPolicy.getBaseDelayMs())
                .isEqualTo(properties.getExponentialReconnectionPolicy().getBaseDelayMs());
        assertThat(exponentialReconnectionPolicy.getMaxDelayMs())
                .isEqualTo(properties.getExponentialReconnectionPolicy().getMaxDelayMs());

        // pooling-options

        PoolingOptions poolingOptions = cluster.getConfiguration().getPoolingOptions();
        assertThat(poolingOptions).isNotNull();
        assertThat(poolingOptions.getHeartbeatIntervalSeconds())
                .isEqualTo(properties.getPoolingOptions().getHeartbeatIntervalSeconds());
        assertThat(poolingOptions.getIdleTimeoutSeconds())
                .isEqualTo(properties.getPoolingOptions().getIdleTimeoutSeconds());

        // specific-consistency-retry-policy

        assertThat(cluster.getConfiguration().getPolicies().getRetryPolicy())
                .isInstanceOf(LoggingRetryPolicy.class);
        LoggingRetryPolicy loggingRetryPolicy =
                (LoggingRetryPolicy) cluster.getConfiguration().getPolicies().getRetryPolicy();

        RetryPolicy retryPolicy = (RetryPolicy) getField(loggingRetryPolicy, "policy");

        assertThat(retryPolicy)
                .isInstanceOf(SpecificConsistencyRetryPolicy.class);

        SpecificConsistencyRetryPolicy specificConsistencyRetryPolicy = (SpecificConsistencyRetryPolicy) retryPolicy;

        assertThat(properties.getSpecificConsistencyRetryPolicy().getRetryConsistencyLevel())
                .isEqualTo((ConsistencyLevel) getField(specificConsistencyRetryPolicy, "specificConsistencyLevel"));
        assertThat(properties.getSpecificConsistencyRetryPolicy().getMaxRetryAttempts())
                .isEqualTo((int) getField(specificConsistencyRetryPolicy, "maxRetryAttempts"));
    }

    @SpringBootApplication
    static class TestApplication {

        public static void main(String[] args) {
            SpringApplication.run(SupplementalCassandraAutoConfigurationIT.TestApplication.class, args);
        }
    }
}
