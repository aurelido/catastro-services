package ie.aib.msf.cassandra.auto.config;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PoolingOptions;
import ie.aib.msf.cassandra.auto.config.policies.SpecificConsistencyRetryPolicy;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties used to customize the Cassandra {@link Cluster} in {@link CassandraCustomizer}
 */
@ConfigurationProperties(prefix = "spring.data.cassandra.customizer")
@Getter
@Setter
@SuppressWarnings("WeakerAccess")
class CassandraCustomizerProperties {

    private boolean registerDateAndTimeCodecs = true;

    private DCAwareRoundRobinPolicyProperties dcAwareRoundRobinPolicy = new DCAwareRoundRobinPolicyProperties();
    private ExponentialReconnectionPolicyProperties exponentialReconnectionPolicy = new ExponentialReconnectionPolicyProperties();
    private PoolingOptionsProperties poolingOptions = new PoolingOptionsProperties();
    private SpecificConsistencyRetryPolicyProperties specificConsistencyRetryPolicy = new SpecificConsistencyRetryPolicyProperties();

    @Getter
    @Setter
    public static class DCAwareRoundRobinPolicyProperties {

        private boolean enabled = true;
        private boolean allowRemoteDcForLocalConsistencyLevel = true;
        private String localDc;
        private int usedHostsPerRemoteDc = 1;
    }

    @Getter
    @Setter
    public static class ExponentialReconnectionPolicyProperties {

        /**
         * @see com.datastax.driver.core.policies.Policies Policies.DEFAULT_RECONNECTION_POLICY
         */
        public static final long DEFAULT_BASE_DELAY_MS = 1000;

        /**
         * @see com.datastax.driver.core.policies.Policies Policies.DEFAULT_RECONNECTION_POLICY
         */
        public static final long DEFAULT_MAX_DELAY_MS = 10 * 60 * 1000;

        private boolean enabled = true;
        private long baseDelayMs = DEFAULT_BASE_DELAY_MS;
        private long maxDelayMs = DEFAULT_MAX_DELAY_MS;
    }

    @Getter
    @Setter
    public static class PoolingOptionsProperties {

        public static final int DEFAULT_CORE_CONNECTIONS_PER_HOST = 2;
        public static final int DEFAULT_MAX_CONNECTIONS_PER_HOST = 14;

        @Getter
        @Setter
        public static class Local {

            private int coreConnectionsPerHost = DEFAULT_CORE_CONNECTIONS_PER_HOST;
            private int maxConnectionsPerHost = DEFAULT_MAX_CONNECTIONS_PER_HOST;
        }

        @Getter
        @Setter
        public static class Remote {

            private int coreConnectionsPerHost = DEFAULT_CORE_CONNECTIONS_PER_HOST;
            private int maxConnectionsPerHost = DEFAULT_MAX_CONNECTIONS_PER_HOST;
        }

        private boolean enabled = true;
        private int idleTimeoutSeconds = PoolingOptions.DEFAULT_IDLE_TIMEOUT_SECONDS;
        private int heartbeatIntervalSeconds = PoolingOptions.DEFAULT_HEARTBEAT_INTERVAL_SECONDS;

        private Local local = new Local();
        private Remote remote = new Remote();
    }

    @Getter
    @Setter
    public static class SpecificConsistencyRetryPolicyProperties {

        private boolean enabled = false;
        private ConsistencyLevel retryConsistencyLevel;
        private int maxRetryAttempts = SpecificConsistencyRetryPolicy.DEFAULT_MAX_RETRY_ATTEMPTS;
    }
}