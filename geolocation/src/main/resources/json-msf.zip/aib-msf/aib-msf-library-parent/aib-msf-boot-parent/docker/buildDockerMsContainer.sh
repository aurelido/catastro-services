#!/bin/bash

export DOCKERIZE_VERSION=v0.2.0
export https_proxy=http://192.168.99.1:3128

curl -L --insecure -O https://github.com/jwilder/dockerize/releases/download/$DOCKERIZE_VERSION/dockerize-linux-amd64-$DOCKERIZE_VERSION.tar.gz \
    && tar -C . -xzvf dockerize-linux-amd64-$DOCKERIZE_VERSION.tar.gz

docker build -t aib-docker-ms-container .

docker tag aib-docker-ms-container:latest rhethomt2.mid.aib.pri:18444/infra/aib-docker-ms-container

docker push rhethomt2.mid.aib.pri:18444/infra/aib-docker-ms-container

docker pull rhethomt2.mid.aib.pri:18444/infra/aib-docker-ms-container

rm -f dockerize*
