#!/bin/sh

touch -m /${1}.jar

java -Djava.security.egd=file:/dev/./urandom -jar /${1}.jar
