package ie.aib.msf.spring.data.cassandra;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy.Builder;
import com.datastax.driver.core.policies.LoadBalancingPolicy;
import com.datastax.driver.core.policies.TokenAwarePolicy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.cassandra.ClusterBuilderCustomizer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @deprecated As of 1.2.11, use {@link ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfiguration}
 * <p>
 * Provides auto-configuration for Spring Data Cassandra Cluster builder customizers
 */
@Deprecated
@SuppressWarnings("DeprecatedIsStillUsed")
@Configuration
@ConditionalOnClass(Cluster.class)
@EnableConfigurationProperties(SpringDataCassandraCustomizerProperties.class)
public class SpringDataCassandraCustomizerAutoConfiguration {

    private static final Log LOG = LogFactory.getLog(SpringDataCassandraCustomizerAutoConfiguration.class);

    private final SpringDataCassandraCustomizerProperties properties;

    @Autowired
    SpringDataCassandraCustomizerAutoConfiguration(SpringDataCassandraCustomizerProperties properties) {
        this.properties = properties;

        LOG.warn("SpringDataCassandraCustomizerAutoConfiguration has been deprecated and will be REMOVED from a future release.  Please move to SupplementalCassandraAutoConfiguration (aib-msf-cassandra-auto-config)");
    }

    /**
     * Create a Customizer bean to set the DC Aware load balancing policy
     */
    @Bean
    @ConditionalOnProperty(value = "spring.data.cassandra.customizer.dcAwareLoadBalancingPolicy.enabled", havingValue = "true")
    ClusterBuilderCustomizer dcAwareLoadBalancingPolicyClusterBuilderCustomizer() {
        Builder builder = DCAwareRoundRobinPolicy.builder();
        if (properties.getDcAwareLoadBalancingPolicy().isAllowRemoteDCsForLocalConsistencyLevel()) {
            builder.allowRemoteDCsForLocalConsistencyLevel();
        }

        LoadBalancingPolicy childPolicy = builder.withLocalDc(properties.getDcAwareLoadBalancingPolicy().getLocalDc())
                .withUsedHostsPerRemoteDc(properties.getDcAwareLoadBalancingPolicy().getUsedHostsPerRemoteDc())
                .build();
        LoadBalancingPolicy parentPolicy = new TokenAwarePolicy(childPolicy, true);

        return clusterBuilder -> clusterBuilder.withLoadBalancingPolicy(parentPolicy);
    }
}