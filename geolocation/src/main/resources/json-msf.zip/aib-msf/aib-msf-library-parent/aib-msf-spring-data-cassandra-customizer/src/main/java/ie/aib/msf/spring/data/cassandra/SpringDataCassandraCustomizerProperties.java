package ie.aib.msf.spring.data.cassandra;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @deprecated As of 1.2.11, use {@link ie.aib.msf.cassandra.auto.config.SupplementalCassandraAutoConfiguration}
 * <p>
 * Configuration properties for customizing Spring Data's Cassandra configuration
 * <p>
 * Spring Data only exposes a subset of Cluster properties, so a customizer is required to set things like the load
 * balancing policy options.
 */
@Deprecated
@SuppressWarnings("DeprecatedIsStillUsed")
@ConfigurationProperties(prefix = "spring.data.cassandra.customizer")
@Getter
@Setter
class SpringDataCassandraCustomizerProperties {

    private DCAwareLoadBalancingPolicy dcAwareLoadBalancingPolicy;

    /**
     * DCAware load balancing policy configuration.
     * <p/>
     * It's possible more cluster customization will be needed later, so these properties are being namespaced
     * together.
     */
    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    public static class DCAwareLoadBalancingPolicy {

        private boolean enabled = true;
        private boolean allowRemoteDCsForLocalConsistencyLevel = true;
        private String localDc;
        private int usedHostsPerRemoteDc;
    }
}