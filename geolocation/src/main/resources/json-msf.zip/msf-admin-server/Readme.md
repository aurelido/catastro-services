## Spring Boot Admin Server

[Spring Boot Admin Server](https://github.com/codecentric/spring-boot-admin), configured with service discovery via Eureka.

Contains plugins for UI, Hystrix and Turbine

[Documentation](http://codecentric.github.io/spring-boot-admin/1.4.4/#getting-started)

### Bootstrap Properties

Property | Default Value
--- | --- 
`MSF_CONFIG_SERVER_SERVICE_ID` | msf-config-server
`MSF_DISCOVERY_HOST` | http://localhost
`MSF_DISCOVERY_PORT` | 8761

### Notable Application Properties (via Configuration Server)

Property | Profile | Default Value
--- | --- | ---
`server.port` | default | 9000
`spring.application.name` | default | msf-admin-server
`SSL_KEY_STORE` | https | /opt/ssl/keystore.jks
`SSL_KEY_STORE_PASSWORD` | https | (no default vaue, required property)

### LDAP Password Protection

[LDAP security module](https://wiki.aib.pri/display/MSF/LDAP+Support+Module) is included and con be configured to control access via LDAP
