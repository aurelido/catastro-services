package ie.aib.msf.admin.server;

import static org.assertj.core.api.Assertions.assertThat;

import com.icegreen.greenmail.junit.GreenMailRule;
import com.icegreen.greenmail.util.ServerSetupTest;
import de.codecentric.boot.admin.event.ClientApplicationStatusChangedEvent;
import de.codecentric.boot.admin.model.Application;
import de.codecentric.boot.admin.model.StatusInfo;
import java.time.Duration;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,
        properties = {"spring.admin.hazelcast.enabled=false", "spring.boot.admin.notify.delay=1"})
public class DelayedMailNotifierIT {

    @Autowired
    private ApplicationEventPublisher publisher;

    @Rule
    public final GreenMailRule greenMail = new GreenMailRule((ServerSetupTest.SMTP));

    @Test
    public void testApplicationDownEvent() {
        publisher.publishEvent(
                new ClientApplicationStatusChangedEvent(
                        Application.create("test").withHealthUrl("http://demo.com/health").withId("123")
                                .withStatusInfo(StatusInfo.ofDown()).build(),
                        StatusInfo.ofUp(),
                        StatusInfo.ofDown()));

        assertThat(greenMail.getReceivedMessages()).hasSize(0);
        greenMail.waitForIncomingEmail(Duration.ofMinutes(2L).toMillis(), 1);
        assertThat(greenMail.getReceivedMessages()).hasSize(1);
    }

}
