package ie.aib.msf.admin.server.notification;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;

import de.codecentric.boot.admin.event.ClientApplicationEvent;
import de.codecentric.boot.admin.event.ClientApplicationStatusChangedEvent;
import de.codecentric.boot.admin.model.Application;
import de.codecentric.boot.admin.model.StatusInfo;
import de.codecentric.boot.admin.notify.Notifier;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;

public class DelayingNotifierTest {

    private static final String APPLICATION_NAME = "testApp";
    private static final String APPLICATION_ID = "12345";
    private Notifier delegate = mock(Notifier.class);
    private DelayingNotifier notifier;
    private NotificationDelayConfigurationProperties properties;

    @Before
    public void setup() {
        properties = new NotificationDelayConfigurationProperties();
        properties.setPeriodInMinutes(5L);
        notifier = new DelayingNotifier(delegate, new DelayedNotificationEventStore(new HashMap<>()), properties);
    }

    @Test
    public void testSendingDownNotification() {
        ClientApplicationEvent event = createApplicationEvent(StatusInfo.ofUp(), StatusInfo.ofDown());
        notifier.doNotify(event);

        notifier.sendDelayedNotifications();

        //period, no notification sent yet
        verifyZeroInteractions(delegate);

        //reduce period to 0 seconds
        properties.setPeriodInMinutes(0L);

        //notification should now be sent
        notifier.sendDelayedNotifications();
        verify(delegate).notify(event);

        //notification should have been cleared and not sent on the next poll
        notifier.sendDelayedNotifications();
        verifyNoMoreInteractions(delegate);
    }

    @Test
    public void testNotificationCancelled() {
        ClientApplicationEvent downEvent = createApplicationEvent(StatusInfo.ofUp(), StatusInfo.ofDown());
        notifier.doNotify(downEvent);

        notifier.sendDelayedNotifications();

        //period, no notification sent yet
        verifyZeroInteractions(delegate);

        ClientApplicationEvent upEvent = createApplicationEvent(StatusInfo.ofDown(), StatusInfo.ofUp());
        notifier.doNotify(upEvent);
        //reduce period to 0 seconds
        properties.setPeriodInMinutes(0L);

        //notification should not be sent because it was cancelled up up event
        notifier.sendDelayedNotifications();
        verifyZeroInteractions(delegate);
    }

    private Application createApplication(StatusInfo status) {
        return Application.create(APPLICATION_NAME).withId(APPLICATION_ID)
                .withHealthUrl("/health").withStatusInfo(status).build();
    }

    private ClientApplicationEvent createApplicationEvent(StatusInfo from, StatusInfo to) {
        return new ClientApplicationStatusChangedEvent(createApplication(to), from, to);
    }
}