package ie.aib.msf.admin.server.notification;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@ConditionalOnBean(DelayingNotifier.class)
public class NotifierSchedulerConfiguration {

    private final DelayingNotifier delayingNotifier;

    public NotifierSchedulerConfiguration(DelayingNotifier delayingNotifier) {
        this.delayingNotifier = delayingNotifier;
    }

    //check if delayed notifications need to be sent once per minute
    @Scheduled(fixedRate = 60_000L)
    public void sendDelayedNotifications() {
        delayingNotifier.sendDelayedNotifications();
    }
}