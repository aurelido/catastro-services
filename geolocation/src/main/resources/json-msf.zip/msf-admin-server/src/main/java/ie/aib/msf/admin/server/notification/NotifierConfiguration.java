package ie.aib.msf.admin.server.notification;

import de.codecentric.boot.admin.notify.AbstractStatusChangeNotifier;
import de.codecentric.boot.admin.notify.LoggingNotifier;
import de.codecentric.boot.admin.notify.Notifier;
import de.codecentric.boot.admin.notify.filter.FilteringNotifier;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan(basePackageClasses = NotificationDelayConfigurationProperties.class)
public class NotifierConfiguration {

    @Bean
    @Primary
    public FilteringNotifier filteringNotifier(DelayingNotifier delayingNotifier) {
        return new FilteringNotifier(delayingNotifier);
    }

    @Bean
    @ConditionalOnMissingBean(DelayedNotificationEventStore.class)
    public DelayedNotificationEventStore delayedNotificationEventStore() {
        return new DelayedNotificationEventStore(new ConcurrentHashMap<>());
    }

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Bean
    public DelayingNotifier delayingNotifier(
            @Autowired(required = false) AbstractStatusChangeNotifier statusChangeNotifier,
            DelayedNotificationEventStore eventStore, NotificationDelayConfigurationProperties properties) {
        Notifier delegate = statusChangeNotifier != null ? statusChangeNotifier : new LoggingNotifier();
        return new DelayingNotifier(delegate, eventStore, properties);
    }
}