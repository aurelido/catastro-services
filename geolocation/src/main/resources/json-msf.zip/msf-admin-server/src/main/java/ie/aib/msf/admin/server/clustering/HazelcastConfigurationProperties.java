package ie.aib.msf.admin.server.clustering;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "spring.boot.admin.hazelcast")
@Component
@Getter
@Setter
public class HazelcastConfigurationProperties {

    /**
     * The name of the Hazelcast map containing the application metadata
     */
    private String applicationStore = "spring-boot-admin-application-store";

    /**
     * The name of the Hazelcast list containing the journal events
     */
    private String eventListName = "spring-boot-admin-event-store";

    /**
     * The name of the Hazelcast map containing the delayed notification events
     */
    private String delayNotificationEventStoreMapName = "spring-boot-admin-delayed-notification-event-store";

    /**
     * The maximum number of journal events to store
     */
    private int journalEventSize = 1000;

    /**
     * The number of Hazelcast backups
     */
    private int backupCount = 1;

    /**
     * Enable Hazelcast JMX
     */
    private boolean jmxEnabled = true;

    /**
     * The port to run Hazelcast on. This is the port the application uses to communicate with Hazelcast
     */
    private int port = 5701;

    /**
     * The maximum number of ports Hazelcast can attempt to use when setting a port.
     * <p/>
     * The default setting of 1 means that Hazelcast must use the specified port, and will fail to start if it is not available<br/>
     * Setting it to 10, for example, means that Hazelcast would try ports 5701-5710 until it finds an available port.
     * <p/>
     * It is best to use an explicit port. It is only an issue if running multiple instances on the same physical machine
     */
    private int portCount = 1;

    /**
     * The port range Hazelcast should use to communicate with peers.
     * <p/>
     * Can take values like "64000-64100" or "64000,64001,64002"
     * <p/>
     * If running a single Hazelcast instance per physical machine, it is best of set a single value.<br/>
     * This port needs to be open for communication with its peers, so a firewall rule may be required.
     */
    private String outboundPortDefinition;

    /**
     * Set the well known members
     * <p/>
     * To join a Hazelcast cluster, peers need to know about at least one well known member.<br/>
     * In the case of a cluster of two peers, both members should add the ip address of the other to this list.<br/>
     * If the member is running on a non-default port, the port and ip should be specified, e.g. "127.0.0.1:5702"
     */
    private List<String> members = new ArrayList<>();
}