package ie.aib.msf.admin.server;

import io.micrometer.core.instrument.Meter.Id;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.config.MeterFilter;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetricsConfiguration {

    public MetricsConfiguration(MeterRegistry meterRegistry) {
        meterRegistry.config().meterFilter(MeterFilter
                .deny(MetricsConfiguration::checkApiApplicationUriTag));
    }

    /*
        Suppress api/application/{id{, since the admin server programmatically adds apis instead of using a template uri
        This would add a series per tab for every application instance
     */
    private static boolean checkApiApplicationUriTag(Id meterId) {
        String tag = meterId.getTag("uri");
        return tag != null && tag.contains("api/applications/");
    }
}