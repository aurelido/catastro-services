package ie.aib.msf.admin.server.clustering;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import ie.aib.msf.admin.server.notification.DelayedNotificationEvent;
import ie.aib.msf.admin.server.notification.DelayedNotificationEventStore;
import ie.aib.msf.admin.server.notification.NotifierConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AutoConfigureBefore(NotifierConfiguration.class)
@AutoConfigureAfter(HazelcastConfiguration.class)
@ConditionalOnProperty(prefix = "spring.boot.admin.hazelcast", name = "enabled", matchIfMissing = true)
public class HazelcastDelayEventStoreConfiguration {

    private final HazelcastInstance hazelcastInstance;
    private final HazelcastConfigurationProperties hazelcastProperties;

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    public HazelcastDelayEventStoreConfiguration(HazelcastInstance hazelcastInstance,
            HazelcastConfigurationProperties hazelcastProperties) {
        this.hazelcastInstance = hazelcastInstance;
        this.hazelcastProperties = hazelcastProperties;
    }

    @Bean
    @ConditionalOnMissingBean(DelayedNotificationEventStore.class)
    public DelayedNotificationEventStore delayedNotificationEventStore() {
        IMap<String, DelayedNotificationEvent> map = hazelcastInstance
                .getMap(hazelcastProperties.getDelayNotificationEventStoreMapName());
        return new DelayedNotificationEventStore(map);
    }
}