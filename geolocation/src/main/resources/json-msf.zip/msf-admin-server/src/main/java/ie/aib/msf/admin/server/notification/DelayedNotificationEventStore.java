package ie.aib.msf.admin.server.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Event Store for Notification Events that have been delayed for a fixed period
 */
public class DelayedNotificationEventStore {

    private final Map<String, DelayedNotificationEvent> delayedEvents;

    public DelayedNotificationEventStore(Map<String, DelayedNotificationEvent> delayedEvents) {
        this.delayedEvents = delayedEvents;
    }

    /**
     * Add an event for the store for the given application id
     * @param applicationId the id of the application
     * @param event the event to add to the store
     */
    public void add(String applicationId, DelayedNotificationEvent event) {
        delayedEvents.putIfAbsent(applicationId, event);
    }

    /**
     * Remove an event from the store for the given application id
     * @param applicationId the id of the application
     */
    public void remove(String applicationId) {
        delayedEvents.remove(applicationId);
    }

    /**
     * @return The delayed events for all applications
     */
    public List<DelayedNotificationEvent> getEvents() {
        return new ArrayList<>(delayedEvents.values());
    }
}