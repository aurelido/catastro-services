package ie.aib.msf.admin.server.notification;

import de.codecentric.boot.admin.event.ClientApplicationEvent;
import java.io.Serializable;

public class DelayedNotificationEvent implements Serializable {

    private final ClientApplicationEvent event;
    private long triggerTime;

    DelayedNotificationEvent(ClientApplicationEvent event) {
        this.event = event;
        this.triggerTime = event.getTimestamp();
    }

    ClientApplicationEvent getEvent() {
        return event;
    }

    long getTriggerTime() {
        return triggerTime;
    }
}