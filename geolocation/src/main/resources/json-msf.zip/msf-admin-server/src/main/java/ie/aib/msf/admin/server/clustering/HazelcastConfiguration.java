package ie.aib.msf.admin.server.clustering;

import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.ListConfig;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.NetworkConfig;
import ie.aib.msf.admin.server.notification.NotificationDelayConfigurationProperties;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

@Configuration
@AutoConfigureBefore(HazelcastAutoConfiguration.class)
@ConditionalOnProperty(prefix = "spring.boot.admin.hazelcast", name = "enabled", matchIfMissing = true)
public class HazelcastConfiguration {

    private final HazelcastConfigurationProperties hazelcastProperties;
    private final NotificationDelayConfigurationProperties delayConfigurationProperties;

    public HazelcastConfiguration(
            HazelcastConfigurationProperties hazelcastProperties,
            NotificationDelayConfigurationProperties delayConfigurationProperties) {
        this.hazelcastProperties = hazelcastProperties;
        this.delayConfigurationProperties = delayConfigurationProperties;
    }

    @Bean
    public Config hazelcastConfig() {
        Config config = new Config()
                .setProperty("hazelcast.jmx", Boolean.toString(hazelcastProperties.isJmxEnabled()))
                //application store configuration, for keeping apps in sync
                .addMapConfig(new MapConfig(hazelcastProperties.getApplicationStore())
                        .setBackupCount(hazelcastProperties.getBackupCount())
                        .setEvictionPolicy(EvictionPolicy.NONE))
                //journal event list configuration
                .addListConfig(new ListConfig(hazelcastProperties.getEventListName())
                        .setBackupCount(hazelcastProperties.getBackupCount())
                        .setMaxSize(hazelcastProperties.getJournalEventSize()));
        //delayed notifications event store, only enable if the notification delay is set to more than 0
        if (delayConfigurationProperties.getPeriodInMinutes() > 0L) {
            config.addMapConfig(new MapConfig(hazelcastProperties.getDelayNotificationEventStoreMapName())
                    .setBackupCount(hazelcastProperties.getBackupCount())
                    .setEvictionPolicy(EvictionPolicy.NONE));
        }

        NetworkConfig networkConfig = config.getNetworkConfig().setPort(hazelcastProperties.getPort());
        networkConfig.setPortCount(hazelcastProperties.getPortCount());

        if (!StringUtils.isEmpty(hazelcastProperties.getOutboundPortDefinition())) {
            networkConfig.addOutboundPortDefinition(hazelcastProperties.getOutboundPortDefinition());
        }

        JoinConfig joinConfig = networkConfig.getJoin();
        joinConfig.getMulticastConfig().setEnabled(false);
        joinConfig.getAwsConfig().setEnabled(false);
        joinConfig.getTcpIpConfig().setEnabled(true).setMembers(hazelcastProperties.getMembers());

        return config;
    }
}