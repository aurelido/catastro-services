package ie.aib.msf.admin.server.notification;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "spring.boot.admin.notify.delay")
@Component
@RefreshScope
@Getter
@Setter
public class NotificationDelayConfigurationProperties {

    /**
     * Length of delay in minutes before sending notifications
     * Default is 0 minutes (no delay)
     */
    private long periodInMinutes = 0L;

    /**
     * Statuses to send notifications for
     */
    private String[] statuses = {"DOWN", "OFFLINE"};
}