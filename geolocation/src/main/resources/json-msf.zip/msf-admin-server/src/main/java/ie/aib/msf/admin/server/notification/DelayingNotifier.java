package ie.aib.msf.admin.server.notification;

import de.codecentric.boot.admin.event.ClientApplicationEvent;
import de.codecentric.boot.admin.event.ClientApplicationStatusChangedEvent;
import de.codecentric.boot.admin.notify.AbstractEventNotifier;
import de.codecentric.boot.admin.notify.Notifier;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import org.springframework.util.Assert;

/**
 * Notifier for delaying notifications for a set period.
 * If an event occurs during the period period to cancel the notification, no notification is sent.
 * E.g. and application goes down briefly and comes back up
 */
public class DelayingNotifier extends AbstractEventNotifier {

    private final Notifier delegate;
    private final DelayedNotificationEventStore eventStore;
    private NotificationDelayConfigurationProperties properties;

    public DelayingNotifier(Notifier delegate, DelayedNotificationEventStore eventStore,
            NotificationDelayConfigurationProperties properties) {
        this.eventStore = eventStore;
        this.properties = properties;
        Assert.notNull(delegate, "'delegate' must not be null!");
        this.delegate = delegate;
    }

    @Override
    protected void doNotify(ClientApplicationEvent event) {
        if (shouldCancelNotification(event)) {
            eventStore.remove(event.getApplication().getId());
        } else if (shouldDelayNotification(event)) {
            eventStore.add(event.getApplication().getId(), new DelayedNotificationEvent(event));
        }
    }

    void sendDelayedNotifications() {
        long now = System.currentTimeMillis();
        for (DelayedNotificationEvent delayedEvent : eventStore.getEvents()) {
            if (now >= delayedEvent.getTriggerTime() + TimeUnit.MINUTES.toMillis(properties.getPeriodInMinutes())) {
                delegate.notify(delayedEvent.getEvent());
                eventStore.remove(delayedEvent.getEvent().getApplication().getId());
            }
        }
    }

    private boolean shouldCancelNotification(ClientApplicationEvent event) {
        return event instanceof ClientApplicationStatusChangedEvent
                && Arrays.binarySearch(properties.getStatuses(), event.getApplication().getStatusInfo().getStatus())
                < 0;
    }

    private boolean shouldDelayNotification(ClientApplicationEvent event) {
        return event instanceof ClientApplicationStatusChangedEvent
                && Arrays.binarySearch(properties.getStatuses(), event.getApplication().getStatusInfo().getStatus())
                >= 0;
    }

}