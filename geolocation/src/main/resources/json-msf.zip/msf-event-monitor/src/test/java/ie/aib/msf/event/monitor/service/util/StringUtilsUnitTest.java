package ie.aib.msf.event.monitor.service.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class StringUtilsUnitTest {
    @Test
    public void testTruncate() {
        String string = "12345";
        String result;

        result = StringUtils.truncate(string, 6);
        assertEquals(string, result);

        result = StringUtils.truncate(string, 5);
        assertEquals(string, result);

        result = StringUtils.truncate(string, 4);
        assertEquals("1234" + StringUtils.TRUNCATED, result);

        result = StringUtils.truncate(string, 0);
        assertEquals(StringUtils.TRUNCATED, result);

        result = StringUtils.truncate(string, -1);
        assertEquals(string, result);

        result = StringUtils.truncate(null, -1);
        assertNull(result);
    }
}