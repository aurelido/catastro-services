package ie.aib.msf.event.monitor.streamlistener;

import ie.aib.msf.event.monitor.service.ProcessBytes;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

import java.util.Map;

@EnableBinding({Sink.class})
public class EventMonitorStreamListener {
    private static final Log LOG = LogFactory.getLog(EventMonitorStreamListener.class);

    private final ProcessBytes processBytes;

    @Autowired
    public EventMonitorStreamListener(ProcessBytes processBytes) {
        this.processBytes = processBytes;
    }

    @StreamListener(Sink.INPUT)
    public void processInput(@Headers Map<String, Object> headers, @Payload byte[] bytes) {
        processBytes.process(headers, bytes);
	}
}
