package ie.aib.msf.event.monitor.service.util;

public class StringUtils {

    public static final String TRUNCATED = "...(TRUNCATED)";

    private StringUtils() {
    }

    /**
     *
     * @param string
     * @param length
     * @return
     */
    public static String truncate(String string, int length) {
        if (string == null) {
            return null;
        }
        if (length < 0) {
            length = Integer.MAX_VALUE;
        }
        int endIndex = Math.min(string.length(), length);
        String stringBody = string.substring(0, endIndex);
        String stringTruncated;
        if (endIndex < string.length()) {
            stringTruncated = TRUNCATED;
        }
        else {
            stringTruncated = "";
        }

        return stringBody + stringTruncated;
    }
}
