package ie.aib.msf.event.monitor.service;

import ie.aib.msf.core.domain.model.event.LogLevel;
import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;
import ie.aib.msf.event.monitor.configuration.EventMonitorProperties;
import ie.aib.msf.event.monitor.service.util.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Service
public class ProcessEvent {
    private static final Log LOG = LogFactory.getLog(ProcessEvent.class);

    private final EventMonitorProperties eventMonitorProperties;
    private final ObjectMapperHelper objectMapperHelper;

    @Autowired
    public ProcessEvent(EventMonitorProperties eventMonitorProperties, ObjectMapperHelper objectMapperHelper) {
        this.eventMonitorProperties = eventMonitorProperties;
        this.objectMapperHelper = objectMapperHelper;
    }

    public void process(Map<String, Object> headers, AbstractLogEntry event) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Processing event");
        }

        log(headers, event);

        if (LOG.isDebugEnabled()) {
            LOG.debug("Finished processing event");
        }
    }

    private void log(Map<String, Object> headers, AbstractLogEntry event) {
        LogLevel logLevel = event.getSeverity();

        if (logLevel == null ) {
            LOG.warn("Unknown severity - " + event.getSeverity());
            logLevel = LogLevel.WARNING;
        }

        switch (logLevel) {
            case CRITICAL:
                LOG.fatal(composeMessage(headers, event));
                break;
            case ERROR:
                LOG.error(composeMessage(headers, event));
                break;
            case WARNING:
                LOG.warn(composeMessage(headers, event));
                break;
            case INFO:
                if (LOG.isInfoEnabled()) {
                    LOG.info(composeMessage(headers, event));
                }
                break;
            case DEBUG:
                if (LOG.isDebugEnabled()) {
                    LOG.debug(composeMessage(headers, event));
                }
                break;
            case TRACE:
                if (LOG.isTraceEnabled()) {
                    LOG.trace(composeMessage(headers, event));
                }
                break;
            default:
                LOG.warn("Unhandled logLevel - " + event.getSeverity());
                LOG.warn(composeMessage(headers, event));
                break;
        }
    }

    private String composeMessage(Map<String, Object> headers, AbstractLogEntry event) {
        Object payload = event.getPayload();
        String eventAsString = null;
        String payloadAsString = null;
        Exception exception = null;

        try {
            Field payloadField = ReflectionUtils.findField(event.getClass(), "payload");
            payloadField.setAccessible(true);
            payloadField.set(event, null);
            eventAsString = objectMapperHelper.toString(event);
            if (payload != null) {
                payloadAsString = StringUtils.truncate(objectMapperHelper.toString(payload), eventMonitorProperties.getPayloadLoggingCharacterLimits().getAbstractLogEntry());
            }
        }
        catch (Exception e) {
            exception = e;
        }

        String logMessage = "Logging payload - JSON AbstractLogEntry ...\n  Headers: %s\n  Event: %s\n  Payload: %s\n  Exception: %s";
        return String.format(logMessage, headers, eventAsString, payloadAsString, exception);
    }
}
