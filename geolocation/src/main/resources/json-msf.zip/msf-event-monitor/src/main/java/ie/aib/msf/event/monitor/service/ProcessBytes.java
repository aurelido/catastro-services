package ie.aib.msf.event.monitor.service;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import ie.aib.msf.event.monitor.configuration.EventMonitorProperties;
import ie.aib.msf.event.monitor.service.util.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ie.aib.msf.core.domain.model.event.entry.AbstractLogEntry;
import ie.aib.msf.core.helper.ObjectMapperHelper;

@Service
public class ProcessBytes {
    private static final Log LOG = LogFactory.getLog(ProcessBytes.class);

    private final EventMonitorProperties eventMonitorProperties;
    private final ObjectMapperHelper objectMapperHelper;
    private final ProcessEvent processEvent;

    @Autowired
    public ProcessBytes(EventMonitorProperties eventMonitorProperties, ObjectMapperHelper objectMapperHelper, ProcessEvent processEvent) {
        this.eventMonitorProperties = eventMonitorProperties;
        this.objectMapperHelper = objectMapperHelper;
        this.processEvent = processEvent;
    }

    public void process(Map<String, Object> headers, byte[] bytes) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Processing input");
        }

        String payloadAsString = null;
        AbstractLogEntry event = null;
        Exception exception = null;

        try {
            payloadAsString = new String(bytes, StandardCharsets.UTF_8);
            event = objectMapperHelper.fromJson(payloadAsString, AbstractLogEntry.class);
        }
        catch (RuntimeException e) {
            exception = e;
        }

        if (event == null) {
            skipPayload(headers, payloadAsString, exception);
        }
        else {
            processEvent.process(headers, event);
        }

        if (LOG.isDebugEnabled()) {
            LOG.debug("Finished processing input");
        }
    }
    
    private void skipPayload(Map<String, Object> headers, String payloadAsString, Exception exception) {
        String logMessage = "Skipping payload - not a JSON AbstractLogEntry ...\n  Headers: %s\n  Payload: %s\n  Exception: %s";
        String payloadOut = StringUtils.truncate(payloadAsString, eventMonitorProperties.getPayloadLoggingCharacterLimits().getNonAbstractLogEntry());
        LOG.warn(String.format(logMessage, headers, payloadOut, exception));
    }
}
