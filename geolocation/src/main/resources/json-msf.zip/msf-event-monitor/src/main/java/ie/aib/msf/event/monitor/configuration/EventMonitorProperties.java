package ie.aib.msf.event.monitor.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("ie.aib.msf.event.monitor")
public class EventMonitorProperties {

    public static class PayloadLoggingCharacterLimits {
        private int abstractLogEntry = 0;
        private int nonAbstractLogEntry = 100;

        public int getAbstractLogEntry() {
            return abstractLogEntry;
        }

        public void setAbstractLogEntry(int abstractLogEntry) {
            this.abstractLogEntry = abstractLogEntry;
        }

        public int getNonAbstractLogEntry() {
            return nonAbstractLogEntry;
        }

        public void setNonAbstractLogEntry(int nonAbstractLogEntry) {
            this.nonAbstractLogEntry = nonAbstractLogEntry;
        }
    }

    private PayloadLoggingCharacterLimits payloadLoggingCharacterLimits;

    private String email;

    public PayloadLoggingCharacterLimits getPayloadLoggingCharacterLimits() {
        return payloadLoggingCharacterLimits;
    }

    public void setPayloadLoggingCharacterLimits(PayloadLoggingCharacterLimits payloadLoggingCharacterLimits) {
        this.payloadLoggingCharacterLimits = payloadLoggingCharacterLimits;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
