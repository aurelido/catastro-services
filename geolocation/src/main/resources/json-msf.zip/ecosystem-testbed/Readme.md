# Ecosystem Testbed

This project can be used to smoke test the microservices ecosystem.

It uses [testcontainers](https://www.testcontainers.org) to bring up the ecosystem components, 
and a simple microservice,
and run some basic end to end tests against them.


It includes:

* config-server

* edge-server (Zuul)

* discovery-service (Eureka)

* admin-server

* customer-service (simple service included in this project)

* Kafka (+Zookeeper)

* Cassandra

## Usage

The config-server needs credentials to be able to connect to git, 
so you must set the following ENV variables on your system (or modify the docker-compose.yml file locally)

* MSF_CONFIG_GIT_USERNAME
* MSF_CONFIG_GIT_PASSWORD

Due to the fact that the Nexus Docker repo needs you to be logged in before pulling images, you may have to run:

`docker login nexus3.aib.pri:18444` to log in to the repo, and then

`docker-compose pull` to pull the images before starting the tests.


### Automated tests through Maven
Check out the project and run `mvn clean verify docker:build`

This will run the unit and integration tests, and then build a Docker image for the customer service.

Next run `mvn verify -Pacceptance-tests`, this will run the acceptance test with test containers

### Exploratory Testing
You can also run `docker-compose up` from the root of the project(after first building the image), which can be used to exploratory / manual testing

Running this way will pick up the port mappings from the `docker-compose.override.yml` file, 
and expose port so they can be accessed locally.

## Clean up

TestContainers will clean up any created resources, even if the test is aborted

## Notes

* The Docker machine needs at least 4GB of available RAM to run all the containers needed for the test. 

    This is mostly due to Cassandra having high memory requirements (>2GB)