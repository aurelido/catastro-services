package ie.aib.msf.samples.customerservice;

import java.io.File;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.testcontainers.containers.DockerComposeContainer;
import org.testcontainers.containers.wait.strategy.Wait;

public class ServiceAT extends AbstractAT {

    @ClassRule
    public static DockerComposeContainer environment =
            new DockerComposeContainer(new File("src/test/resources/docker-compose.yml"))
                    .withLocalCompose(true)
                    .withPull(false)
                    .withExposedService(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT, Wait.forHttp("/actuator/health"));

    @BeforeClass
    public static void setupKafkaConsumer() {
        setupKafkaConsumer(environment);
    }

    @Test
    public void testReadCustomer() {
        String serviceHost = environment.getServiceHost(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);
        Integer servicePort = environment.getServicePort(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);

        testRead(serviceHost, servicePort, TEST_CUSTOMER, "Test", "Customer");
    }

    @Test
    public void testWriteCustomer() {
        writeAndVerifyCustomer(environment);
        verifyWriteToKafka();
    }
}
