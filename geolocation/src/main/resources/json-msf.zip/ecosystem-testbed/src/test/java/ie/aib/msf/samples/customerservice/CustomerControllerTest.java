package ie.aib.msf.samples.customerservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ie.aib.msf.core.domain.model.event.entry.BusinessLogEntry;
import ie.aib.msf.eventtemplate.KafkaEventTemplate;
import ie.aib.msf.samples.customerservice.model.Customer;
import ie.aib.msf.samples.customerservice.repository.CustomerRepository;
import org.junit.Before;
import org.junit.Test;

public class CustomerControllerTest {

    private CustomerController customerController;
    private KafkaEventTemplate kafkaEventTemplate;
    private CustomerRepository customerRepository;

    @Before
    public void setUp() throws Exception {
        kafkaEventTemplate = mock(KafkaEventTemplate.class);
        customerRepository = mock(CustomerRepository.class);
        customerController = new CustomerController(kafkaEventTemplate, customerRepository);
    }

    @Test
    public void testGetCustomer() {
        String username = "test";
        Customer expectedCustomer = new Customer(username, "Test", "Customer");
        when(customerRepository.findByUsername("test")).thenReturn(expectedCustomer);
        assertThat(customerController.getCustomer(username)).isEqualTo(expectedCustomer);
    }

    @Test
    public void testCreateCustomer() {
        String username = "test";
        String firstName = "Test";
        String lastName = "Customer";
        Customer expectedCustomer = new Customer(username, firstName, lastName);
        when(customerRepository.save(expectedCustomer)).thenReturn(expectedCustomer);
        assertThat(customerController.createCustomer(username, firstName, lastName)).isEqualTo(expectedCustomer);
        verify(kafkaEventTemplate, times(1)).business(any(BusinessLogEntry.class));
    }
}