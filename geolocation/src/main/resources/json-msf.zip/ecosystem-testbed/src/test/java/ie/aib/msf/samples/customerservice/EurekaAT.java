package ie.aib.msf.samples.customerservice;

import static org.assertj.core.api.Assertions.assertThat;

import com.jayway.jsonassert.JsonAssert;
import org.junit.ClassRule;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.wait.strategy.Wait;

public class EurekaAT {

    private RestTemplate restTemplate = new RestTemplate();

    @ClassRule
    public static GenericContainer eureka = new GenericContainer(
            "nexus3.aib.pri:18444/aib_msf/msf-eureka-server:1.3.0")
            .withEnv("MANAGEMENT_PORT", "8761")
            .withExposedPorts(8761)
            .waitingFor(Wait.forHttp("/actuator/health").forStatusCode(200));

    @Test
    public void testInfoEndpoint() {
        String ipAddress = eureka.getContainerIpAddress();
        Integer mappedPort = eureka.getMappedPort(8761);

        ResponseEntity<String> entity = restTemplate
                .getForEntity(String.format("http://%s:%d/actuator/info", ipAddress, mappedPort), String.class);

        assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.OK);
        JsonAssert.with(entity.getBody()).assertEquals("$.build.version", "1.3.0");
    }
}
