package ie.aib.msf.samples.customerservice;

import static org.assertj.core.api.Assertions.assertThat;

import com.jayway.jsonassert.JsonAssert;
import ie.aib.msf.security.jwt.test.JwtTestTokenGenerator;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.hamcrest.Matchers;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testcontainers.containers.DockerComposeContainer;

class AbstractAT {

    //customer-service constants
    static final String CUSTOMER_SERVICE = "customer-service_1";
    static final int CUSTOMER_SERVICE_STANDARD_PORT = 8080;

    //JWT constants
    private static final String NAME = "test";
    private static final String USER = "user";
    static final String TEST_CUSTOMER = "testcustomer";

    private static KafkaConsumer<String, String> kafkaConsumer;

    private static RestTemplate restTemplate = new RestTemplate();

    static void setupKafkaConsumer(DockerComposeContainer environment) {
        //the host is just the ip of the docker machine, the address for all services is the same
        String kafkaHost = environment.getServiceHost(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);
        //kafka is not given a random port, because of the way kafka.advertised.listeners work
        Integer kafkaPort = 9092;

        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaHost + ":" + kafkaPort);
        props.put("group.id", UUID.randomUUID().toString());
        props.put("enable.auto.commit", "false");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

        kafkaConsumer = new KafkaConsumer<>(props);
        kafkaConsumer.subscribe(Collections.singletonList("testbed_business"));
        kafkaConsumer.poll(0);
    }

    void testRead(String serviceHost, int servicePort, String username, String firstName, String lastName) {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER, NAME);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION,
                "Bearer " + JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS256, "test", claims));

        ResponseEntity<String> response = restTemplate
                .exchange(String.format("http://%s:%d/customers/%s", serviceHost, servicePort, username),
                        HttpMethod.GET,
                        new HttpEntity<>(headers), String.class);

        checkCustomerResponse(response, username, firstName, lastName);
    }

    private void checkCustomerResponse(ResponseEntity<String> response, String username, String firstName,
            String lastName) {
        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody()).isNotEmpty();
        JsonAssert.with(response.getBody()).assertThat("$.username", Matchers.equalTo(username));
        JsonAssert.with(response.getBody()).assertThat("$.firstName", Matchers.equalTo(firstName));
        JsonAssert.with(response.getBody()).assertThat("$.lastName", Matchers.equalTo(lastName));
    }

    void writeAndVerifyCustomer(DockerComposeContainer environment) {
        String serviceHost = environment.getServiceHost(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);
        Integer servicePort = environment.getServicePort(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);

        String username = "writecustomer";
        String firstName = "Write";
        String lastName = "Customer";

        ResponseEntity<String> response = restTemplate
                .postForEntity(String.format("http://%s:%d/customers", serviceHost, servicePort),
                        createWriteRequest(username, firstName, lastName), String.class);
        checkCustomerResponse(response, username, firstName, lastName);
        //read the customer back to make sure it was written to Cassandra
        testRead(serviceHost, servicePort, username, firstName, lastName);
    }

    void verifyWriteToKafka() {

        ConsumerRecords<String, String> records = kafkaConsumer.poll(1000);
        assertThat(records.count()).isEqualTo(1);
    }

    private HttpEntity<MultiValueMap<String, String>> createWriteRequest(String username, String firstName,
            String lastName) {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER, NAME);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add(HttpHeaders.AUTHORIZATION,
                "Bearer " + JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS256, "test", claims));

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add("username", username);
        map.add("firstName", firstName);
        map.add("lastName", lastName);
        return new HttpEntity<>(map, headers);
    }
}
