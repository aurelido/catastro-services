package ie.aib.msf.samples.customerservice.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.Insert;
import ie.aib.msf.samples.customerservice.exceptions.CustomerNotFoundException;
import ie.aib.msf.samples.customerservice.model.Customer;
import org.junit.Before;
import org.junit.Test;

public class CassandraCustomerRepositoryTest {

    private CassandraCustomerRepository customerRepository;
    private Session session;

    @Before
    public void setUp() throws Exception {
        session = mock(Session.class);
        customerRepository = new CassandraCustomerRepository(session);
    }

    @Test
    public void testFindByUsername() throws Exception {
        String username = "testuser";
        String firstName = "Test";
        String lastName = "User";

        ResultSet rows = mock(ResultSet.class);
        Row row = mock(Row.class);
        when(row.getString("username")).thenReturn(username);
        when(row.getString("firstName")).thenReturn(firstName);
        when(row.getString("lastName")).thenReturn(lastName);
        when(rows.one()).thenReturn(row);
        when(session.execute(anyString())).thenReturn(rows);
        assertThat(customerRepository.findByUsername(username)).isEqualTo(new Customer(username, firstName, lastName));
    }

    @Test(expected = CustomerNotFoundException.class)
    public void testUserNotFound() {
        when(session.execute(anyString())).thenReturn(null);
        customerRepository.findByUsername("missing");
    }

    @Test(expected = CustomerNotFoundException.class)
    public void testSessionException() {
        when(session.execute(anyString())).thenThrow(new RuntimeException());
        customerRepository.findByUsername("missing");
    }

    @Test
    public void testSave() throws Exception {
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.wasApplied()).thenReturn(true);
        when(session.execute(any(Insert.class))).thenReturn(resultSet);
        Customer customer = new Customer("testuser", "Test", "User");
        assertThat(customerRepository.save(customer)).isEqualTo(customer);
        verify(session, times(1)).execute(any(Insert.class));
    }
}