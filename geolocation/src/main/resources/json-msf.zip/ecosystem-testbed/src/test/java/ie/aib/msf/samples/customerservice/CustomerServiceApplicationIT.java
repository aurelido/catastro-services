package ie.aib.msf.samples.customerservice;

import static ie.aib.msf.security.jwt.test.JwtTestTokenGenerator.generateToken;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.consumer.Consumer;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionIntegrationTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;

@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,
        properties = {"ie.aib.cassandra.dse.port=9142",
                "spring.cloud.stream.kafka.binder.configuration.max.block.ms=1000"})
@EmbeddedCassandra(timeout = 90000L)
@TestExecutionListeners(listeners = {CassandraUnitDependencyInjectionIntegrationTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class})
public class CustomerServiceApplicationIT {

    private static final String TEST_BUSINESS = "testbed_business";
    private static final String BEARER = "Bearer ";
    private static final String NAME = "test";
    private static final String USER = "user";

    @ClassRule
    public static final KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, TEST_BUSINESS);
    private static Consumer<String, String> consumer;

    @Autowired
    MockMvc mockMvc;

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Autowired
    Session session;

    @BeforeClass
    public static void setupEnvironment() {
        System.setProperty("spring.cloud.stream.kafka.binder.auto-create-topics", "false");
        System.setProperty("spring.cloud.stream.kafka.binder.brokers", embeddedKafka.getBrokersAsString());
        Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("test", "false", embeddedKafka);
        DefaultKafkaConsumerFactory<String, String> cf = new DefaultKafkaConsumerFactory<>(
                consumerProps);
        consumer = cf.createConsumer();
        consumer.poll(0);
    }

    @AfterClass
    public static void shutdownKafka() {
        embeddedKafka.getKafkaServer(0).shutdown();
    }

    @Test
    public void testGetCustomer() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER, NAME);
        String jwt = generateToken(SignatureAlgorithm.HS512, "test", claims);
        mockMvc.perform(get("/customers/testcustomer")
                .header(HttpHeaders.AUTHORIZATION, BEARER + jwt))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("Test"));
    }

    @Test
    public void testCreateCustomer() throws Exception {
        Map<String, String> claims = new HashMap<>();
        claims.put(USER, NAME);
        String jwt = generateToken(SignatureAlgorithm.HS512, "test", claims);
        mockMvc.perform(post("/customers/")
                .param("username","testCustomer2")
                .param("firstName", "Test2")
                .param("lastName", "Customer")
                .header(HttpHeaders.AUTHORIZATION, BEARER + jwt))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("Test2"));

        ResultSet resultSet = session.execute("select * from customer_keyspace.customer");
        assertThat(resultSet.all().size()).isEqualTo(2);

        //TODO: investigate why kafka consumer is not returning any records
        /*ConsumerRecords<String, String> consumerRecords = consumer.poll(10000);
        assertThat(consumerRecords.count()).isEqualTo(1);*/
    }
}
