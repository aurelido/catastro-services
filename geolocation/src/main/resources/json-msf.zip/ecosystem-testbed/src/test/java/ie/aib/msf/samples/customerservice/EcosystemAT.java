package ie.aib.msf.samples.customerservice;

import static java.time.Duration.ofMinutes;

import com.jayway.jsonpath.JsonPath;
import java.io.File;
import java.util.List;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.testcontainers.containers.DockerComposeContainer;
import org.testcontainers.containers.wait.strategy.Wait;

public class EcosystemAT extends AbstractAT {

    //customer-service constants
    private static final int CUSTOMER_SERVICE_MANAGEMENT_PORT = 18080;

    //edger-server constants
    private static final String EDGE_SERVER = "msf-edge-server_1";
    private static final int EDGE_SERVER_STANDARD_PORT = 9006;
    private static final int EDGE_SERVER_MANAGEMENT_PORT = 19006;

    //admin server constants
    private static final String ADMIN_SERVER = "msf-admin-server_1";
    private static final int ADMIN_SERVER_MANAGEMENT_PORT = 19000;

    @SuppressWarnings("unchecked")
    @ClassRule
    public static DockerComposeContainer environment =
            new DockerComposeContainer(new File("docker-compose.yml"))
                    .withLocalCompose(true)
                    .withPull(false)
                    .withExposedService(EDGE_SERVER, EDGE_SERVER_STANDARD_PORT,
                            Wait.defaultWaitStrategy().withStartupTimeout(ofMinutes(5L)))
                    .withExposedService(EDGE_SERVER, EDGE_SERVER_MANAGEMENT_PORT, Wait.forHttp("/actuator/health")
                            .forResponsePredicate(EcosystemAT::isServiceDiscovered).withStartupTimeout(ofMinutes(5L)))
                    .withExposedService(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT)
                    .withExposedService(CUSTOMER_SERVICE, CUSTOMER_SERVICE_MANAGEMENT_PORT)
                    .withExposedService(ADMIN_SERVER, ADMIN_SERVER_MANAGEMENT_PORT, Wait.forHttp("/actuator/health"));

    @BeforeClass
    public static void setupKafkaConsumer() {
        setupKafkaConsumer(environment);
    }

    private static boolean isServiceDiscovered(String response) {
        return JsonPath.parse(response)
                .read("$.discoveryComposite.discoveryClient.services", List.class)
                .contains("customer-service");
    }

    @Test
    public void testReadCustomerDirectly() {
        String serviceHost = environment.getServiceHost(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);
        Integer servicePort = environment.getServicePort(CUSTOMER_SERVICE, CUSTOMER_SERVICE_STANDARD_PORT);

        testRead(serviceHost, servicePort, TEST_CUSTOMER, "Test", "Customer");
    }

    @Test
    public void testReadCustomerThroughEdgeServer() {
        String serviceHost = environment.getServiceHost(EDGE_SERVER, EDGE_SERVER_STANDARD_PORT);
        Integer servicePort = environment.getServicePort(EDGE_SERVER, EDGE_SERVER_STANDARD_PORT);

        testRead(serviceHost, servicePort, TEST_CUSTOMER, "Test", "Customer");
    }

    @Test
    public void testWriteCustomer() {
        writeAndVerifyCustomer(environment);
        verifyWriteToKafka();
    }
}