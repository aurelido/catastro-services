package ie.aib.msf.samples.customerservice;

import com.datastax.driver.core.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

@Configuration
class CassandraConfiguration {

    private final Session session;
    private final ResourceLoader resourceLoader;

    @Autowired
    CassandraConfiguration(Session session, ResourceLoader resourceLoader) {
        this.session = session;
        this.resourceLoader = resourceLoader;
    }

    @PostConstruct
    void initializeCassandra() throws IOException {
        Resource resource = resourceLoader.getResource("classpath:create-schema.cql");
        Scanner scanner = new Scanner(resource.getInputStream(), StandardCharsets.UTF_8.name()).useDelimiter(";");

        while (scanner.hasNext()) {
            session.execute(scanner.next());
        }
    }
}
