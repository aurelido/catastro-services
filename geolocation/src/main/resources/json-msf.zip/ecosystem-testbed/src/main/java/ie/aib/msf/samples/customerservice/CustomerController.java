package ie.aib.msf.samples.customerservice;

import ie.aib.msf.core.domain.model.event.entry.BusinessLogEntry;
import ie.aib.msf.eventtemplate.KafkaEventTemplate;
import ie.aib.msf.samples.customerservice.model.Customer;
import ie.aib.msf.samples.customerservice.repository.CustomerRepository;
import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customers")
@JwtAuthorization
class CustomerController {

    private KafkaEventTemplate kafkaEventTemplate;
    private CustomerRepository customerRepository;

    @Autowired
    CustomerController(KafkaEventTemplate kafkaEventTemplate, CustomerRepository customerRepository) {
        this.kafkaEventTemplate = kafkaEventTemplate;
        this.customerRepository = customerRepository;
    }

    @GetMapping("/{username}")
    Customer getCustomer(@PathVariable String username) {
        return customerRepository.findByUsername(username);
    }

    @PostMapping
    Customer createCustomer(String username, String firstName, String lastName) {
        Customer customer = new Customer(username, firstName, lastName);
        customer = customerRepository.save(customer);
        kafkaEventTemplate
                .business(BusinessLogEntry.builder().message("Created new Customer").payload(customer).build());
        return customer;
    }
}
