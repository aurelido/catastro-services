package ie.aib.msf.samples.customerservice.repository;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import ie.aib.msf.samples.customerservice.exceptions.CustomerNotCreatedException;
import ie.aib.msf.samples.customerservice.exceptions.CustomerNotFoundException;
import ie.aib.msf.samples.customerservice.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CassandraCustomerRepository implements CustomerRepository {

    private final Session session;

    @Autowired
    public CassandraCustomerRepository(Session session) {
        this.session = session;
    }

    @Override
    public Customer findByUsername(String username) {
        try {
            Row row = session
                    .execute(String.format("select * from customer_keyspace.customer where username='%s';", username))
                    .one();

            if (row == null) {
                throw new CustomerNotFoundException(String.format("customer: %s not found", username));
            }

            return new Customer(row.getString("username"), row.getString("firstName"), row.getString("lastName"));
        } catch (Exception e) {
            throw new CustomerNotFoundException(String.format("customer: %s not found", username));
        }
    }

    @Override
    public Customer save(Customer customer) {
        Insert insert = QueryBuilder.insertInto("customer_keyspace", "customer")
                .value("username", customer.getUsername())
                .value("firstName", customer.getFirstName())
                .value("lastName", customer.getLastName())
                .ifNotExists();

        ResultSet resultSet = session.execute(insert);

        if (resultSet.wasApplied()) {
            return customer;
        } else {
            throw new CustomerNotCreatedException("failed to save customer");
        }
    }
}
