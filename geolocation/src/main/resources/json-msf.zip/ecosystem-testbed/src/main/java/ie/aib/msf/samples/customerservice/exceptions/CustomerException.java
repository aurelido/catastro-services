package ie.aib.msf.samples.customerservice.exceptions;

class CustomerException extends RuntimeException {

    CustomerException(String message) {
        super(message);
    }
}
