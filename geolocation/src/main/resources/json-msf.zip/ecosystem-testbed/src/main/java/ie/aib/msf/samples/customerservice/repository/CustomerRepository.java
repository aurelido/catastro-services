package ie.aib.msf.samples.customerservice.repository;

import ie.aib.msf.samples.customerservice.model.Customer;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends org.springframework.data.repository.Repository<Customer, String> {

    Customer findByUsername(String username);

    Customer save(Customer customer);

}
