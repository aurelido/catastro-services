package io.spring.initializr.generator

import io.spring.initializr.metadata.AIBInitializerMetadata
import io.spring.initializr.metadata.AIBMsfVersionMetadataElement
import io.spring.initializr.metadata.InitializrMetadata

class AIBProjectRequest extends ProjectRequest {

    String msfVersion

    @Override
    void initialize(InitializrMetadata metadata) {
        if(!msfVersion) {
            msfVersion = ((AIBInitializerMetadata)metadata).msfVersions.default.id
        }

        AIBMsfVersionMetadataElement msfVersionMetadata = ((AIBInitializerMetadata) metadata).msfVersions.get(msfVersion)
        bootVersion = msfVersionMetadata.bootVersion
        super.initialize(metadata)
    }
}
