package io.spring.initializr.metadata

class AIBInitializerMetadata extends InitializrMetadata {

    final SingleSelectCapability msfVersions =
            new SingleSelectCapability('msfVersion', 'MSF Version', 'msf version')
}
