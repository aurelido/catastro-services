package io.spring.initializr.metadata

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "ie.aib")
class AIBProperties {

    String metadataUrl = 'http://localhost:8080/aib-metadata.json'
}
