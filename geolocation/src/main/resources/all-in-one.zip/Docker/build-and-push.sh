#!/bin/bash

export http_proxy=http://webproxy.prd.aib.pri:8080
export https_proxy=https://webproxy.prd.aib.pri:8080
export no_proxy=\"10.0.0.0/8,127.0.0.1,*.aib.pri,localhost\"

docker build -t aurelido/wiremock .