package ie.aib.msf.sample.payment.web;

import ie.aib.msf.core.domain.model.event.entry.*;
import ie.aib.msf.eventtemplate.KafkaEventTemplate;
import ie.aib.msf.sample.payment.model.Payment;
import ie.aib.msf.sample.payment.model.ValidationError;
import ie.aib.msf.sample.payment.service.PaymentService;
import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@JwtAuthorization
@RestController
@RequestMapping({ "/", "/payment" })
public class PaymentController {

	private static final Log logger = LogFactory.getLog(PaymentController.class);

    private static final String INVALID_REQUEST = "Invalid request";

    private PaymentService paymentService;
    private KafkaEventTemplate kafkaEventTemplate;

    @Autowired
    public PaymentController(PaymentService paymentService, KafkaEventTemplate kafkaEventTemplate) {
        this.paymentService = paymentService;
        this.kafkaEventTemplate = kafkaEventTemplate;
    }

    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    Payment processPayment(@Valid @RequestBody Payment payment) {

    	logger.info("Processing payment: " + payment);

        kafkaEventTemplate.audit(AuditLogEntry.builder().content(payment).build());
        paymentService.makePayment(payment.getDebitAccount(), payment.getCreditAccount(), payment.getAmount());
        return payment;
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    ValidationError handleBadRequest() {

        return new ValidationError(INVALID_REQUEST);
    }
}
