package ie.aib.msf.sample.payment.repository;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import ie.aib.msf.sample.payment.model.PaymentEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@ConditionalOnProperty(prefix = "cassandra", name = "enabled")
@Component
public class CassandraPaymentEventRepository implements PaymentEventRepository {

    private final Session session;

    @Autowired
    public CassandraPaymentEventRepository(Session session) {
        this.session = session;
    }

    @Override
    public PaymentEvent save(PaymentEvent paymentEvent) {
        Insert insert = QueryBuilder.insertInto("paymentevent")
                .value("iban", paymentEvent.getIban())
                .value("insertdate", paymentEvent.getInsertDate())
                .value("paymenteventtype", paymentEvent.getPaymentEventType().name())
                .value("amount", paymentEvent.getAmount())
                .ifNotExists();

        ResultSet resultSet = session.execute(insert);

        if(resultSet.wasApplied()) {
            return paymentEvent;
        } else {
            throw new RuntimeException("failed to save paymentevent"); //TODO : new exception type
        }
    }
}
