package ie.aib.msf.sample.payment.repository;

import ie.aib.msf.sample.payment.model.PaymentEvent;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentEventRepository extends org.springframework.data.repository.Repository<PaymentEvent, Long> {

    PaymentEvent save(PaymentEvent paymentEvent);
}
