package ie.aib.msf.sample.payment;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
public class PaymentAT {
}
