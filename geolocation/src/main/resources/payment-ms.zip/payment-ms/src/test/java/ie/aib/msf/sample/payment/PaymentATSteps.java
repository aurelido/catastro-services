package ie.aib.msf.sample.payment;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.fasterxml.jackson.databind.ObjectMapper;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import ie.aib.msf.sample.payment.model.Payment;
import ie.aib.msf.sample.payment.model.PaymentCompleteEvent;
import ie.aib.msf.security.jwt.test.JwtTestTokenGenerator;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.cassandraunit.CQLDataLoader;
import org.cassandraunit.dataset.cql.ClassPathCQLDataSet;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import static ie.aib.msf.sample.payment.PaymentUtil.*;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class PaymentATSteps {

    private static final String PROPERTY_APPLICATION_IP = "APP_IP";
    private static final String PROPERTY_APPLICATION_PORT = "APP_PORT";

    private TestRestTemplate template = new TestRestTemplate();
    private URL url;
    private Payment payment;
    private ResponseEntity<Payment> responseEntity;

    private static final String PROPERTY_KAFKA_IP = "CI_KAFKA_IP";
    private static final String PROPERTY_KAFKA_PORT = "CI_KAFKA_PORT";
    private static final String PROPERTY_KAFKA_TOPIC = "CI_KAFKA_TOPIC";

    private static final String PROPERTY_CASSANDRA_IP = "CI_CASSANDRA_IP";
    private static final String PROPERTY_CASSANDRA_PORT = "CI_CASSANDRA_PORT";
    private static final String PROPERTY_CASSANDRA_KEYSPACE = "CI_CASSANDRA_KEYSPACE";

    private static final String BEARER = "Bearer ";

    private KafkaConsumer<String, String> kafkaConsumer;
    private Session session;

    @Before
    public void before() throws MalformedURLException {
        String applicationIPProperty = System.getenv().get(PROPERTY_APPLICATION_IP);
        String applicationIP = applicationIPProperty != null ? applicationIPProperty : "localhost";
        String applicationPortProperty = System.getenv().get(PROPERTY_APPLICATION_PORT);
        int applicationPort = applicationPortProperty != null ? Integer.parseInt(applicationPortProperty) : 8080;
        url = new URL("http://" + applicationIP + ":" + applicationPort + "/");

        initializeKafka();
        initializeCassandra();
    }

    private void initializeKafka() {
        String kafkaIPProperty = System.getenv().get(PROPERTY_KAFKA_IP);
        String kafkaIP = kafkaIPProperty != null ? kafkaIPProperty : "192.168.99.100";

        String kafkaPortString = System.getenv().get(PROPERTY_KAFKA_PORT);
        int kafkaPort = kafkaPortString != null ? Integer.parseInt(kafkaPortString) : 9092;

        String kafkaTopicProperty = System.getenv().get(PROPERTY_KAFKA_TOPIC);
        String kafkaTopic = kafkaTopicProperty != null ? kafkaTopicProperty : "payment_business";

        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaIP + ":" + kafkaPort);
        props.put("group.id", UUID.randomUUID().toString());
        props.put("enable.auto.commit", "false");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        kafkaConsumer = new KafkaConsumer<>(props);
        kafkaConsumer.subscribe(Collections.singletonList(kafkaTopic));
        kafkaConsumer.poll(0);
    }

    private void initializeCassandra() {
        String cassandraIPProperty = System.getenv().get(PROPERTY_CASSANDRA_IP);
        String cassandraIP = cassandraIPProperty != null ? cassandraIPProperty : "192.168.99.100";

        String cassandraPortString = System.getenv().get(PROPERTY_CASSANDRA_PORT);
        int cassandraPort = cassandraPortString != null ? Integer.parseInt(cassandraPortString) : 9042;

        String cassandraKeyspaceProperty = System.getenv().get(PROPERTY_CASSANDRA_KEYSPACE);
        String cassandraKeyspace = cassandraKeyspaceProperty != null ? cassandraKeyspaceProperty : "payment_keyspace";

        Cluster cluster = Cluster.builder()
                .addContactPoint(cassandraIP)
                .withPort(cassandraPort)
                .build();

        session = cluster.connect(cassandraKeyspace);
        CQLDataLoader cqlDataLoader = new CQLDataLoader(session);
        cqlDataLoader.load(new ClassPathCQLDataSet("create-schema.cql"));
    }

    @When("^a user sends a valid payment$")
    public void aUserSendsAValidPayment() throws Throwable {
        Map<String, String> claims = new HashMap<>();
        claims.put("user", "TEST");
        String jwt = JwtTestTokenGenerator.generateToken(SignatureAlgorithm.HS512, "test-key", claims);
        HttpHeaders headers = new HttpHeaders();
        headers.add("AUTHORIZATION", BEARER + jwt);
        payment = PaymentUtil.createPayment(VALID_TEST_BIC, VALID_TEST_IBAN_1, VALID_TEST_BIC, VALID_TEST_IBAN_2, 123.45);
        HttpEntity<Payment> entity = new HttpEntity<>(payment, headers);

        responseEntity = template.exchange(url.toString(), HttpMethod.POST, entity, Payment.class);
    }

    @Then("^a valid response is returned$")
    public void aValidResponseIsReturned() throws Throwable {
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(payment, responseEntity.getBody());
    }

    @And("^an event is sent to kafka$")
    public void anEventIsSentToKafka() throws Throwable {
        ConsumerRecords<String, String> records = kafkaConsumer.poll(1000);
        assertThat(records.count(), is(1));
        for (ConsumerRecord<String, String> record : records) {
            ObjectMapper mapper = new ObjectMapper();
            PaymentCompleteEvent paymentEvent = mapper.readValue(record.value(), PaymentCompleteEvent.class);

            PaymentCompleteEvent expectedPaymentEvent = new PaymentCompleteEvent(payment.getDebitAccount(), payment.getCreditAccount(), payment.getAmount());
            assertThat(paymentEvent, is(expectedPaymentEvent));
        }
    }

    @And("^records are written to Cassandra$")
    public void recordsAreWrittenToCassandra() throws Throwable {
        ResultSet resultSet = session.execute("select * from paymentevent");
        assertEquals(2, resultSet.all().size());
    }
}
