package ie.aib.msf.sample.payment;

import ie.aib.msf.sample.payment.model.AccountReference;
import ie.aib.msf.sample.payment.model.Payment;

public class PaymentUtil {
    public static final String VALID_TEST_BIC = "AIBKIE2D";
    public static final String VALID_TEST_IBAN_1 = "IE11AIBK1111111111111111";
    public static final String VALID_TEST_IBAN_2 = "IE11AIBK9999999999999999";

    public static Payment createPayment(String debitBic, String debitIban, String creditBic, String creditIban, Double amount) {
        AccountReference debitAccount = new AccountReference(debitBic, debitIban);
        AccountReference creditAccount = new AccountReference(creditBic, creditIban);
        return new Payment(debitAccount, creditAccount, amount);
    }
}
