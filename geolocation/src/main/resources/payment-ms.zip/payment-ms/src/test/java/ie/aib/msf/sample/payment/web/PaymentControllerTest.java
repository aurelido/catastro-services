package ie.aib.msf.sample.payment.web;

import ie.aib.msf.core.domain.model.event.entry.AuditLogEntry;
import ie.aib.msf.eventtemplate.KafkaEventTemplate;
import ie.aib.msf.sample.payment.PaymentUtil;
import ie.aib.msf.sample.payment.model.Payment;
import ie.aib.msf.sample.payment.service.PaymentService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static ie.aib.msf.sample.payment.PaymentUtil.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;

public class PaymentControllerTest {

    private static PaymentController paymentController;

    @Mock
    KafkaEventTemplate kafkaEventTemplate;

    @Mock
    PaymentService paymentService;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        paymentController = new PaymentController(paymentService, kafkaEventTemplate);
    }

    @Test
    public void processPayment() throws Exception {
        Payment payment = PaymentUtil.createPayment(VALID_TEST_BIC, VALID_TEST_IBAN_1, VALID_TEST_BIC, VALID_TEST_IBAN_2, 123.45);
        Payment paymentResponse = paymentController.processPayment(payment);
        assertEquals(payment, paymentResponse);
        verify(kafkaEventTemplate).audit(any(AuditLogEntry.class));
    }

}