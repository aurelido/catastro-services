package ie.aib.comms.model;

import ie.aib.comms.exception.SmsException;

public enum Category {

    MARKETING("marketing"),
    OPERATIONAL("operational");

    private final String value;

    private Category(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    /**
     * This method gets the category.
     *
     * @param value for which to get the category object.
     * @return category object.
     * @throws SmsException if theres error during processing.
     */
    public static Category getCategory(String value) throws SmsException {

        for (Category category : Category.values()) {
            if (category.getValue().equals(value)) {
                return category;
            }
        }
        throw new IllegalArgumentException("Illegal Category value: " + value);
    }

}
