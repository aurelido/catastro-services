package ie.aib.comms.model;

import ie.aib.comms.exception.SmsException;

public enum Priority {

    HIGH("high"),
    NORMAL("normal");

    private final String value;

    private Priority(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    /**
     * This method gets the priority.
     *
     * @param value for which to get the priority object.
     * @return priority object.
     * @throws SmsException if theres error during processing.
     */
    public static Priority getPriority(String value) throws SmsException {

        for (Priority priority : Priority.values()) {
            if (priority.getValue().equals(value)) {
                return priority;
            }
        }
        throw new IllegalArgumentException("Illegal Priority value: " + value);
    }

}
