package ie.aib.comms.model;

import ie.aib.comms.exception.SmsException;

public enum CharacterSet {

    TBD1("tbd1"),
    TBD2("tbd2");

    private final String value;

    private CharacterSet(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    /**
     * This method gets the characterSet.
     *
     * @param value for which to get the characterSet object.
     * @return characterSet object.
     * @throws SmsException if theres error during processing.
     */
    public static CharacterSet getCharacterSet(String value) throws SmsException {

        for (CharacterSet characterSet : CharacterSet.values()) {
            if (characterSet.getValue().equals(value)) {
                return characterSet;
            }
        }
        throw new IllegalArgumentException("Illegal CharacterSet value: " + value);
    }

}
