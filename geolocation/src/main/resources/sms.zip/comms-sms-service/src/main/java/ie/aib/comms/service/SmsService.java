package ie.aib.comms.service;

import ie.aib.comms.exception.SmsException;
import ie.aib.comms.model.Sms;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URLEncoder;
import java.util.Arrays;

@Service
public class SmsService implements EnvironmentAware {

    private static Log logger = LogFactory.getLog(SmsService.class);
    private static final String OXYGEN8_SUCCESS_CODE = "101";

    private Environment environment;

    @Override
    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    /**
     * This method builds and sends the http request to the sms provider.
     *
     * @param sms containing the request data to pass to the sms provider.
     * @throws SmsException if an error occurs during processing.
     */
    public void sendSms(Sms sms) throws SmsException {
        logger.info("Processing SMS request for " + sms.getDestinationAddress());

        String encodeMessage;
        try {
            encodeMessage = URLEncoder.encode(sms.getMessage(), "UTF-8");
        } catch (UnsupportedEncodingException uee) {
            logger.error("UnsupportedEncodingException caught: ", uee);
            throw new SmsException(uee);
        }

        String requestBody =
                "Username=" + environment.getProperty("sms.oxygen.username")
                + "&Password=" + environment.getProperty("sms.oxygen.password")
                + "&CampaignID=" + environment.getProperty("sms.oxygen.campaign")
                + "&Content=" + encodeMessage
                + "&mask=" + "AIB"
                + "&channel=" + "BULK"
                + "&Multipart=1" // allows for multi part messages. greater than 160 gets split.
                + "&MSISDN=" + StringUtils.stripStart(sms.getDestinationAddress(), "+");

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, httpHeaders);

        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

        Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(
                environment.getProperty("sms.oxygen.proxy.host"),
                Integer.parseInt(environment.getProperty("sms.oxygen.proxy.port"))));
        requestFactory.setProxy(proxy);

        RestTemplate restTemplate = new RestTemplate(requestFactory);

        ResponseEntity<String> responseEntity;
        try {
            responseEntity = restTemplate.exchange(environment.getProperty("sms.oxygen.uri"),
                    HttpMethod.POST, httpEntity, String.class);

            HttpStatus httpStatus = responseEntity.getStatusCode();
            if (!HttpStatus.OK.equals(httpStatus)) {
                throw new SmsException("HTTPStatus: " + httpStatus.value() + " : "
                        + httpStatus.getReasonPhrase());
            }
        } catch (RuntimeException rexc) {
            logger.error("RuntimeException caught: ", rexc);
            throw new SmsException(rexc);
        } catch (Exception exc) {
            logger.error("Exception caught: ", exc);
            throw new SmsException(exc);
        }

        String response = responseEntity.getBody();
        logger.info("Response for " + sms.getDestinationAddress() + ": " + response);

        String[] responseStringParts = response.split("\n");
        if (responseStringParts != null && responseStringParts.length > 0) {
            String responseCode = responseStringParts[0];
            String responseDescription = responseStringParts[1];

            if (!OXYGEN8_SUCCESS_CODE.equals(responseCode)) {
                String errorString = "BAD Response from SMS Provider: "
                        + responseCode + " - " + responseDescription;
                logger.error(errorString);
                throw new SmsException(errorString);
            }

            // set messageIds onto response object
            sms.setMessageId(Arrays.asList(responseStringParts[2].split("\\s*,\\s*")));
            sms.setReceipt(false);
        } else {
            String errorString = "Response Body does not contain valid response data.";
            throw new SmsException(errorString);
        }

    }

}
