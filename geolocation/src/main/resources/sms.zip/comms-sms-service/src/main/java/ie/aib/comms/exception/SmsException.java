package ie.aib.comms.exception;

public class SmsException extends Exception {

    private static final long serialVersionUID = 1L;
    private String errorCode;
    private String errorString;

    public SmsException(Exception exc) {
        super(exc);
    }

    public SmsException(String exc) {
        super(exc);
    }

    /**
     * This is used to create with a custom error code and string.
     * @param errorCode for setting an error code.
     * @param errorString for setting and error string.
     */
    public SmsException(String errorCode, String errorString) {
        super();
        this.errorCode = errorCode;
        this.errorString = errorString;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorString() {
        return errorString;
    }

    public void setErrorString(String errorString) {
        this.errorString = errorString;
    }
}

