package ie.aib.comms.validation;

import ie.aib.comms.model.Sms;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Pattern;

public class SmsRequestValidator implements Validator {

    private static Log logger = LogFactory.getLog(SmsRequestValidator.class);
    private static final String INVALID_DEST_ADDRESS = "destinationAddress field is invalid";
    private static final int MIN_DEST_NUM_LEN = 5;
    private static final int MAX_INTL_DEST_NUM_LEN = 15;
    private static final Pattern DEST_REGEX_PATTERN =
            Pattern.compile("^\\+(?:[0-9] ?){6,14}[0-9]$");

    @Override
    public boolean supports(Class<?> clazz) {
        return Sms.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        logger.debug("SmsRequestValidator.validate start...");

        Sms smsRequest = (Sms)target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicationId", "",
                "applicationId field is invalid");

        if (smsRequest.getDestinationAddress() == null
                || StringUtils.isEmpty(smsRequest.getDestinationAddress())) {
            errors.rejectValue("destinationAddress", "", INVALID_DEST_ADDRESS);
        } else {
            if (smsRequest.getDestinationAddress().length() < MIN_DEST_NUM_LEN
                    || smsRequest.getDestinationAddress().length() > MAX_INTL_DEST_NUM_LEN) {
                errors.rejectValue("destinationAddress", "", INVALID_DEST_ADDRESS);
            }
            if (!DEST_REGEX_PATTERN.matcher(smsRequest.getDestinationAddress()).find()) {
                errors.rejectValue("destinationAddress", "", INVALID_DEST_ADDRESS);
            }
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "message", "",
                "message field is invalid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "messageType", "",
                "messageType field is invalid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "category", "",
                "category field is invalid");

        logger.debug("SmsRequestValidator.validate end.");

    }

}
