package ie.aib.comms.controller;

import ie.aib.comms.exception.SmsException;
import ie.aib.comms.model.Sms;
import ie.aib.comms.service.SmsService;
import ie.aib.comms.validation.SmsRequestValidator;
import ie.aib.msf.security.jwt.JwtAuthenticationToken;
import ie.aib.msf.security.jwt.annotation.JwtAuthorization;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "comms-sms-service", description = "Comms SMS Service")
@RestController
@RequestMapping("/api")
public class SmsController {
    private static Log logger = LogFactory.getLog(SmsController.class);

    @Autowired
    SmsService smsService;

    /**
     * This validates the request object.
     * @param binder for the validation.
     */
    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(new SmsRequestValidator());
    }

    /**
     * This is the endpoint which takes in the sms request and calls the sms service to process.
     *
     * @param sms to be processed.
     * @return ResponseEntity containing the message id supplied by the sms provider.
     * @throws SmsException if an error occurs during processing.
     */
    @ApiOperation(value = "Send SMS", notes = "### Calls the SMS Provider. \n")
    @JwtAuthorization
    @RequestMapping(value = "/communications/v1/sms", method = RequestMethod.POST,
    consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Sms> sendSms(@Valid @RequestBody Sms sms) throws SmsException {

        logger.info("Received Sms...");
        smsService.sendSms(sms);

        return new ResponseEntity<>(sms, HttpStatus.OK);
    }

}
