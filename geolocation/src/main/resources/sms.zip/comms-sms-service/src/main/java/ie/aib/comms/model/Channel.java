package ie.aib.comms.model;

import ie.aib.comms.exception.SmsException;

public enum Channel {

    TBD1("tbd1"),
    TBD2("tbd2");

    private final String value;

    private Channel(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    /**
     * This method gets the channel.
     *
     * @param value for which to get the channel object.
     * @return channel object.
     * @throws SmsException if theres error during processing.
     */
    public static Channel getChannel(String value) throws SmsException {

        for (Channel channel : Channel.values()) {
            if (channel.getValue().equals(value)) {
                return channel;
            }
        }
        throw new IllegalArgumentException("Illegal Channel value: " + value);
    }

}
