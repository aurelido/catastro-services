package ie.aib.comms.configuration;

import static com.google.common.collect.Lists.newArrayList;

import com.fasterxml.classmate.TypeResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {

    @Autowired
    private TypeResolver typeResolver;

    /**
     * Provides generic defaults and convenience methods for Springfox/Swagger framework configuration.
     */
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .securitySchemes(newArrayList(new ApiKey("authorization", "authorization", "header")))
                .select()
                .apis(RequestHandlerSelectors.basePackage("ie.aib.comms"))
                .paths(PathSelectors.any()).build()
                .pathMapping("/");
    }
}
