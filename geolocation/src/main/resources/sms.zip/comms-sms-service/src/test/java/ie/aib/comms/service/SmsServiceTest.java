package ie.aib.comms.service;

import org.junit.Before;
import org.junit.Test;

public class SmsServiceTest {

    @Before
    public void init() {
        //
    }

    @Test
    public void testSendSms() {
        // Cannot send SMS as test
    }

}
