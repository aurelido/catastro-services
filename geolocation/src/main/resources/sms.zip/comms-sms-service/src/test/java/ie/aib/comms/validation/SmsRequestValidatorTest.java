package ie.aib.comms.validation;

import static org.assertj.core.api.Assertions.assertThat;

import ie.aib.comms.model.Category;
import ie.aib.comms.model.Sms;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;

@RunWith(MockitoJUnitRunner.class)
public class SmsRequestValidatorTest {

    private SmsRequestValidator smsRequestValidator;
    private BindingResult bindingResult;
    private Sms smsRequest;

    public static final String APPLICATIONID_INVALID = "applicationId field is invalid";
    public static final String DESTINATIONADDRESS_INVALID = "destinationAddress field is invalid";
    public static final String MESSAGE_INVALID = "message field is invalid";
    public static final String MESSAGETYPE_INVALID = "messageType field is invalid";
    public static final String CATEGORY_INVALID = "category field is invalid";


    @Before
    public void setUp() {
        smsRequestValidator = new SmsRequestValidator();
        bindingResult = new BeanPropertyBindingResult(new Sms(), "Sms");
    }

    @Test
    public void should_fail_validation_applicationid_null() {

        smsRequest = getValidSmsRequest();
        smsRequest.setApplicationId(null);
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("applicationId").getDefaultMessage()).isEqualTo(APPLICATIONID_INVALID);
    }

    @Test
    public void should_fail_validation_applicationid_empty() {

        Sms smsRequest = new Sms();
        smsRequest.setApplicationId("");
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("applicationId").getDefaultMessage()).isEqualTo(APPLICATIONID_INVALID);
    }

    @Test
    public void should_fail_validation_destinationaddress_null() {

        smsRequest = getValidSmsRequest();
        smsRequest.setDestinationAddress(null);
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("destinationAddress").getDefaultMessage()).isEqualTo(DESTINATIONADDRESS_INVALID);
    }

    @Test
    public void should_fail_validation_destinationaddress_empty() {

        Sms smsRequest = new Sms();
        smsRequest.setDestinationAddress("");
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("destinationAddress").getDefaultMessage()).isEqualTo(DESTINATIONADDRESS_INVALID);
    }

    @Test
    public void should_fail_validation_message_null() {

        smsRequest = getValidSmsRequest();
        smsRequest.setMessage(null);
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("message").getDefaultMessage()).isEqualTo(MESSAGE_INVALID);
    }

    @Test
    public void should_fail_validation_message_empty() {

        Sms smsRequest = new Sms();
        smsRequest.setMessage("");
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("message").getDefaultMessage()).isEqualTo(MESSAGE_INVALID);
    }

    @Test
    public void should_fail_validation_messagetype_null() {

        smsRequest = getValidSmsRequest();
        smsRequest.setMessageType(null);
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("messageType").getDefaultMessage()).isEqualTo(MESSAGETYPE_INVALID);
    }

    @Test
    public void should_fail_validation_messagetype_empty() {

        Sms smsRequest = new Sms();
        smsRequest.setMessageType("");
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("messageType").getDefaultMessage()).isEqualTo(MESSAGETYPE_INVALID);
    }

    @Test
    public void should_fail_validation_category_null() {

        smsRequest = getValidSmsRequest();
        smsRequest.setCategory(null);
        smsRequestValidator.validate(smsRequest, bindingResult);
        assertThat(bindingResult.getFieldError("category").getDefaultMessage()).isEqualTo(CATEGORY_INVALID);
    }

    public Sms getValidSmsRequest() {
        Sms smsRequest = new Sms();
        smsRequest.setApplicationId("oneview");
        smsRequest.setDestinationAddress("+353121234567");
        smsRequest.setMessage("Hello");
        smsRequest.setMessageType("1");
        smsRequest.setCategory(Category.OPERATIONAL);

        return smsRequest;
    }

}
