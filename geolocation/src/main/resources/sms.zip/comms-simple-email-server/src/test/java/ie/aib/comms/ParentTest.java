package ie.aib.comms;

import ie.aib.comms.integration.model.Address;
import ie.aib.comms.integration.model.Attachment;
import ie.aib.comms.integration.model.AttachmentHref;
import ie.aib.comms.integration.model.Body;
import ie.aib.comms.integration.model.Email;
import ie.aib.comms.integration.model.Header;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ParentTest {

    public static final String HEADER_NAME = "Return-Path";
    public static final String HEADER_VALUE = "<djs@yahoo.co.uk>";
    public static final String ATTACHMENT_NAME = "file.txt";
    public static final String RECIPIENT_EMAIL = "tommy.j.mitchell@aib.ie";
    public static final String EMAIL_SUBJECT = "This is the subject";
    public static final String FROM_EMAIL = "commshubtest@aib.ie";
    public static final String RECIPIENT_NAME = "Tommy";
    public static final String FROM_NAME = "AIB Comms Hub Test";

    public Email prepareEmail() throws IOException {

        Email email = new Email();

        Address from = new Address(FROM_NAME, FROM_EMAIL);
        email.setFrom(from);

        List<Address> to = new ArrayList<>();
        to.add(new Address(RECIPIENT_NAME, RECIPIENT_EMAIL));
        email.setTo(to);
        email.setSubject(EMAIL_SUBJECT);

        email.setReplyTo(RECIPIENT_EMAIL);

        Body body = new Body("sample body", "&lt;html&gt;&lt;body&gt;Hello World&lt;/body&gt;&lt;/html&gt;");
        email.setBody(body);

        List<Header> headers = new ArrayList<>();
        headers.add(new Header(HEADER_NAME, HEADER_VALUE));
        email.setHeaders(headers);

        List<Attachment> attachements = new ArrayList<>();
        Attachment attachment = new AttachmentHref(ATTACHMENT_NAME, getAttachmentHref());
        attachements.add(attachment);
        email.setAttachments(attachements);

        //TODO implement an attachement test for Base54 content

        return email;
    }

    public static String getAttachmentHref() throws IOException {
        Resource fileResource = new ClassPathResource(ATTACHMENT_NAME);
        return fileResource.getURL().toString();
    }

}
