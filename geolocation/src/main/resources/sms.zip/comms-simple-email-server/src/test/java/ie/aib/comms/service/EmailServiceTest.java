package ie.aib.comms.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.google.common.base.Strings;
import ie.aib.comms.ParentTest;
import ie.aib.comms.integration.model.Email;
import java.util.Properties;
import javax.activation.DataSource;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.commons.mail.util.MimeMessageParser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;

public class EmailServiceTest extends ParentTest {

    private EmailService emailService;
    private JavaMailSender javaMailSender;

    @Before
    public void setup() {
        javaMailSender = mock(JavaMailSender.class);
        emailService = new EmailServiceImpl(javaMailSender);
    }

    @Test
    public void testSendEmailWithPlainAndHtmlContent() throws Exception {
        MimeMessage message = prepareMimeMessage();
        when(javaMailSender.createMimeMessage()).thenReturn(message);
        doNothing().when(javaMailSender).send(message);

        Email email = prepareEmail();
        emailService.sendEmail(email);

        verifyMessage(message, email);
        verify(javaMailSender, times(1)).createMimeMessage();
        verify(javaMailSender, times(1)).send(message);
    }

    private void verifyMessage(MimeMessage message, Email email) throws Exception {
        assertEquals(email.getSubject(), message.getSubject());

        MimeMessageParser parser = new MimeMessageParser(message);
        parser.parse();
        String actualHtmlContent = parser.getHtmlContent();
        assertEquals(email.getBody().getHtmlContent(), actualHtmlContent);

        String actualPlainContent = parser.getPlainContent();
        assertEquals(email.getBody().getPlainTextContent(), actualPlainContent);

        InternetAddress toAddress = (InternetAddress) message.getAllRecipients()[0];
        assertEquals(email.getTo().get(0).getEmail(), toAddress.getAddress());
        assertEquals(email.getTo().get(0).getName(), toAddress.getPersonal());

        InternetAddress fromAddress = (InternetAddress) message.getFrom()[0];
        assertEquals(email.getFrom().getEmail(), fromAddress.getAddress());
        assertEquals(email.getFrom().getName(), fromAddress.getPersonal());

        //verify headers
        String[] header = message.getHeader(ParentTest.HEADER_NAME);
        assertTrue(header.length == 1);
        assertEquals(ParentTest.HEADER_VALUE, header[0]);

        //verify attachements
        DataSource attachmentDataSource = parser.findAttachmentByName(ParentTest.ATTACHMENT_NAME);
        assertNotNull(attachmentDataSource);
        assertEquals("text/plain", attachmentDataSource.getContentType());

    }

    private MimeMessage prepareMimeMessage() {

        Properties mailProperties = new Properties();
        mailProperties.setProperty("mail.smtp.host", "smtp://localhost");
        mailProperties.setProperty("mail.smtp.port", "25");
        mailProperties.setProperty("mail.user", "Tommy");
        mailProperties.setProperty("mail.password", "TommyPass");
        mailProperties.setProperty("mail.store.protocol", "smtp");

        Session session = Session.getDefaultInstance(mailProperties);
        return new MimeMessage(session);
    }

    @Test
    public void testSendEmailWithPlainOnlyContent() throws Exception {
        MimeMessage message = prepareMimeMessage();
        when(javaMailSender.createMimeMessage()).thenReturn(message);
        doNothing().when(javaMailSender).send(message);

        Email email = prepareEmail();
        email.getBody().setHtmlContent("");
        emailService.sendEmail(email);

        MimeMessageParser parser = new MimeMessageParser(message);
        parser.parse();
        String actualHtmlContent = parser.getHtmlContent();
        assertTrue(Strings.isNullOrEmpty(actualHtmlContent));

        String actualPlainContent = parser.getPlainContent();
        assertEquals(email.getBody().getPlainTextContent(), actualPlainContent);


        verify(javaMailSender, times(1)).createMimeMessage();
        verify(javaMailSender, times(1)).send(message);
    }

    @Test
    public void testSendEmailWithHtmlOnlyContent() throws Exception {
        MimeMessage message = prepareMimeMessage();
        when(javaMailSender.createMimeMessage()).thenReturn(message);
        doNothing().when(javaMailSender).send(message);

        Email email = prepareEmail();
        email.getBody().setPlainTextContent("");
        emailService.sendEmail(email);

        MimeMessageParser parser = new MimeMessageParser(message);
        parser.parse();

        assertTrue(Strings.isNullOrEmpty(parser.getPlainContent()));

        String actualHtmlContent = parser.getHtmlContent();
        assertEquals(email.getBody().getHtmlContent(), actualHtmlContent);


        verify(javaMailSender, times(1)).createMimeMessage();
        verify(javaMailSender, times(1)).send(message);
    }


    @Test(expected = MailException.class)
    public void testSendEmailWithMessagingException() throws Exception {
        MimeMessage message = prepareMimeMessage();
        when(javaMailSender.createMimeMessage()).thenReturn(message);
        doThrow(new MailSendException("mail failed")).when(javaMailSender).send(message);

        Email email = prepareEmail();
        emailService.sendEmail(email);

        verifyMessage(message, email);
        verify(javaMailSender, times(1)).createMimeMessage();
        verify(javaMailSender, times(1)).send(message);
    }

}
