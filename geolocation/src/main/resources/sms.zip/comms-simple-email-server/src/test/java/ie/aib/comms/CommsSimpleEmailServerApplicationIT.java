package ie.aib.comms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.icegreen.greenmail.junit.GreenMailRule;
import com.icegreen.greenmail.util.ServerSetupTest;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.core.MediaType;
import org.apache.commons.mail.util.MimeMessageParser;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CommsSimpleEmailServerApplicationIT {

    private static final String JSON_CORRECT_PAYLOAD = "{\n"
            + "\"from\": {\n"
            + "\"name\": \"AIB Comms Hub Test\",\n"
            + "\"email\": \"Direct.EnquiryTESTGB@aib.ie\"\n"
            + "},\n"
            + "\"to\": [{\n"
            + "\"name\": \"Tommy\",\n"
            + "\"email\": \"tommy.j.mitchell@aib.ie\"\n"
            + "}],\n"
            + "\"replyTo\":   \"Lukasz.X.Grabczyk@aib.ie\",\n"
            + "\"subject\": \"Welcome to AIB\",\n"
            + "\"headers\": [{\n"
            + "\"name\": \"X-Return-Path\",\n"
            + "\"value\": \"<djs@yahoo.co.uk>\"\n"
            + "}],\n"
            + "\"body\": {\n"
            + "\"plainTextContent\": \"Hello John Do\",\n"
            + "\"htmlContent\": \"<HTML><B>Hello John Doe</B></HTML>\"\n"
            + "}\n"
            + ",\n"
            + "\"attachments\": [{"
            + "\"filename\": \"file.txt\",\n"
            + "\"type\": \"href\",\n"
            + "\t\t\"href\": \"%s\""
            + "}]\n"
            + "}\n";


    private static final String JSON_MISSING_VALUE_PAYLOAD = "{\n"
            + "\"from\": {\n"
            + "\"name\": \"AIB Comms Hub Test\",\n"
            + "\"email\": \"Direct.EnquiryTESTGBaib.ie\"\n"
            + "},\n"
            + "\"to\": [{\n"
            + "\"name\": \"Tommy\",\n"
            + "\"email\": \"\"\n"
            + "}],\n"
            + "\"replyTo\":   \"Lukasz.X.Grabczyk@aib.ie\",\n"
            + "\"subject\": \"Welcome to AIB\",\n"
            + "\"headers\": [{\n"
            + "\"name\": \"Return-Path\",\n"
            + "\"value\": \"<djs@yahoo.co.uk>\"\n"
            + "}],\n"
            + "\"body\": {\n"
            + "\"plainTextContent\": \"Hello John Do\",\n"
            + "\"htmlContent\": \"<HTML><B>Hello John Doe</B></HTML>\"\n"
            + "}\n"
            + ",\n"
            + "\"attachments\": [{}]\n"
            + "}\n";

    private static final String JSON_MALFORMED_EMAIL_PAYLOAD = "{\n"
            + "\"from\": {\n"
            + "\"name\": \"AIB Comms Hub Test\",\n"
            + "\"email\": \"Direct.EnquiryTESTGBaib.ie\"\n"
            + "},\n"
            + "\"to\": [{\n"
            + "\"name\": \"Tommy\",\n"
            + "\"email\": \"tommy.j.mitchell@aib.ie\"\n"
            + "}],\n"
            + "\"replyTo\":   \"Lukasz.X.Grabczyk@aib.ie\",\n"
            + "\"subject\": \"Welcome to AIB\",\n"
            + "\"headers\": [{\n"
            + "\"name\": \"Return-Path\",\n"
            + "\"value\": \"<djs@yahoo.co.uk>\"\n"
            + "}],\n"
            + "\"body\": {\n"
            + "\"plainTextContent\": \"Hello John Do\",\n"
            + "\"htmlContent\": \"<HTML><B>Hello John Doe</B></HTML>\"\n"
            + "}\n"
            + "}\n";
    ;

    private static final String SEND_EMAIL_URL = "/v1/messages/send";

    @Rule
    public final GreenMailRule greenMail = new GreenMailRule((ServerSetupTest.SMTP));

    @Autowired
    private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before
    public void setup() throws Exception {
        mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    @Test
    public void testEmailServerWithJsonPayload() throws Exception {

        String attachmentHref = ParentTest.getAttachmentHref();
        attachmentHref = String.format(JSON_CORRECT_PAYLOAD, attachmentHref);

        MockHttpServletRequestBuilder requestBuilder = post(SEND_EMAIL_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(attachmentHref);

        mockMvc.perform(requestBuilder).andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"));

        verifyEmail();
    }

    private void verifyEmail() throws Exception {
        MimeMessage[] receivedMessages = greenMail.getReceivedMessages();
        assertThat(receivedMessages).hasSize(1);
        MimeMessage actualMessage = receivedMessages[0];

        //tests subject
        assertEquals("Welcome to AIB", actualMessage.getSubject());

        // test recipient
        assertEquals("Tommy <tommy.j.mitchell@aib.ie>", actualMessage.getAllRecipients()[0].toString());

        // tests body payload
        MimeMessageParser parser = new MimeMessageParser(actualMessage);
        parser.parse();

        String actualPlainContent = parser.getPlainContent();
        assertEquals("Hello John Do", actualPlainContent);

        String actualHtmlContent = parser.getHtmlContent();
        assertEquals("<HTML><B>Hello John Doe</B></HTML>", actualHtmlContent);

        //tests headers
        String[] actualReturnPathHeader = actualMessage.getHeader("X-Return-Path");
        assertTrue(actualReturnPathHeader.length == 1);
        assertEquals("<djs@yahoo.co.uk>", actualReturnPathHeader[0]);

        //tests replyto
        Address[] replyTo = actualMessage.getReplyTo();
        assertTrue(replyTo.length == 1);
        assertEquals("Lukasz.X.Grabczyk@aib.ie", replyTo[0].toString());

        //verify attachements
        DataSource attachmentDataSource = parser.findAttachmentByName(ParentTest.ATTACHMENT_NAME);
        assertNotNull(attachmentDataSource);
        assertEquals("text/plain", attachmentDataSource.getContentType());

    }

    @Test
    public void testEmailServerWithMalformedContent() throws Exception {
        MockHttpServletRequestBuilder requestBuilder = post(SEND_EMAIL_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(JSON_MALFORMED_EMAIL_PAYLOAD);
        mockMvc.perform(requestBuilder).andExpect(status().is4xxClientError());
    }

    @Test
    public void testEmailServerWithMissingContent() throws Exception {

        MockHttpServletRequestBuilder requestBuilder = post(SEND_EMAIL_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(JSON_MISSING_VALUE_PAYLOAD);

        mockMvc.perform(requestBuilder)
                .andExpect(status().is4xxClientError());
    }
}
