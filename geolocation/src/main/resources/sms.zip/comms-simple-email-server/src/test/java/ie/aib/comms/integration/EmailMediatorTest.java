package ie.aib.comms.integration;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ie.aib.comms.ParentTest;
import ie.aib.comms.integration.model.ApiResponse;
import ie.aib.comms.integration.model.Email;
import ie.aib.comms.service.EmailService;
import ie.aib.comms.service.EmailServiceImpl;
import java.io.IOException;
import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import org.junit.Before;
import org.junit.Test;

public class EmailMediatorTest extends ParentTest  {

    public static final String MESSADE_ID = "messade-ID";
    private EmailService emailService;
    private EmailMediator emailMediator;

    @Before
    public void setup() {
        emailService = mock(EmailServiceImpl.class);
        emailMediator = new EmailMediatorImpl(emailService);
    }

    @Test
    public void testSendEmail() throws IOException, MessagingException {

        Email email = prepareEmail();
        when(emailService.sendEmail(email)).thenReturn(MESSADE_ID);

        ApiResponse apiResponseActual = emailMediator.sendEmail(email);
        assertEquals(MESSADE_ID, apiResponseActual.getMessageId());

        verify(emailService, times(1)).sendEmail(email);
    }

    @Test(expected = MessagingException.class)
    public void testSendEmailWithMessagingException() throws IOException, MessagingException {
        Email email = prepareEmail();
        doThrow(new AuthenticationFailedException("auth failed")).when(emailService).sendEmail(email);

        emailMediator.sendEmail(email);

        verify(emailService, times(1)).sendEmail(email);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSendEmailWithMissingBodyException() throws IOException, MessagingException {
        Email email = prepareEmail();
        email.getBody().setPlainTextContent("");
        email.getBody().setHtmlContent("");
        emailMediator.sendEmail(email);

        verify(emailService, times(0)).sendEmail(email);
    }

}
