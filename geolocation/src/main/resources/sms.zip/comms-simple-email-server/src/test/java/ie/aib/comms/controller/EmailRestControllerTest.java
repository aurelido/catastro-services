package ie.aib.comms.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ie.aib.comms.ParentTest;
import ie.aib.comms.integration.EmailMediator;
import ie.aib.comms.integration.EmailMediatorImpl;
import ie.aib.comms.integration.model.ApiResponse;
import ie.aib.comms.integration.model.Email;
import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import org.junit.Before;
import org.junit.Test;

public class EmailRestControllerTest extends ParentTest {

    public static final String MESSAGE_ID = "messageId13";
    private EmailRestController emailRestController;
    private EmailMediator emailMediator;

    @Before
    public void setup() {
        emailMediator = mock(EmailMediatorImpl.class);
        emailRestController = new EmailRestController(emailMediator);
    }

    @Test
    public void testSendEmail() throws IOException, MessagingException {
        Email email = prepareEmail();
        ApiResponse apiResponse = prepareApiResponse(email);
        when(emailMediator.sendEmail(email)).thenReturn(apiResponse);

        ApiResponse apiResponseActual = emailRestController.sendEmail(email);
        assertEquals(MESSAGE_ID, apiResponseActual.getMessageId());

        verify(emailMediator, times(1)).sendEmail(email);
    }

    private ApiResponse prepareApiResponse(Email email) {
        return new ApiResponse("commsId", MESSAGE_ID);
    }

    @Test(expected = MessagingException.class)
    public void testSendEmailWithMessagingException() throws IOException, MessagingException {
        Email email = prepareEmail();
        when(emailMediator.sendEmail(email)).thenThrow(new AddressException());

        emailRestController.sendEmail(email);

        verify(emailMediator, times(1)).sendEmail(email);
    }

}
