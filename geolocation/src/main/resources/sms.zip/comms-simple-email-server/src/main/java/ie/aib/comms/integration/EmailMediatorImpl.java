package ie.aib.comms.integration;

import com.google.common.base.Strings;
import ie.aib.comms.integration.model.ApiResponse;
import ie.aib.comms.integration.model.Email;
import ie.aib.comms.service.EmailService;
import java.io.UnsupportedEncodingException;
import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailMediatorImpl implements EmailMediator {

    private static final int OK = 200;

    private EmailService emailService;

    @Autowired
    public EmailMediatorImpl(EmailService emailService) {
        this.emailService = emailService;
    }

    @Override
    public ApiResponse sendEmail(Email email) throws MessagingException, UnsupportedEncodingException {

        validateEmail(email);

        String messageID =  emailService.sendEmail(email);

        ApiResponse apiResponse = new ApiResponse("comms", messageID);
        return apiResponse;
    }

    private void validateEmail(Email email) {

        // validate email's body
        if (Strings.isNullOrEmpty(email.getBody().getPlainTextContent()) && Strings
                .isNullOrEmpty(email.getBody().getHtmlContent())) {
            throw new IllegalArgumentException("Email's body cannot be empty.");
        }

        //validate 'To' addresses
        if (email.getTo().size() == 0) {
            throw new IllegalArgumentException("At least one 'To' email recipient must be specified.");
        }

    }
}
