package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Header {

    @NotNull(message = "'name' attribute cannot be null")
    @NotBlank(message = "'name' attribute cannot be empty")
    private String name;

    @NotNull(message = "'value' attribute cannot be null")
    @NotBlank(message = "'value' attribute cannot be empty")
    private String value;

}
