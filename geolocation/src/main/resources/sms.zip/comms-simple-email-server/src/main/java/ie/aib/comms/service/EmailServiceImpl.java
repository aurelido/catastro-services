package ie.aib.comms.service;

import com.google.common.base.Strings;
import ie.aib.comms.controller.EmailRestController;
import ie.aib.comms.exception.AttachmentException;
import ie.aib.comms.exception.HeaderException;
import ie.aib.comms.integration.model.Address;
import ie.aib.comms.integration.model.Attachment;
import ie.aib.comms.integration.model.AttachmentHref;
import ie.aib.comms.integration.model.Email;
import ie.aib.comms.integration.model.Header;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailRestController.class);

    private JavaMailSender emailSender;

    @Autowired
    public EmailServiceImpl(JavaMailSender emailSender) {
        this.emailSender = emailSender;
    }

    @Override
    public String sendEmail(Email email) throws MessagingException {

        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setSubject(email.getSubject());

        setReplyTo(email, helper);

        setBody(email, helper);

        setTo(email, helper);
        helper.setFrom(getInternetAddress(email.getFrom()));

        if (email.getHeaders() != null) {
            email.getHeaders().forEach(header -> addHeader(message, header));
        }

        if (email.getAttachments() != null) {
            email.getAttachments().forEach(attachment -> addAttachment(helper, attachment));
        }

        emailSender.send(message);

        LOGGER.info("Email sent to " + email.getTo());

        return message.getMessageID();
    }

    private void setReplyTo(Email email, MimeMessageHelper helper) throws MessagingException {
        if (!Strings.isNullOrEmpty(email.getReplyTo())) {
            helper.setReplyTo(email.getReplyTo());
        }
    }

    private void setTo(Email email, MimeMessageHelper helper) throws MessagingException {
        InternetAddress[] addresses = email.getTo().stream().map(this::getInternetAddress)
                .toArray(InternetAddress[]::new);
        helper.setTo(addresses);
    }

    private InternetAddress getInternetAddress(Address address) {
        try {
            return new InternetAddress(address.getEmail(), address.getName());
        } catch (UnsupportedEncodingException exp) {
            throw new RuntimeException(exp);
        }
    }

    private void addHeader(MimeMessage message, Header header) {
        try {
            message.addHeader(header.getName(), header.getValue());
        } catch (MessagingException exp) {
            LOGGER.error("An error occurred durign adding a header ", exp);
            throw new HeaderException("An error occurred durign adding a header", exp);
        }
    }

    private void addAttachment(MimeMessageHelper helper, Attachment attachment) {

        if (attachment instanceof AttachmentHref) {
            AttachmentHref attachmentHref = (AttachmentHref) attachment;
            if (!Strings.isNullOrEmpty(attachmentHref.getHref())) {
                try {
                    Resource attachmentResource = new UrlResource(String.format("url:%s", attachmentHref.getHref()));
                    helper.addAttachment(attachmentHref.getFilename(), attachmentResource);
                } catch (MessagingException | MalformedURLException exp) {
                    LOGGER.error("An error occurred during adding an attachement ", exp);
                    throw new AttachmentException("An error occurred during adding an attachemen", exp);
                }
            }
        }
        //TODO implements an attachment functionality for Base54 content
    }

    private void setBody(Email email, MimeMessageHelper helper) throws MessagingException {

        String plainTextContent = email.getBody().getPlainTextContent();
        String htmlContent = email.getBody().getHtmlContent();

        if (isPlainTextOnlyContent(plainTextContent, htmlContent)) {
            helper.setText(plainTextContent, false);
        } else if (isHtmlOnlyContent(plainTextContent, htmlContent)) {
            helper.setText(htmlContent, true);
        } else if (isBothHmltAndPlainContent(plainTextContent, htmlContent)) {
            helper.setText(plainTextContent, htmlContent);
        }
    }

    private boolean isBothHmltAndPlainContent(String plainTextContent, String htmlContent) {
        return !Strings.isNullOrEmpty(plainTextContent) && !Strings.isNullOrEmpty(htmlContent);
    }

    private boolean isHtmlOnlyContent(String plainTextContent, String htmlContent) {
        return !Strings.isNullOrEmpty(htmlContent) && Strings.isNullOrEmpty(plainTextContent);
    }

    private boolean isPlainTextOnlyContent(String plainTextContent, String htmlContent) {
        return !Strings.isNullOrEmpty(plainTextContent) && Strings.isNullOrEmpty(htmlContent);
    }

}
