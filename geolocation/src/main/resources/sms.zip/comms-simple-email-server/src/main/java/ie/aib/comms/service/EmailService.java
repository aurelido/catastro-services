package ie.aib.comms.service;

import ie.aib.comms.integration.model.Email;
import java.io.UnsupportedEncodingException;
import javax.mail.MessagingException;

public interface EmailService {

    String sendEmail(Email email) throws MessagingException, UnsupportedEncodingException;
}
