package ie.aib.comms.integration;

import ie.aib.comms.integration.model.ApiResponse;
import ie.aib.comms.integration.model.Email;
import java.io.UnsupportedEncodingException;
import javax.mail.MessagingException;

public interface EmailMediator {

    ApiResponse sendEmail(Email email) throws MessagingException, UnsupportedEncodingException;
}
