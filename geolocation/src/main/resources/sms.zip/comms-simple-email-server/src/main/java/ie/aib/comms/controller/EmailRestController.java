package ie.aib.comms.controller;

import ie.aib.comms.integration.EmailMediator;
import ie.aib.comms.integration.model.ApiResponse;
import ie.aib.comms.integration.model.Email;
import java.io.UnsupportedEncodingException;
import javax.mail.MessagingException;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/messages")
public class EmailRestController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailRestController.class);

    private EmailMediator emailMediator;

    @Autowired
    public EmailRestController(EmailMediator emailMediator) {
        this.emailMediator = emailMediator;
    }

    @RequestMapping(value = "/send", method = RequestMethod.POST)
    @ResponseBody
    public ApiResponse sendEmail(@RequestBody @Valid Email email)
            throws MessagingException, UnsupportedEncodingException {
        LOGGER.info("received a request to send an email with payload " + email);
        return emailMediator.sendEmail(email);
    }

    // Convert a predefined exceptions to an HTTP Status codes

    @ResponseStatus(value = HttpStatus.BAD_REQUEST,
            reason = "Malformed payload passed in a request")
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public void methodArgumentNotValidException(MethodArgumentNotValidException exp) {
        LOGGER.error("Malformed payload passed in a request ", exp);
    }

    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR,
            reason = "Internal Server Error")
    @ExceptionHandler(Exception.class)
    public void internalServerError(Exception exp) {
        LOGGER.error("An exception has occured ", exp);
    }

}
