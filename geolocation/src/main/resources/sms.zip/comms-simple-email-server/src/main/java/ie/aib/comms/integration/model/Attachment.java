package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import javax.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
@JsonTypeInfo(
        defaultImpl = AttachmentHref.class,
        use = JsonTypeInfo.Id.NAME,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = AttachmentHref.class, name = "href"),
        @JsonSubTypes.Type(value = AttachmentBase64.class, name = "contentType")
})
public abstract class Attachment {

    private String filename;

    Attachment(String filename) {
        this.filename = filename;
    }


}
