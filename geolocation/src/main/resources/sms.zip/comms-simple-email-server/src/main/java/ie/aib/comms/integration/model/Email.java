package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Email {

    @NotNull(message = "'from' field cannot be null")
    @Valid
    private Address from;

    @NotNull(message = "'to' field cannot be null")
    @Valid
    private List<Address> to;

    private String replyTo;

    @NotNull(message = "'subject' field cannot be null")
    private String subject;

    @Valid
    private List<Header> headers;

    @NotNull(message = "'body' field cannot be null")
    private Body body;

    private List<Attachment> attachments;

}
