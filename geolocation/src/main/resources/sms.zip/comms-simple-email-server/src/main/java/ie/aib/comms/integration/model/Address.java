package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    @NotBlank(message = "'name' field cannot be empty")
    private String name;

    @NotBlank(message = "'email' field cannot be empty")
    @javax.validation.constraints.Email(message = "'email' field must contain a valid email address")
    private String email;

}
