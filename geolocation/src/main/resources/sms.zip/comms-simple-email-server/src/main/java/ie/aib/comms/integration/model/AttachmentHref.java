package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
public class AttachmentHref extends Attachment {

    private String href;

    public AttachmentHref(@NotBlank(message = "'filename' attribute cannot be empty") String filename,
            @NotBlank(message = "'href' attribute cannot be empty") String href) {
        super(filename);
        this.href = href;
    }
}
