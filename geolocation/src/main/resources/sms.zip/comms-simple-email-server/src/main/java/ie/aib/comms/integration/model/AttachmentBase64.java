package ie.aib.comms.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
public class AttachmentBase64 extends Attachment {

    private String contentType;

    private String content;

    public AttachmentBase64(@NotBlank(message = "'filename' attribute cannot be empty") String filename,
            @NotBlank(message = "'contentType' attribute cannot be empty") String contentType,
            @NotBlank(message = "'base64Content' attribute cannot be empty") String content) {
        super(filename);
        this.contentType = contentType;
        this.content = content;
    }
}
